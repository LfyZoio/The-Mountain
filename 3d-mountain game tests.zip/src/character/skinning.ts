import * as THREE from 'three';
import { BONE_DEFS, BONE_INDEX, PRIMARY_CHILD } from './skeleton';

export interface Seg {
  name: string;
  idx: number;
  a: THREE.Vector3;
  b: THREE.Vector3;
}

const PARENT: Record<string, string | null> = Object.fromEntries(BONE_DEFS.map((d) => [d.name, d.parent]));
const CHILDREN: Record<string, string[]> = {};
for (const d of BONE_DEFS) if (d.parent) (CHILDREN[d.parent] ||= []).push(d.name);

/** Bone segments in bind (world) space for the given bone positions. */
export function buildSegments(world: Record<string, THREE.Vector3>, names: string[]): Seg[] {
  return names.map((n) => {
    const a = world[n].clone();
    const c = PRIMARY_CHILD[n];
    let b = c && world[c] ? world[c].clone() : a.clone().add(new THREE.Vector3(0, 0.06, 0));
    if (n === 'Backpack') b = a.clone().add(new THREE.Vector3(0, 0.25, 0));
    return { name: n, idx: BONE_INDEX[n], a, b };
  });
}

const _ab = new THREE.Vector3(),
  _ap = new THREE.Vector3();
export function segDist(p: THREE.Vector3, s: Seg) {
  _ab.subVectors(s.b, s.a);
  _ap.subVectors(p, s.a);
  const l2 = _ab.lengthSq();
  const t = l2 > 0 ? Math.max(0, Math.min(1, _ap.dot(_ab) / l2)) : 0;
  return _ap.addScaledVector(_ab, -t).length();
}

/**
 * Computes skin indices/weights for a geometry whose positions are in bind (world) space.
 * Influences are restricted to the nearest bone and its direct parent/children to avoid bleeding,
 * with smooth inverse-distance falloff for natural joint deformation.
 */
export function computeSkin(
  geo: THREE.BufferGeometry,
  segs: Seg[],
  opts: { candidates?: (p: THREE.Vector3) => Seg[] | null; falloff?: number; maxInf?: number } = {},
) {
  const pos = geo.attributes.position;
  const n = pos.count;
  const si = new Uint16Array(n * 4);
  const sw = new Float32Array(n * 4);
  const p = new THREE.Vector3();
  const falloff = opts.falloff ?? 0.06;
  const maxInf = opts.maxInf ?? 4;
  const byName: Record<string, Seg> = Object.fromEntries(segs.map((s) => [s.name, s]));
  for (let i = 0; i < n; i++) {
    p.fromBufferAttribute(pos, i);
    const cand = opts.candidates?.(p) ?? segs;
    let best = cand[0],
      bd = Infinity;
    const ds = new Map<Seg, number>();
    for (const s of cand) {
      const d = segDist(p, s);
      ds.set(s, d);
      if (d < bd) {
        bd = d;
        best = s;
      }
    }
    const allowed: Seg[] = [best];
    const par = PARENT[best.name];
    if (par && byName[par] && cand.includes(byName[par])) allowed.push(byName[par]);
    for (const c of CHILDREN[best.name] || []) if (byName[c] && cand.includes(byName[c])) allowed.push(byName[c]);
    const inf: [number, number][] = [];
    for (const s of allowed) {
      const d = ds.get(s) ?? segDist(p, s);
      if (d > bd + falloff) continue;
      const w = 1 / Math.pow(Math.max(d, 0.004), 4);
      inf.push([s.idx, w]);
    }
    inf.sort((a, b) => b[1] - a[1]);
    const top = inf.slice(0, maxInf);
    const tot = top.reduce((a, b) => a + b[1], 0) || 1;
    top.forEach(([idx, w], k) => {
      si[i * 4 + k] = idx;
      sw[i * 4 + k] = w / tot;
    });
  }
  geo.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4));
  geo.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4));
}
