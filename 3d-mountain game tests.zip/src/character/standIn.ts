import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { BONE_WORLD, DEFORM_BONES, createSkeleton } from './skeleton';
import { buildSegments, computeSkin } from './skinning';

/**
 * TEMPORARY STAND-IN — not the user's model.
 * A low-poly proxy built from the protagonist reference sheet (dark faceted shell jacket,
 * orange harness, carabiners, goggles, brown hair, pack + ice axe, mountaineering boots)
 * so the rig and animation pipeline can be demonstrated until the real model file is imported.
 */

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const COL = {
  jacket: 0x2c3039,
  jacket2: 0x353a45,
  pants: 0x2a2d33,
  harness: 0xe0561f,
  strap: 0x34363b,
  metal: 0xc7ccd2,
  glove: 0x18191b,
  boot: 0x3b3e44,
  sole: 0x1b1b1c,
  lace: 0xe08a2a,
  skin: 0xc9926c,
  stubble: 0x9a7058,
  hair: 0x5a3a22,
  lens: 0x5b8fb8,
  frame: 0x1e2024,
  pack: 0x2b2f37,
  packTrim: 0xd9531e,
  axeShaft: 0xd8561e,
};

function hash(x: number, y: number, z: number) {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
}

function jitter(g: THREE.BufferGeometry, amp: number) {
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i),
      y = p.getY(i),
      z = p.getZ(i);
    const k = Math.round(x * 400) + Math.round(y * 400) * 7 + Math.round(z * 400) * 13;
    p.setXYZ(i, x + (hash(k, 1, 2) - 0.5) * amp, y + (hash(k, 3, 4) - 0.5) * amp, z + (hash(k, 5, 6) - 0.5) * amp);
  }
  return g;
}

/** low-poly loft along a polyline with elliptical rings */
function loft(rings: { c: THREE.Vector3; rx: number; rz: number }[], seg = 8, capA = true, capB = true) {
  const pos: number[] = [];
  const idx: number[] = [];
  const up = V(0, 1, 0);
  rings.forEach((r, i) => {
    const prev = rings[Math.max(0, i - 1)].c,
      next = rings[Math.min(rings.length - 1, i + 1)].c;
    const t = next.clone().sub(prev).normalize();
    let u = Math.abs(t.y) > 0.9 ? V(1, 0, 0) : up.clone().cross(t).normalize();
    if (Math.abs(t.y) > 0.9) u = V(1, 0, 0);
    const v = t.clone().cross(u).normalize();
    // keep "rz" aligned with world Z for vertical loft
    for (let k = 0; k < seg; k++) {
      const a = (k / seg) * Math.PI * 2;
      const q = r.c.clone().addScaledVector(u, Math.cos(a) * r.rx).addScaledVector(v, Math.sin(a) * r.rz);
      pos.push(q.x, q.y, q.z);
    }
  });
  for (let i = 0; i < rings.length - 1; i++)
    for (let k = 0; k < seg; k++) {
      const a = i * seg + k,
        b = i * seg + ((k + 1) % seg),
        c = (i + 1) * seg + k,
        d = (i + 1) * seg + ((k + 1) % seg);
      idx.push(a, c, b, b, c, d);
    }
  const addCap = (ri: number, flip: boolean) => {
    const c = rings[ri].c;
    const ci = pos.length / 3;
    pos.push(c.x, c.y, c.z);
    for (let k = 0; k < seg; k++) {
      const a = ri * seg + k,
        b = ri * seg + ((k + 1) % seg);
      if (flip) idx.push(ci, a, b);
      else idx.push(ci, b, a);
    }
  };
  if (capA) addCap(0, false);
  if (capB) addCap(rings.length - 1, true);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  return g;
}

function tube(a: THREE.Vector3, b: THREE.Vector3, ra: number, rb: number, seg = 7, rings = 3) {
  const rs = [];
  for (let i = 0; i <= rings; i++) {
    const t = i / rings;
    const r = ra + (rb - ra) * t;
    rs.push({ c: a.clone().lerp(b, t), rx: r, rz: r });
  }
  return loft(rs, seg);
}

function ell(c: THREE.Vector3, rx: number, ry: number, rz: number, detail = 1) {
  const g = new THREE.IcosahedronGeometry(1, detail);
  g.scale(rx, ry, rz);
  g.translate(c.x, c.y, c.z);
  return g;
}

function box(c: THREE.Vector3, sx: number, sy: number, sz: number, rx = 0, ry = 0, rz = 0) {
  const g = new THREE.BoxGeometry(sx, sy, sz);
  g.rotateX(rx);
  g.rotateY(ry);
  g.rotateZ(rz);
  g.translate(c.x, c.y, c.z);
  return g;
}

function torusAt(c: THREE.Vector3, R: number, r: number, rx = Math.PI / 2, ry = 0, sx = 1, sz = 1) {
  const g = new THREE.TorusGeometry(R, r, 4, 14);
  g.rotateX(rx);
  g.rotateY(ry);
  g.scale(sx, 1, sz);
  g.translate(c.x, c.y, c.z);
  return g;
}

interface Part {
  g: THREE.BufferGeometry;
  color: number;
  bones: string[];
  facet?: number;
  jit?: number;
}

export interface StandInResult {
  group: THREE.Group;
  mesh: THREE.SkinnedMesh;
  skeleton: THREE.Skeleton;
  bones: Record<string, THREE.Bone>;
  axe: THREE.Group;
  triangles: number;
}

export function buildIceAxe(): THREE.Group {
  const g = new THREE.Group();
  g.name = 'IceAxe';
  const mat = (c: number, m = 0.1, r = 0.6) => new THREE.MeshStandardMaterial({ color: c, metalness: m, roughness: r, flatShading: true });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.017, 0.56, 6), mat(COL.axeShaft, 0.2, 0.5));
  shaft.position.y = 0;
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.16, 6), mat(0x1c1c1e, 0, 0.9));
  grip.position.y = -0.2;
  const spike = new THREE.Mesh(new THREE.ConeGeometry(0.014, 0.05, 5), mat(COL.metal, 0.9, 0.3));
  spike.rotation.x = Math.PI;
  spike.position.y = -0.305;
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.05), mat(0x2a2c30, 0.8, 0.4));
  head.position.y = 0.29;
  const pickG = new THREE.CylinderGeometry(0.004, 0.016, 0.16, 4);
  pickG.rotateX(Math.PI / 2);
  pickG.translate(0, 0, 0.1);
  const pick = new THREE.Mesh(pickG, mat(COL.metal, 0.9, 0.3));
  pick.position.y = 0.285;
  pick.rotation.x = 0.25;
  const adze = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.012, 0.075), mat(COL.metal, 0.9, 0.3));
  adze.position.set(0, 0.29, -0.06);
  for (const m of [shaft, grip, spike, head, pick, adze]) {
    m.castShadow = true;
    g.add(m);
  }
  return g;
}

export function buildStandIn(): StandInResult {
  const W = BONE_WORLD;
  const parts: Part[] = [];
  const P = (g: THREE.BufferGeometry, color: number, bones: string[], jit = 0.006, facet = 0.08) => parts.push({ g, color, bones, jit, facet });
  const torsoB = ['Hips', 'Spine', 'Spine1', 'Spine2'];

  // ---------- head ----------
  P(ell(V(0, 1.685, 0.012), 0.083, 0.105, 0.097, 1), COL.skin, ['Head'], 0.008);
  P(ell(V(0, 1.632, 0.04), 0.068, 0.045, 0.06, 1), COL.stubble, ['Head'], 0.006);
  P(box(V(0, 1.67, 0.105), 0.022, 0.04, 0.03, 0.25), COL.skin, ['Head'], 0.004);
  P(box(V(0.034, 1.705, 0.098), 0.024, 0.008, 0.01), COL.hair, ['Head'], 0.002);
  P(box(V(-0.034, 1.705, 0.098), 0.024, 0.008, 0.01), COL.hair, ['Head'], 0.002);
  P(box(V(0.032, 1.69, 0.096), 0.016, 0.01, 0.008), 0x1d1a18, ['Head'], 0.001);
  P(box(V(-0.032, 1.69, 0.096), 0.016, 0.01, 0.008), 0x1d1a18, ['Head'], 0.001);
  P(ell(V(0.085, 1.68, 0), 0.016, 0.026, 0.02, 0), COL.skin, ['Head'], 0.003);
  P(ell(V(-0.085, 1.68, 0), 0.016, 0.026, 0.02, 0), COL.skin, ['Head'], 0.003);
  // hair (tousled)
  P(ell(V(0, 1.745, -0.006), 0.09, 0.07, 0.105, 1), COL.hair, ['Head'], 0.03);
  P(ell(V(0.02, 1.775, 0.06), 0.05, 0.035, 0.04, 0), COL.hair, ['Head'], 0.02);
  P(ell(V(-0.03, 1.77, 0.05), 0.045, 0.03, 0.04, 0), COL.hair, ['Head'], 0.02);
  P(ell(V(0, 1.7, -0.07), 0.085, 0.06, 0.05, 1), COL.hair, ['Head'], 0.02);
  // neck + collar + hood
  P(tube(V(0, 1.5, 0), V(0, 1.62, 0.01), 0.05, 0.048, 6, 2), COL.skin, ['Neck', 'Head']);
  P(
    loft([
      { c: V(0, 1.44, -0.01), rx: 0.11, rz: 0.1 },
      { c: V(0, 1.5, -0.005), rx: 0.092, rz: 0.088 },
      { c: V(0, 1.57, 0), rx: 0.08, rz: 0.08 },
    ], 9, false, false),
    COL.jacket2,
    ['Spine2', 'Neck'],
  );
  P(ell(V(0, 1.53, -0.09), 0.12, 0.07, 0.06, 1), COL.jacket, ['Spine2', 'Neck'], 0.012);
  // goggles resting on collar
  P(box(V(0, 1.565, 0.085), 0.165, 0.058, 0.04, -0.2), COL.frame, ['Neck'], 0.003);
  P(box(V(0.042, 1.566, 0.106), 0.07, 0.042, 0.012, -0.2, 0.15), COL.lens, ['Neck'], 0.002);
  P(box(V(-0.042, 1.566, 0.106), 0.07, 0.042, 0.012, -0.2, -0.15), COL.lens, ['Neck'], 0.002);
  P(torusAt(V(0, 1.56, -0.005), 0.088, 0.008, Math.PI / 2, 0, 1, 1), COL.frame, ['Neck'], 0.002);

  // ---------- torso jacket ----------
  P(
    loft([
      { c: V(0, 0.86, 0), rx: 0.17, rz: 0.125 },
      { c: V(0, 0.98, 0), rx: 0.168, rz: 0.122 },
      { c: V(0, 1.1, -0.005), rx: 0.165, rz: 0.12 },
      { c: V(0, 1.24, -0.01), rx: 0.178, rz: 0.13 },
      { c: V(0, 1.36, -0.015), rx: 0.195, rz: 0.135 },
      { c: V(0, 1.44, -0.015), rx: 0.17, rz: 0.12 },
      { c: V(0, 1.48, -0.015), rx: 0.11, rz: 0.1 },
    ], 10, true, false),
    COL.jacket,
    torsoB,
    0.012,
  );
  // shoulders
  for (const s of [1, -1]) {
    const sd = s > 0 ? 'Left' : 'Right';
    P(ell(V(0.19 * s, 1.43, -0.02), 0.085, 0.075, 0.085, 1), COL.jacket, [`${sd}Shoulder`, `${sd}Arm`, 'Spine2'], 0.012);
  }
  P(box(V(0, 1.2, 0.128), 0.012, 0.5, 0.01), 0x6c717a, torsoB, 0.002);
  P(box(V(0.11, 1.22, 0.121), 0.06, 0.006, 0.01, 0, 0, 0.3), 0x6c717a, torsoB, 0.001);
  // backpack straps + sternum strap
  for (const s of [1, -1]) {
    P(box(V(0.095 * s, 1.3, 0.133), 0.05, 0.3, 0.018, 0.08, 0, 0.12 * s), COL.strap, ['Spine1', 'Spine2'], 0.004);
    P(box(V(0.12 * s, 1.31, 0.143), 0.008, 0.28, 0.008, 0.08, 0, 0.12 * s), COL.harness, ['Spine1', 'Spine2'], 0.002);
    P(box(V(0.15 * s, 1.47, 0.0), 0.06, 0.03, 0.2, 0, 0, -0.3 * s), COL.strap, ['Spine2'], 0.004);
  }
  P(box(V(0, 1.33, 0.148), 0.22, 0.022, 0.012), COL.strap, ['Spine2'], 0.002);
  P(box(V(0, 1.33, 0.156), 0.04, 0.03, 0.012), 0x111111, ['Spine2'], 0.002);
  // harness (waist belt + leg loops + belay loop + gear loops)
  P(loft([{ c: V(0, 0.965, 0.005), rx: 0.178, rz: 0.134 }, { c: V(0, 1.01, 0.005), rx: 0.176, rz: 0.132 }], 12, false, false), COL.strap, ['Hips', 'Spine'], 0.004);
  P(loft([{ c: V(0, 0.985, 0.008), rx: 0.18, rz: 0.136 }, { c: V(0, 0.995, 0.008), rx: 0.18, rz: 0.136 }], 12, false, false), COL.harness, ['Hips', 'Spine'], 0.002);
  P(box(V(0, 0.985, 0.142), 0.07, 0.03, 0.012), 0x8a8f96, ['Hips'], 0.002);
  P(box(V(0, 0.92, 0.135), 0.03, 0.12, 0.014), COL.harness, ['Hips'], 0.003);
  P(torusAt(V(0, 0.86, 0.14), 0.035, 0.007, 0, 0, 1, 1), COL.metal, ['Hips'], 0.002);
  for (const s of [1, -1]) {
    const sd = s > 0 ? 'Left' : 'Right';
    P(loft([{ c: V(0.1 * s, 0.82, 0.005), rx: 0.098, rz: 0.098 }, { c: V(0.1 * s, 0.845, 0.008), rx: 0.098, rz: 0.098 }], 10, false, false), COL.harness, [`${sd}UpLeg`, 'Hips'], 0.003);
    P(box(V(0.07 * s, 0.88, 0.12), 0.025, 0.1, 0.012, 0, 0, 0.5 * s), COL.harness, ['Hips', `${sd}UpLeg`], 0.002);
    // carabiners on gear loops
    for (let k = 0; k < 3; k++) {
      const a = 0.5 + k * 0.35;
      P(torusAt(V(Math.sin(a) * 0.185 * s, 0.94 - k * 0.012, Math.cos(a) * 0.14), 0.022, 0.0045, 0, (Math.PI / 2) * s * 0.4, 0.7, 1), k === 1 ? COL.harness : COL.metal, ['Hips'], 0.001);
    }
  }

  // ---------- arms & gloves ----------
  for (const s of [1, -1]) {
    const sd = s > 0 ? 'Left' : 'Right';
    const arm = W[`${sd}Arm`],
      el = W[`${sd}ForeArm`],
      wr = W[`${sd}Hand`];
    P(tube(arm.clone().add(V(-0.02 * s, 0.01, 0)), el, 0.068, 0.056, 7, 3), COL.jacket, [`${sd}Shoulder`, `${sd}Arm`, `${sd}ForeArm`], 0.01);
    P(tube(el, wr.clone().lerp(el, -0.05), 0.056, 0.05, 7, 3), COL.jacket, [`${sd}Arm`, `${sd}ForeArm`, `${sd}Hand`], 0.01);
    P(tube(wr.clone().lerp(el, 0.12), wr.clone().lerp(el, -0.04), 0.054, 0.052, 7, 1), COL.jacket2, [`${sd}ForeArm`, `${sd}Hand`], 0.004);
    // glove palm
    const dir = W[`${sd}HandMiddle1`].clone().sub(wr).normalize();
    const pc = wr.clone().addScaledVector(dir, 0.05);
    const pg = new THREE.BoxGeometry(0.03, 0.09, 0.085);
    const q = new THREE.Quaternion().setFromUnitVectors(V(0, -1, 0), dir);
    pg.applyQuaternion(q);
    pg.translate(pc.x, pc.y, pc.z);
    P(pg, COL.glove, [`${sd}Hand`, `${sd}ForeArm`], 0.004);
    for (const f of ['Index', 'Middle', 'Ring', 'Pinky', 'Thumb']) {
      for (let j = 1; j <= 3; j++) {
        const a = W[`${sd}Hand${f}${j}`],
          b = W[`${sd}Hand${f}${j + 1}`];
        const r = f === 'Thumb' ? 0.013 : 0.0115;
        P(tube(a, b, r, r * 0.9, 5, 1), COL.glove, [`${sd}Hand${f}${j}`, ...(j === 1 ? [`${sd}Hand`] : [`${sd}Hand${f}${j - 1}`])], 0.002, 0.04);
      }
    }
  }

  // ---------- legs & boots ----------
  for (const s of [1, -1]) {
    const sd = s > 0 ? 'Left' : 'Right';
    const hip = W[`${sd}UpLeg`],
      kn = W[`${sd}Leg`],
      an = W[`${sd}Foot`];
    P(tube(hip.clone().add(V(0.0, 0.07, 0)), kn, 0.098, 0.074, 8, 4), COL.pants, ['Hips', `${sd}UpLeg`, `${sd}Leg`], 0.012);
    P(tube(kn, an.clone().add(V(0, 0.09, 0)), 0.074, 0.066, 8, 4), COL.pants, [`${sd}UpLeg`, `${sd}Leg`, `${sd}Foot`], 0.012);
    P(ell(kn.clone().add(V(0, 0.01, 0.05)), 0.06, 0.07, 0.035, 0), 0x31353c, [`${sd}Leg`, `${sd}UpLeg`], 0.008);
    // pocket (left thigh like reference)
    if (s > 0) P(box(V(0.17, 0.72, 0.03), 0.02, 0.12, 0.09), 0x26292e, ['LeftUpLeg'], 0.004);
    // boot shaft
    P(tube(an.clone().add(V(0, 0.15, 0)), an.clone().add(V(0, -0.03, 0)), 0.068, 0.07, 8, 2), COL.boot, [`${sd}Leg`, `${sd}Foot`], 0.006);
    P(loft([{ c: an.clone().add(V(0, 0.155, 0)), rx: 0.072, rz: 0.072 }, { c: an.clone().add(V(0, 0.17, 0)), rx: 0.07, rz: 0.07 }], 8, false, false), COL.harness, [`${sd}Leg`], 0.002);
    // foot
    P(box(V(an.x, 0.05, 0.045), 0.1, 0.075, 0.25), COL.boot, [`${sd}Foot`, `${sd}ToeBase`], 0.01);
    P(box(V(an.x, 0.035, 0.17), 0.095, 0.05, 0.08), COL.boot, [`${sd}ToeBase`], 0.008);
    P(box(V(an.x, 0.012, 0.05), 0.108, 0.024, 0.3), COL.sole, [`${sd}Foot`, `${sd}ToeBase`], 0.004);
    for (let k = 0; k < 4; k++) P(box(V(an.x, 0.09 + k * 0.025, 0.07 - k * 0.012), 0.05, 0.006, 0.01, -0.3), COL.lace, [`${sd}Foot`, `${sd}Leg`], 0.001);
  }

  // ---------- backpack ----------
  P(box(V(0, 1.27, -0.215), 0.31, 0.5, 0.2), COL.pack, ['Backpack'], 0.02, 0.06);
  P(ell(V(0, 1.54, -0.215), 0.15, 0.06, 0.1, 1), COL.pack, ['Backpack'], 0.015);
  P(box(V(0, 1.36, -0.32), 0.24, 0.24, 0.04), 0x252930, ['Backpack'], 0.01);
  P(box(V(0, 1.27, -0.318), 0.012, 0.46, 0.012), COL.packTrim, ['Backpack'], 0.002);
  for (const s of [1, -1]) {
    P(box(V(0.165 * s, 1.18, -0.21), 0.04, 0.24, 0.15), 0x262a31, ['Backpack'], 0.01);
    P(box(V(0.158 * s, 1.36, -0.21), 0.012, 0.36, 0.012), COL.packTrim, ['Backpack'], 0.002);
  }
  P(box(V(0, 1.06, -0.2), 0.3, 0.03, 0.17), COL.strap, ['Backpack'], 0.004);

  // ---------- assemble ----------
  const geos: THREE.BufferGeometry[] = [];
  const { root, bones, byName, skeleton } = createSkeleton();
  const allSegs = buildSegments(BONE_WORLD, DEFORM_BONES);
  const segBy = Object.fromEntries(allSegs.map((s) => [s.name, s]));
  const col = new THREE.Color();
  for (const part of parts) {
    let g = part.g.index ? part.g.toNonIndexed() : part.g;
    g.deleteAttribute('normal');
    g.deleteAttribute('uv');
    if (part.jit) jitter(g, part.jit);
    const n = g.attributes.position.count;
    const colors = new Float32Array(n * 3);
    for (let t = 0; t < n; t += 3) {
      const x = g.attributes.position.getX(t),
        y = g.attributes.position.getY(t),
        z = g.attributes.position.getZ(t);
      const v = 1 + (hash(x * 9, y * 9, z * 9) - 0.5) * 2 * (part.facet ?? 0.08);
      col.set(part.color).multiplyScalar(v);
      for (let k = 0; k < 3; k++) {
        colors[(t + k) * 3] = col.r;
        colors[(t + k) * 3 + 1] = col.g;
        colors[(t + k) * 3 + 2] = col.b;
      }
    }
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const cand = part.bones.map((b) => segBy[b]).filter(Boolean);
    computeSkin(g, allSegs, { candidates: () => cand, falloff: 0.05 });
    g.computeVertexNormals();
    geos.push(g);
    g = null as any;
  }
  const merged = mergeGeometries(geos)!;
  merged.computeBoundingSphere();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.82, metalness: 0.02 });
  const mesh = new THREE.SkinnedMesh(merged, mat);
  mesh.name = 'Protagonist_StandIn';
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  const group = new THREE.Group();
  group.name = 'Character';
  group.add(root);
  group.add(mesh);
  mesh.bind(skeleton);

  const axe = buildIceAxe();
  attachAxeToPack(axe, byName);
  return { group, mesh, skeleton, bones: byName, axe, triangles: merged.attributes.position.count / 3 + 0 * bones.length };
}

export function attachAxeToPack(axe: THREE.Object3D, bones: Record<string, THREE.Bone>) {
  bones.IceAxe_Pack.add(axe);
  axe.position.set(0, 0, 0);
  axe.rotation.set(0, Math.PI / 2, 0.08);
}

export function attachAxeToHand(axe: THREE.Object3D, bones: Record<string, THREE.Bone>, side: 'Left' | 'Right' = 'Right') {
  const hand = bones[`${side}Hand`];
  hand.add(axe);
  const dir = BONE_WORLD[`${side}HandMiddle1`].clone().sub(BONE_WORLD[`${side}Hand`]).normalize();
  axe.position.copy(dir.multiplyScalar(0.06));
  axe.rotation.set(Math.PI / 2, 0, 0);
  axe.translateY(0.2);
}
