import * as THREE from 'three';
import { CharacterAnimator } from './animator';
import { CharacterModel } from './model';
import { attachAxeToHand, attachAxeToPack } from './standIn';

export interface AvatarHand {
  gripped: boolean;
  reaching: boolean;
  pos: THREE.Vector3;
  mat: string;
}

export interface AvatarInput {
  dt: number;
  state: 'ground' | 'air' | 'climb' | 'dead';
  pos: THREE.Vector3; // body centre (player capsule)
  vel: THREE.Vector3;
  face: THREE.Vector3; // horizontal facing
  R: THREE.Vector3;
  U: THREE.Vector3;
  F: THREE.Vector3;
  hands: [AvatarHand, AvatarHand];
  gripped: number;
  slope: number;
  surfMat: string;
  wind: THREE.Vector3;
  windSpeed: number;
  temp: number;
  stamina: number;
  exhausted: boolean;
  nearFire: boolean;
  crouch: boolean;
  moveInput: boolean;
  ropeCaught: boolean;
  anchor: THREE.Vector3 | null;
  lookDir: THREE.Vector3;
  ground: (x: number, z: number) => number;
  project: (p: THREE.Vector3, offset: number, out: THREE.Vector3) => THREE.Vector3;
  axe: boolean;
  crampons: boolean;
  lamp: boolean;
}

const IDLE_ACTS = ['look_around', 'check_equipment', 'adjust_backpack'];

/** Gameplay driver: maps the player simulation onto the animation state machine + IK. */
export class CharacterAvatar {
  animator: CharacterAnimator;
  lamp: THREE.SpotLight;
  private yaw = 0;
  private idleT = 0;
  private lastState = 'ground';
  private prevSpeed = 0;
  private turning = 0;
  private snow = 0;
  private wind = 0;
  private careful = 0;
  private sitting = false;
  private crouched = false;
  private mantle: { from: THREE.Vector3; offset: THREE.Vector3 | null; endY: number; endZ: number } | null = null;
  private footHold: [THREE.Vector3 | null, THREE.Vector3 | null] = [null, null];
  private footStep: { i: number; from: THREE.Vector3; to: THREE.Vector3; t: number } | null = null;
  private ikDip = { L: 0, R: 0 };
  private axeInHand = false;
  private lastObjPos = new THREE.Vector3();
  private tmp = new THREE.Vector3();
  private m = new THREE.Matrix4();
  private deadT = 0;

  constructor(public model: CharacterModel) {
    this.animator = new CharacterAnimator(model);
    this.lamp = new THREE.SpotLight(0xfff2d0, 0, 60, 0.6, 0.5, 1.2);
    const tgt = new THREE.Object3D();
    tgt.position.set(0, -2, 10);
    model.bones.HeadLamp.add(this.lamp, tgt);
    this.lamp.target = tgt;
  }

  get object() {
    return this.model.object;
  }

  trigger(ev: string, data: any = {}) {
    const a = this.animator;
    switch (ev) {
      case 'jump':
        a.setState('jump', 0.08, { next: 'fall', nextFade: 0.35 });
        break;
      case 'dyno':
        a.setState('jump', 0.06, { next: 'fall', nextFade: 0.3, timeScale: 1.3 });
        break;
      case 'landed':
        if (data.fell > 5) a.setState('land_hard', 0.06, { next: 'loco', nextFade: 0.35, timeScale: data.fell > 12 ? 0.9 : 1.2 });
        else if (data.fell > 0.6) a.setState('land', 0.06, { next: 'loco', nextFade: 0.25 });
        break;
      case 'slip':
        a.overlay('slip_recover', 'full', 0.55, 0.06, true);
        break;
      case 'mantle':
        this.mantle = { from: this.lastObjPos.clone(), offset: null, endY: 0, endZ: 0 };
        break;
      case 'piton':
        if (this.lastState === 'climb') {
          a.overlay('place_piton_wall', 'rightArm', 0.95, 0.12, true);
          this.ikDip.R = 1.6;
        } else a.setState('place_piton_ground', 0.2, { next: 'loco', nextFade: 0.35 });
        break;
      case 'eat':
        if (this.lastState === 'ground') a.overlay('use_item', 'upper', 0.9, 0.2, true);
        break;
      case 'grab':
        if (data.mat === 'ice' && data.axe) {
          a.overlay('ice_axe_swing', data.hand === 0 ? 'leftArm' : 'rightArm', 0.9, 0.05, true);
          if (data.hand === 0) this.ikDip.L = 0.55;
          else this.ikDip.R = 0.55;
        }
        break;
      case 'respawn':
        a.setState('loco', 0.01, { restart: true });
        a.stopAllOverlays(0.01);
        this.footHold = [null, null];
        this.mantle = null;
        this.deadT = 0;
        a.timeScale = 1;
        break;
    }
  }

  update(i: AvatarInput) {
    const a = this.animator;
    const obj = this.model.object;
    const dt = i.dt;
    this.ikDip.L = Math.max(0, this.ikDip.L - dt);
    this.ikDip.R = Math.max(0, this.ikDip.R - dt);
    const hs = Math.hypot(i.vel.x, i.vel.z);

    // ---- surface/survival modifiers
    const k = Math.min(1, dt * 3);
    this.snow += ((i.surfMat === 'snow' ? 1 : 0) - this.snow) * k;
    this.careful += ((i.surfMat === 'ice' && !i.crampons ? 1 : 0) - this.careful) * k;
    let head = 0;
    if (hs > 0.3 && i.windSpeed > 12) {
      const d = (i.vel.x * i.wind.x + i.vel.z * i.wind.z) / (hs * i.windSpeed);
      head = Math.max(0, -d + 0.2) * Math.min(1, (i.windSpeed - 12) / 14);
    }
    this.wind += (Math.min(1, head) - this.wind) * k;
    a.breath = Math.min(1, 0.15 + (1 - i.stamina / 100) * 0.85);
    a.shiver = Math.max(0, Math.min(1, (36.2 - i.temp) / 2));

    if (i.state === 'dead') {
      if (this.lastState !== 'dead') {
        a.setState('land_hard', 0.15, { once: true, next: 'land_hard' });
        a.stopAllOverlays();
        this.deadT = 0;
      }
      this.deadT += dt;
      a.timeScale = this.deadT > 0.35 ? 0.02 : 1;
      this.lastState = 'dead';
      a.update(dt);
      return;
    }
    a.timeScale = 1;

    // ---- axe prop (stand-in only): in hand on ice walls
    const wantAxe = i.state === 'climb' && i.axe && (i.hands[0].mat === 'ice' || i.hands[1].mat === 'ice');
    if (this.model.axe && wantAxe !== this.axeInHand) {
      this.axeInHand = wantAxe;
      if (wantAxe) attachAxeToHand(this.model.axe, this.model.bones, 'Right');
      else attachAxeToPack(this.model.axe, this.model.bones);
    }
    if (this.model.axe) this.model.axe.visible = i.axe;

    if (i.state === 'climb') this.updateClimb(i);
    else this.updateGroundAir(i, hs);

    // ---- mantle visual blend (root motion driven)
    if (this.mantle) {
      if (!this.mantle.offset) {
        this.mantle.offset = this.mantle.from.clone().sub(obj.position);
        a.setState('mantle', 0.08, { next: 'loco', nextFade: 0.3, timeScale: 1.25 });
        const d = a.lib.get('mantle')!;
        const pt = d.clip.tracks.find((t) => t.name === 'Root.position')!;
        const end = pt.values.slice(-3);
        this.mantle.endY = end[1];
        this.mantle.endZ = end[2];
      }
      if (a.state === 'mantle') {
        const d = a.lib.get('mantle')!;
        const pt = d.clip.tracks.find((t) => t.name === 'Root.position')!;
        const v = pt.createInterpolant().evaluate(a.actions.get('mantle')!.time) as unknown as number[];
        const fy = Math.min(1, v[1] / this.mantle.endY);
        const fz = Math.min(1, v[2] / this.mantle.endZ);
        const off = this.mantle.offset;
        obj.position.x += off.x * (1 - fz);
        obj.position.z += off.z * (1 - fz);
        obj.position.y += off.y * (1 - fy);
        a.ground = null;
      } else this.mantle = null;
    }
    obj.updateMatrixWorld(true);
    this.lastObjPos.copy(obj.position);
    a.update(dt);
    this.lamp.intensity = i.lamp ? 90 : 0;
    this.lastState = i.state;
  }

  private updateGroundAir(i: AvatarInput, hs: number) {
    const a = this.animator;
    const obj = this.model.object;
    a.hand.L.target = a.hand.R.target = null;
    a.foot.L.target = a.foot.R.target = null;
    this.footHold = [null, null];
    if (i.ropeCaught && i.state === 'air') {
      // rope-assisted climbing
      if (a.state !== 'rope_climb') a.setState('rope_climb', 0.3);
      const act = a.actions.get('rope_climb')!;
      act.timeScale = Math.max(0.15, Math.min(1.6, Math.abs(i.vel.y) * 2.2 + (i.moveInput ? 0.6 : 0.15)));
      const up = i.anchor ? i.anchor.clone().sub(i.pos).normalize() : new THREE.Vector3(0, 1, 0);
      const fwd = i.F.clone().addScaledVector(up, -i.F.dot(up)).normalize();
      if (fwd.lengthSq() < 0.01) fwd.copy(i.face);
      const left = up.clone().cross(fwd).normalize();
      this.m.makeBasis(left, up, fwd);
      obj.quaternion.setFromRotationMatrix(this.m);
      obj.position.copy(i.pos).addScaledVector(up, -0.95);
      a.ground = null;
      a.lookWeight = 0;
      return;
    }
    // orientation with turn-in-place
    const targetYaw = Math.atan2(i.face.x, i.face.z);
    let diff = Math.atan2(Math.sin(targetYaw - this.yaw), Math.cos(targetYaw - this.yaw));
    if (i.state === 'ground' && a.state === 'loco' && Math.abs(diff) > 2.6 && hs < 2.5 && this.turning === 0) {
      this.turning = Math.sign(diff) || 1;
      a.setState('turn_180', 0.12, { next: 'loco', nextFade: 0.2, timeScale: 1.25 });
    }
    if (a.state === 'turn_180' && this.turning !== 0) {
      const prog = Math.min(1, a.stateProgress());
      const startYaw = targetYaw - this.turning * Math.PI;
      const curve = prog * prog * (3 - 2 * prog);
      this.yaw = startYaw + this.turning * Math.PI * curve;
      if (prog >= 0.98) this.turning = 0;
    } else {
      this.turning = 0;
      const rate = i.state === 'air' ? 4 : 11;
      diff = Math.atan2(Math.sin(targetYaw - this.yaw), Math.cos(targetYaw - this.yaw));
      this.yaw += diff * Math.min(1, rate * i.dt);
    }
    obj.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    const gy = i.ground(i.pos.x, i.pos.z);
    obj.position.set(i.pos.x, i.state === 'ground' ? gy : i.pos.y - 0.95, i.pos.z);
    // locomotion parameters (local frame)
    const inv = -this.yaw;
    const lx = i.vel.x * Math.cos(inv) + i.vel.z * Math.sin(inv);
    const lz = -i.vel.x * Math.sin(inv) + i.vel.z * Math.cos(inv);
    a.loco.speed = hs;
    if (hs > 0.05) {
      a.loco.dirX = lx;
      a.loco.dirZ = lz;
    }
    a.loco.snow = this.snow;
    a.loco.wind = this.wind;
    a.loco.careful = this.careful;

    if (i.state === 'air') {
      a.ground = null;
      if (this.lastState === 'ground' && i.vel.y > 2.5 && a.state !== 'jump') this.trigger('jump');
      if (a.state !== 'jump' && a.state !== 'fall' && (i.vel.y < -3.5 || this.lastState === 'climb')) a.setState('fall', 0.3);
      a.lookWeight = 0;
      return;
    }
    // ---- ground
    a.ground = i.ground;
    a.groundIK = 1;
    if (a.state === 'fall' || a.state === 'jump' || a.state === 'rope_climb' || this.lastState === 'climb') {
      if (a.state !== 'land' && a.state !== 'land_hard' && a.state !== 'mantle') a.setState('loco', 0.25);
    }
    const moving = hs > 0.25 || i.moveInput;
    this.idleT = moving ? 0 : this.idleT + i.dt;
    // crouch
    if (i.crouch && !this.crouched) {
      this.crouched = true;
      a.setState('crouch_down', 0.12, { next: 'crouch', nextFade: 0.15 });
    } else if (!i.crouch && this.crouched) {
      this.crouched = false;
      a.setState('stand_up', 0.1, { next: 'loco', nextFade: 0.2 });
    }
    if (this.crouched) {
      a.lookWeight = 0.4;
      a.look = this.tmp.copy(i.pos).addScaledVector(i.lookDir, 10).clone();
      this.prevSpeed = hs;
      return;
    }
    const busy = ['land', 'land_hard', 'turn_180', 'mantle', 'place_piton_ground', 'stand_up', 'crouch_down', 'walk_stop', 'walk_start', 'jump'].includes(a.state);
    if (!busy) {
      if (moving) {
        if (this.sitting || IDLE_ACTS.includes(a.state) || ['catch_breath', 'cold_idle', 'rest_sit', 'sit_down'].includes(a.state)) {
          this.sitting = false;
          a.setState('loco', this.sitting ? 0.6 : 0.3);
        } else if (a.state === 'loco' && this.prevSpeed < 0.15 && i.moveInput && hs < 1.2) {
          a.setState('walk_start', 0.15, { next: 'loco', nextFade: 0.25, timeScale: 1.3 });
        }
      } else {
        if (a.state === 'loco' && this.prevSpeed > 1.1 && hs < 0.4) a.setState('walk_stop', 0.18, { next: 'loco', nextFade: 0.3, timeScale: this.prevSpeed > 3 ? 1.3 : 1 });
        else if (i.nearFire && this.idleT > 2.5 && i.stamina < 99.5 && !this.sitting) {
          this.sitting = true;
          a.setState('sit_down', 0.3, { next: 'rest_sit', nextFade: 0.4 });
        } else if (!this.sitting) {
          let want = 'loco';
          if (i.temp < 35.4) want = 'cold_idle';
          else if (i.exhausted || i.stamina < 28) want = 'catch_breath';
          if (want !== 'loco' && a.state !== want) a.setState(want, 0.45);
          else if (want === 'loco' && (a.state === 'cold_idle' || a.state === 'catch_breath')) a.setState('loco', 0.5);
          else if (want === 'loco' && a.state === 'loco' && this.idleT > 9) {
            this.idleT = 0;
            a.setState(IDLE_ACTS[Math.floor(Math.random() * IDLE_ACTS.length)], 0.4, { next: 'loco', nextFade: 0.5 });
          }
        }
      }
    }
    this.prevSpeed = hs;
    // head look follows the camera direction
    const ld = i.lookDir.clone();
    ld.y = Math.max(-0.5, Math.min(0.5, ld.y));
    a.look = this.tmp.copy(i.pos).addScaledVector(ld, 10).clone();
    a.lookWeight = hs > 5 || IDLE_ACTS.includes(a.state) || a.state === 'rest_sit' ? 0 : 0.7;
  }

  private updateClimb(i: AvatarInput) {
    const a = this.animator;
    const obj = this.model.object;
    const left = i.R.clone().negate();
    this.m.makeBasis(left, i.U, i.F);
    obj.quaternion.setFromRotationMatrix(this.m);
    obj.position.copy(i.pos).addScaledVector(i.U, -1.0);
    this.yaw = Math.atan2(i.F.x, i.F.z);
    a.ground = null;
    const overhang = i.slope > 4.5;
    const base = i.gripped === 1 ? (overhang ? 'hang_one_arm' : 'climb_idle') : overhang ? 'hang' : 'climb_idle';
    if (a.state !== base && a.state !== 'mantle') a.setState(base, this.lastState === 'climb' ? 0.35 : 0.15);
    // hands → holds
    (['L', 'R'] as const).forEach((k, idx) => {
      const h = i.hands[idx];
      const tgt = h.gripped || h.reaching ? h.pos : null;
      a.hand[k].target = tgt ? tgt.clone() : null;
      a.hand[k].weight = this.ikDip[k] > 0 ? 0.15 : 1;
    });
    // feet → procedural footholds on the wall
    const legsActive = !overhang && i.gripped > 0;
    for (let f = 0; f < 2; f++) {
      const side = f === 0 ? -1 : 1; // left = -R
      const desired = i.pos.clone().addScaledVector(i.U, -0.82 + (f === 0 ? 0.12 : -0.05)).addScaledVector(i.R, side * 0.2);
      i.project(desired, 0.12, desired);
      if (!this.footHold[f]) this.footHold[f] = desired.clone();
      const d = this.footHold[f]!.distanceTo(desired);
      if (!this.footStep && d > 0.38) this.footStep = { i: f, from: this.footHold[f]!.clone(), to: desired.clone(), t: 0 };
    }
    if (this.footStep) {
      const s = this.footStep;
      s.t += i.dt / 0.32;
      const t = Math.min(1, s.t);
      const e = t * t * (3 - 2 * t);
      const p = s.from.clone().lerp(s.to, e);
      p.addScaledVector(i.F, -Math.sin(Math.PI * t) * 0.14);
      this.footHold[s.i] = p;
      if (t >= 1) {
        this.footHold[s.i] = s.to.clone();
        this.footStep = null;
      }
    }
    a.foot.L.target = legsActive ? this.footHold[0] : null;
    a.foot.R.target = legsActive ? this.footHold[1] : null;
    a.foot.L.weight = a.foot.R.weight = legsActive ? 1 : 0;
    // look at the reaching hand
    const reach = i.hands.find((h) => h.reaching);
    a.look = reach ? reach.pos.clone() : i.pos.clone().addScaledVector(i.U, 2).addScaledVector(i.F, 1);
    a.lookWeight = 0.8;
  }

  dispose() {
    this.animator.dispose();
  }
}
