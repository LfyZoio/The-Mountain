import * as THREE from 'three';
import { ClipDef, getClipLibrary, maskClip } from './clips';
import { CharacterModel } from './model';
import { createSkeleton } from './skeleton';
import { solveTwoBone, applyWorldDelta } from './ik';

export interface LocoParams {
  speed: number; // m/s (horizontal)
  dirX: number; // local move direction (+X = character's left)
  dirZ: number; // local move direction (+Z = forward)
  snow: number; // 0..1
  wind: number; // 0..1 head-wind
  careful: number; // 0..1 (ice)
}

export type OverlayMask = 'upper' | 'head' | 'leftArm' | 'rightArm' | 'full';

const LOCO = ['idle', 'walk_forward', 'walk_backward', 'strafe_left', 'strafe_right', 'run', 'sprint', 'walk_snow', 'walk_wind', 'walk_careful'];
const CROUCH = ['crouch_idle', 'crouch_walk'];

const UPPER = new Set<string>();
const HEAD = new Set(['Neck', 'Head']);
const ARM_L = new Set<string>();
const ARM_R = new Set<string>();

interface Overlay {
  name: string;
  action: THREE.AnimationAction;
  w: number;
  target: number;
  rate: number;
  once: boolean;
  dur: number;
}

/** measures in-place cycle speed from the stance foot (prevents foot sliding) */
function measureSpeed(def: ClipDef): number {
  const { root, byName } = createSkeleton();
  const g = new THREE.Group();
  g.add(root);
  const mixer = new THREE.AnimationMixer(g);
  const a = mixer.clipAction(def.inPlace);
  a.play();
  const N = 120;
  const axis = def.speedAxis ?? 'z';
  const v = new THREE.Vector3();
  const samp: { y: number[]; p: number[] }[] = [
    { y: [], p: [] },
    { y: [], p: [] },
  ];
  for (let i = 0; i <= N; i++) {
    a.time = (i / N) * def.inPlace.duration;
    mixer.update(0);
    g.updateMatrixWorld(true);
    ['LeftFoot', 'RightFoot'].forEach((f, k) => {
      byName[f].getWorldPosition(v);
      samp[k].y.push(v.y);
      samp[k].p.push(axis.endsWith('x') ? v.x : v.z);
    });
  }
  // support foot = the lower foot at each instant; its backward velocity = travel speed
  const vel: number[] = [];
  const dt = def.inPlace.duration / N;
  for (let i = 0; i < N; i++) {
    const k = samp[0].y[i] <= samp[1].y[i] ? 0 : 1;
    let d = -(samp[k].p[i + 1] - samp[k].p[i]) / dt;
    if (axis.startsWith('-')) d = -d;
    vel.push(d);
  }
  vel.sort((x, y) => x - y);
  const tot = vel[Math.floor(vel.length / 2)];
  const cnt = 1;
  mixer.stopAllAction();
  return cnt ? Math.max(0.3, tot / cnt) : 1.4;
}

export class CharacterAnimator {
  mixer: THREE.AnimationMixer;
  lib = new Map<string, ClipDef>();
  actions = new Map<string, THREE.AnimationAction>();
  state = 'loco';
  stateW = new Map<string, number>();
  private fade = 0.25;
  private onceEnd: { next: string; fade: number; cb?: () => void } | null = null;
  overlays: Overlay[] = [];
  loco: LocoParams = { speed: 0, dirX: 0, dirZ: 1, snow: 0, wind: 0, careful: 0 };
  phase = 0;
  timeScale = 1;
  // procedural layers
  breath = 0.3;
  shiver = 0;
  private time = 0;
  // IK
  hand = { L: { target: null as THREE.Vector3 | null, weight: 0, w: 0 }, R: { target: null as THREE.Vector3 | null, weight: 0, w: 0 } };
  foot = { L: { target: null as THREE.Vector3 | null, weight: 0, w: 0 }, R: { target: null as THREE.Vector3 | null, weight: 0, w: 0 } };
  ground: ((x: number, z: number) => number) | null = null;
  groundIK = 1;
  private pelvisDrop = 0;
  look: THREE.Vector3 | null = null;
  lookWeight = 0;
  private lookW = 0;
  // backpack spring
  private packPrev = new THREE.Vector3();
  private packVel = new THREE.Vector3();
  private packAng = new THREE.Vector2();
  private packAngV = new THREE.Vector2();
  private packInit = false;
  // root motion
  rootDelta = { p: new THREE.Vector3(), yaw: 0 };
  private rootPrevT = new Map<string, number>();
  private bind = new Map<THREE.Bone, { p: THREE.Vector3; q: THREE.Quaternion }>();
  private masked = new Map<string, THREE.AnimationClip>();

  constructor(public model: CharacterModel) {
    this.mixer = new THREE.AnimationMixer(model.rigRoot);
    for (const b of Object.values(model.bones)) this.bind.set(b, { p: b.position.clone(), q: b.quaternion.clone() });
    if (UPPER.size === 0) {
      for (const n of Object.keys(model.bones)) {
        if (/^(Spine1|Spine2|Neck|Head|Backpack)$/.test(n) || /Shoulder|Arm|Hand/.test(n)) UPPER.add(n);
        if (/^Left(Shoulder|Arm|ForeArm|Hand)/.test(n)) ARM_L.add(n);
        if (/^Right(Shoulder|Arm|ForeArm|Hand)/.test(n)) ARM_R.add(n);
      }
    }
    for (const d of getClipLibrary()) {
      if (d.speedAxis && d.nominalSpeed == null) d.nominalSpeed = measureSpeed(d);
      this.lib.set(d.name, d);
      const a = this.mixer.clipAction(d.inPlace);
      a.setLoop(d.loop ? THREE.LoopRepeat : THREE.LoopOnce, Infinity);
      a.clampWhenFinished = !d.loop;
      a.enabled = true;
      a.setEffectiveWeight(0);
      this.actions.set(d.name, a);
    }
    this.stateW.set('loco', 1);
    for (const n of LOCO) this.actions.get(n)!.play();
  }

  get clips() {
    return [...this.lib.values()];
  }

  // ------------------------------------------------------------ control
  /** switch the base state ('loco' | 'crouch' | clip name) with crossfade */
  setState(name: string, fade = 0.25, opts: { once?: boolean; next?: string; nextFade?: number; onEnd?: () => void; restart?: boolean; timeScale?: number } = {}) {
    const isGroup = name === 'loco' || name === 'crouch';
    if (!isGroup && !this.lib.has(name)) return;
    if (this.state === name && !opts.restart) return;
    this.state = name;
    this.fade = Math.max(0.01, fade);
    if (!this.stateW.has(name)) this.stateW.set(name, 0);
    if (!isGroup) {
      const d = this.lib.get(name)!;
      const a = this.actions.get(name)!;
      const w = this.stateW.get(name) ?? 0;
      if (opts.restart || w < 0.05 || !d.loop) {
        a.reset();
        this.rootPrevT.set(name, 0);
      }
      a.timeScale = opts.timeScale ?? 1;
      a.play();
      const once = opts.once ?? !d.loop;
      this.onceEnd = once ? { next: opts.next ?? 'loco', fade: opts.nextFade ?? 0.25, cb: opts.onEnd } : null;
    } else {
      this.onceEnd = null;
      for (const n of name === 'loco' ? LOCO : CROUCH) this.actions.get(n)!.play();
    }
  }

  /** layered partial-body clip (e.g. head turn while walking, piton hammering while hanging) */
  overlay(name: string, mask: OverlayMask = 'upper', fraction = 0.85, fadeIn = 0.2, once?: boolean) {
    const d = this.lib.get(name);
    if (!d) return;
    const key = `${name}@${mask}`;
    let clip = this.masked.get(key);
    if (!clip) {
      const set = mask === 'upper' ? UPPER : mask === 'head' ? HEAD : mask === 'leftArm' ? ARM_L : mask === 'rightArm' ? ARM_R : null;
      clip = set ? maskClip(d.inPlace, set, '@' + mask) : d.inPlace;
      this.masked.set(key, clip);
    }
    const existing = this.overlays.find((o) => o.name === key);
    const action = existing?.action ?? this.mixer.clipAction(clip);
    action.reset();
    const isOnce = once ?? !d.loop;
    action.setLoop(isOnce ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
    action.clampWhenFinished = isOnce;
    action.play();
    const f = Math.min(0.97, fraction);
    if (existing) {
      existing.target = f;
      existing.once = isOnce;
    } else this.overlays.push({ name: key, action, w: 0, target: f, rate: 1 / Math.max(0.01, fadeIn), once: isOnce, dur: clip.duration });
  }

  stopOverlay(name: string, fadeOut = 0.25) {
    for (const o of this.overlays) if (o.name.startsWith(name + '@') || o.name === name) {
      o.target = 0;
      o.rate = 1 / Math.max(0.01, fadeOut);
    }
  }

  stopAllOverlays(fadeOut = 0.2) {
    for (const o of this.overlays) {
      o.target = 0;
      o.rate = 1 / fadeOut;
    }
  }

  stateProgress(): number {
    const d = this.lib.get(this.state);
    if (!d) return 0;
    return this.actions.get(this.state)!.time / d.inPlace.duration;
  }

  // ------------------------------------------------------------ weights
  private locoWeights(out: Map<string, number>) {
    const L = this.loco;
    const s = Math.max(0, L.speed);
    const vW = this.lib.get('walk_forward')!.nominalSpeed!;
    const vR = this.lib.get('run')!.nominalSpeed!;
    const vS = this.lib.get('sprint')!.nominalSpeed!;
    let idle = 0,
      walk = 0,
      run = 0,
      sprint = 0;
    if (s < 0.05) idle = 1;
    else if (s < vW) {
      walk = s / vW;
      idle = 1 - walk;
    } else if (s < vR) {
      run = (s - vW) / (vR - vW);
      walk = 1 - run;
    } else if (s < vS) {
      sprint = (s - vR) / (vS - vR);
      run = 1 - sprint;
    } else sprint = 1;
    let dx = L.dirX,
      dz = L.dirZ;
    const dl = Math.hypot(dx, dz) || 1;
    dx /= dl;
    dz /= dl;
    const wF = dz > 0 ? dz * dz : 0,
      wB = dz < 0 ? dz * dz : 0,
      wL = dx > 0 ? dx * dx : 0,
      wR = dx < 0 ? dx * dx : 0;
    const m = 1 - idle;
    out.set('idle', idle);
    // forward walk variants
    const vs = Math.min(1, L.snow),
      vw = Math.min(1, L.wind) * (1 - vs * 0.5),
      vc = Math.min(1, L.careful);
    const base = Math.max(0, 1 - vs - vw - vc);
    const vt = base + vs + vw + vc || 1;
    const fw = walk * wF;
    const runShift = (vs * 0.45 + vw * 0.55 + vc * 0.35) * (run + sprint) * wF;
    out.set('walk_forward', (fw * base) / vt);
    out.set('walk_snow', (fw * vs) / vt + runShift * (vs / (vs + vw + vc || 1)));
    out.set('walk_wind', (fw * vw) / vt + runShift * (vw / (vs + vw + vc || 1)));
    out.set('walk_careful', (fw * vc) / vt + runShift * (vc / (vs + vw + vc || 1)));
    const runKeep = 1 - Math.min(1, vs * 0.45 + vw * 0.55 + vc * 0.35);
    out.set('run', run * wF * runKeep);
    out.set('sprint', sprint * wF * runKeep);
    out.set('walk_backward', m * wB);
    out.set('strafe_left', m * wL);
    out.set('strafe_right', m * wR);
  }

  private crouchWeights(out: Map<string, number>) {
    const vC = this.lib.get('crouch_walk')!.nominalSpeed!;
    const t = Math.min(1, this.loco.speed / (vC * 0.7));
    out.set('crouch_idle', 1 - t);
    out.set('crouch_walk', t);
  }

  // ------------------------------------------------------------ update
  update(dt: number) {
    dt *= this.timeScale;
    this.time += dt;
    // reset to bind (so procedural layers never accumulate)
    for (const [b, r] of this.bind) {
      b.position.copy(r.p);
      b.quaternion.copy(r.q);
    }
    // state fades
    let sum = 0;
    for (const [k, w] of this.stateW) {
      const target = k === this.state ? 1 : 0;
      const nw = target > w ? Math.min(1, w + dt / this.fade) : Math.max(0, w - dt / this.fade);
      this.stateW.set(k, nw);
      sum += nw;
    }
    if (sum > 0) for (const [k, w] of this.stateW) this.stateW.set(k, w / sum);

    const eff = new Map<string, number>();
    const inner = new Map<string, number>();
    for (const [k, sw] of this.stateW) {
      if (sw <= 0) continue;
      inner.clear();
      if (k === 'loco') this.locoWeights(inner);
      else if (k === 'crouch') this.crouchWeights(inner);
      else inner.set(k, 1);
      for (const [n, w] of inner) eff.set(n, (eff.get(n) ?? 0) + w * sw);
    }
    // phase-synchronised cycles
    let rate = 0,
      wsum = 0;
    for (const [n, w] of eff) {
      const d = this.lib.get(n)!;
      if (!d.phaseSync || w <= 0.001) continue;
      const ratio = Math.max(0.55, Math.min(2.0, this.loco.speed / (d.nominalSpeed || 1)));
      rate += (w * ratio) / d.inPlace.duration;
      wsum += w;
    }
    if (wsum > 0) this.phase = (this.phase + (dt * rate) / wsum) % 1;
    for (const [n, a] of this.actions) {
      const w = eff.get(n) ?? 0;
      const d = this.lib.get(n)!;
      a.setEffectiveWeight(w);
      if (w > 0 && !a.isRunning() && d.loop) a.play();
      if (d.phaseSync) {
        a.timeScale = 0;
        a.time = this.phase * d.inPlace.duration;
      }
    }
    // overlays
    for (const o of this.overlays) {
      if (o.once && o.action.time >= o.dur - 0.25) o.target = 0;
      o.w = o.target > o.w ? Math.min(o.target, o.w + dt * o.rate) : Math.max(o.target, o.w - dt * o.rate);
      o.action.setEffectiveWeight(o.w > 0 ? o.w / (1 - o.w) : 0);
    }
    this.overlays = this.overlays.filter((o) => {
      if (o.w <= 0 && o.target <= 0) {
        o.action.stop();
        return false;
      }
      return true;
    });

    // one-shot end → next state
    if (this.onceEnd && this.lib.has(this.state)) {
      const d = this.lib.get(this.state)!;
      const a = this.actions.get(this.state)!;
      const end = d.inPlace.duration - this.onceEnd.fade * 0.9;
      if (a.time >= end || (!a.isRunning() && a.time > 0)) {
        const nx = this.onceEnd;
        this.onceEnd = null;
        nx.cb?.();
        if (this.state === d.name) this.setState(nx.next, nx.fade);
      }
    }

    this.mixer.update(dt);
    this.computeRootMotion();
    this.model.rigRoot.updateMatrixWorld(true);
    this.post(dt);
  }

  private computeRootMotion() {
    this.rootDelta.p.set(0, 0, 0);
    this.rootDelta.yaw = 0;
    const d = this.lib.get(this.state);
    if (!d || !d.rootMotion) return;
    const a = this.actions.get(this.state)!;
    const pt = d.clip.tracks.find((t) => t.name === 'Root.position');
    const qt = d.clip.tracks.find((t) => t.name === 'Root.quaternion');
    if (!pt) return;
    const prev = this.rootPrevT.get(d.name) ?? 0;
    const cur = a.time;
    const ev = (t: number) => {
      const p = pt.createInterpolant().evaluate(t) as unknown as Float32Array;
      const q = qt ? (qt.createInterpolant().evaluate(t) as unknown as Float32Array) : null;
      const yaw = q ? 2 * Math.atan2(q[1], q[3]) : 0;
      return { p: new THREE.Vector3(p[0], p[1], p[2]), yaw };
    };
    if (cur >= prev) {
      const A = ev(prev),
        B = ev(cur);
      this.rootDelta.p.subVectors(B.p, A.p);
      this.rootDelta.yaw = B.yaw - A.yaw;
    } else {
      const A = ev(prev),
        E = ev(d.clip.duration),
        S = ev(0),
        B = ev(cur);
      this.rootDelta.p.subVectors(E.p, A.p).add(B.p.sub(S.p));
      this.rootDelta.yaw = E.yaw - A.yaw + (B.yaw - S.yaw);
    }
    this.rootPrevT.set(d.name, cur);
  }

  // ------------------------------------------------------------ post-processing (procedural + IK)
  private post(dt: number) {
    const b = this.model.bones;
    // bind-pose corrections (imported models with a different arm angle)
    for (const [n, q] of this.model.corrections) b[n]?.quaternion.multiply(q);
    // breathing & shiver
    const br = Math.sin(this.time * (1.4 + this.breath * 2.2) * Math.PI);
    const amp = (0.6 + this.breath * 2.4) * (Math.PI / 180);
    b.Spine1.rotateX(br * amp * 0.6);
    b.Spine2.rotateX(br * amp * 0.5);
    b.LeftShoulder.rotateZ(br * amp * 0.4);
    b.RightShoulder.rotateZ(-br * amp * 0.4);
    if (this.shiver > 0.01) {
      const s = this.shiver * 0.03;
      b.Spine1.rotateZ(Math.sin(this.time * 71) * s);
      b.Spine2.rotateX(Math.sin(this.time * 63) * s);
      b.Head.rotateY(Math.sin(this.time * 57) * s);
      b.LeftArm.rotateX(Math.sin(this.time * 67) * s);
      b.RightArm.rotateX(Math.sin(this.time * 73) * s);
    }
    this.model.rigRoot.updateMatrixWorld(true);
    this.footIK(dt);
    this.limbIK(dt);
    this.headLook(dt);
    this.backpack(dt);
    // IK target bones follow effectors (exported, UE-style)
    const root = b.Root;
    const tmp = new THREE.Vector3();
    const setIk = (ik: string, src: string) => {
      b[src].getWorldPosition(tmp);
      b[ik].position.copy(root.worldToLocal(tmp));
    };
    setIk('ik_hand_l', 'LeftHand');
    setIk('ik_hand_r', 'RightHand');
    setIk('ik_foot_l', 'LeftFoot');
    setIk('ik_foot_r', 'RightFoot');
    this.model.rigRoot.updateMatrixWorld(true);
    this.model.retarget?.apply();
  }

  private objAxes() {
    const q = new THREE.Quaternion();
    this.model.object.getWorldQuaternion(q);
    return {
      F: new THREE.Vector3(0, 0, 1).applyQuaternion(q),
      R: new THREE.Vector3(-1, 0, 0).applyQuaternion(q), // character's right
      U: new THREE.Vector3(0, 1, 0).applyQuaternion(q),
    };
  }

  private footIK(dt: number) {
    const b = this.model.bones;
    const { F } = this.objAxes();
    const g = this.ground;
    const legs: ['L' | 'R', string][] = [
      ['L', 'Left'],
      ['R', 'Right'],
    ];
    // explicit foot targets (climbing)
    let explicit = false;
    for (const [k] of legs) {
      const f = this.foot[k];
      f.w += ((f.target ? f.weight : 0) - f.w) * Math.min(1, dt * 10);
      if (f.w > 0.01) explicit = true;
    }
    if (!g && !explicit) return;
    const oy = this.model.object.getWorldPosition(new THREE.Vector3()).y;
    const targets: (THREE.Vector3 | null)[] = [null, null];
    const planted: number[] = [0, 0];
    let minOff = 0;
    if (g && this.groundIK > 0) {
      legs.forEach(([, s], i) => {
        const an = b[`${s}Foot`].getWorldPosition(new THREE.Vector3());
        const toe = b[`${s}ToeBase`].getWorldPosition(new THREE.Vector3());
        const hA = an.y - oy;
        const gy = Math.max(g(an.x, an.z), g(toe.x, toe.z) - 0.02);
        const off = (gy - oy) * this.groundIK;
        targets[i] = an.clone().setY(an.y + off);
        planted[i] = hA < 0.13 ? 1 : Math.max(0, 1 - (hA - 0.13) * 8);
        minOff = Math.min(minOff, off);
      });
    }
    const drop = Math.max(-0.5, minOff);
    this.pelvisDrop += (drop - this.pelvisDrop) * Math.min(1, dt * 12);
    if (Math.abs(this.pelvisDrop) > 1e-4) {
      const s = this.model.rigRoot.getWorldScale(new THREE.Vector3()).y || 1;
      b.Hips.position.y += this.pelvisDrop / s;
      this.model.rigRoot.updateMatrixWorld(true);
    }
    legs.forEach(([k, s], i) => {
      const f = this.foot[k];
      const up = b[`${s}UpLeg`],
        lo = b[`${s}Leg`],
        ft = b[`${s}Foot`];
      const knee = lo.getWorldPosition(new THREE.Vector3());
      let tgt = targets[i];
      let w = 1;
      if (f.w > 0.01 && f.target) {
        tgt = tgt ? tgt.clone().lerp(f.target, f.w) : f.target.clone();
        w = tgt === targets[i] ? 1 : Math.max(f.w, targets[i] ? 1 : 0);
      }
      if (!tgt) return;
      const pole = knee.clone().addScaledVector(F, 0.4);
      solveTwoBone(up, lo, ft, tgt, pole, w);
      // align planted foot with the ground slope
      if (g && planted[i] > 0 && f.w < 0.5) {
        const p = ft.getWorldPosition(new THREE.Vector3());
        const e = 0.15;
        const n = new THREE.Vector3(g(p.x - e, p.z) - g(p.x + e, p.z), 2 * e, g(p.x, p.z - e) - g(p.x, p.z + e)).normalize();
        const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), n);
        q.slerp(new THREE.Quaternion(), 1 - planted[i] * 0.85);
        applyWorldDelta(ft, q);
      }
    });
  }

  private limbIK(dt: number) {
    const b = this.model.bones;
    const { F, R, U } = this.objAxes();
    (['L', 'R'] as const).forEach((k) => {
      const h = this.hand[k];
      h.w += ((h.target ? h.weight : 0) - h.w) * Math.min(1, dt * 12);
      if (h.w < 0.01 || !h.target) return;
      const s = k === 'L' ? 'Left' : 'Right';
      const side = k === 'L' ? -1 : 1; // R points to character's right
      const sh = b[`${s}Arm`].getWorldPosition(new THREE.Vector3());
      const pole = sh.clone().addScaledVector(F, -0.5).addScaledVector(R, side * 0.7).addScaledVector(U, -0.5);
      solveTwoBone(b[`${s}Arm`], b[`${s}ForeArm`], b[`${s}Hand`], h.target, pole, h.w);
    });
  }

  private headLook(dt: number) {
    this.lookW += ((this.look ? this.lookWeight : 0) - this.lookW) * Math.min(1, dt * 5);
    if (this.lookW < 0.01 || !this.look) return;
    const b = this.model.bones;
    const head = b.Head;
    const hp = head.getWorldPosition(new THREE.Vector3());
    const hq = head.getWorldQuaternion(new THREE.Quaternion());
    const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(hq);
    const want = this.look.clone().sub(hp).normalize();
    const ang = fwd.angleTo(want);
    const max = (75 * Math.PI) / 180;
    const q = new THREE.Quaternion().setFromUnitVectors(fwd, want);
    const lim = ang > max ? max / ang : 1;
    const qa = new THREE.Quaternion().slerp(q, lim * this.lookW * 0.4);
    applyWorldDelta(b.Neck, qa);
    const qb = new THREE.Quaternion().slerp(q, lim * this.lookW * 0.55);
    applyWorldDelta(head, qb);
  }

  private backpack(dt: number) {
    if (dt <= 0) return;
    const pack = this.model.bones.Backpack;
    const p = pack.getWorldPosition(new THREE.Vector3());
    if (!this.packInit) {
      this.packPrev.copy(p);
      this.packInit = true;
      return;
    }
    const v = p.clone().sub(this.packPrev).divideScalar(dt);
    if (v.length() > 30) v.set(0, 0, 0); // teleport
    const acc = v.clone().sub(this.packVel).divideScalar(dt);
    this.packVel.copy(v);
    this.packPrev.copy(p);
    const inv = pack.parent!.getWorldQuaternion(new THREE.Quaternion()).invert();
    acc.applyQuaternion(inv).clampLength(0, 60);
    const k = 140,
      c = 11,
      gain = 0.0035;
    const fx = -acc.z * gain - acc.y * gain * 0.5;
    const fz = acc.x * gain;
    this.packAngV.x += (-k * this.packAng.x - c * this.packAngV.x + fx * k) * dt;
    this.packAngV.y += (-k * this.packAng.y - c * this.packAngV.y + fz * k) * dt;
    this.packAng.x = Math.max(-0.25, Math.min(0.25, this.packAng.x + this.packAngV.x * dt));
    this.packAng.y = Math.max(-0.2, Math.min(0.2, this.packAng.y + this.packAngV.y * dt));
    pack.rotateX(this.packAng.x);
    pack.rotateZ(this.packAng.y);
    pack.updateMatrixWorld(true);
  }

  dispose() {
    this.mixer.stopAllAction();
    this.mixer.uncacheRoot(this.model.rigRoot);
  }
}
