import * as THREE from 'three';

/** Live retargeter: copies the canonical rig pose onto a foreign humanoid skeleton. */
export interface Retargeter {
  apply(): void;
  targetBones: THREE.Bone[];
  mapped: number;
}

export interface CharacterModel {
  /** add this to the scene; position/rotate it (feet at origin, faces +Z) */
  object: THREE.Group;
  /** group that contains the canonical Root bone (animation mixer root) */
  rigRoot: THREE.Group;
  bones: Record<string, THREE.Bone>;
  skeleton: THREE.Skeleton;
  meshes: THREE.Object3D[];
  axe: THREE.Object3D | null;
  source: 'standin' | 'autorig' | 'retarget';
  name: string;
  triangles: number;
  retarget?: Retargeter;
  /** per-bone rest corrections applied after animation (e.g. different arm angle in the bind pose) */
  corrections: Map<string, THREE.Quaternion>;
  /** object used to draw the skeleton helper */
  helperRoot: THREE.Object3D;
  /** export root (meshes + skeleton actually rendered) */
  exportRoot: THREE.Object3D;
  notes: string[];
}
