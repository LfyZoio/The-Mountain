import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CharacterAnimator } from './animator';
import { CharacterModel } from './model';

export interface LabState {
  mode: 'clip' | 'blend';
  clip: string;
  rootMotion: boolean;
  skeleton: boolean;
  wireframe: boolean;
  props: boolean;
  uneven: boolean;
  handIK: boolean;
  lookAtCam: boolean;
  speed: number;
  fade: number;
  paused: boolean;
  blend: { speed: number; dirX: number; dirZ: number; snow: number; wind: number; careful: number; crouch: boolean; moveWorld: boolean };
}

export class LabScene {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(40, 1, 0.05, 200);
  controls: OrbitControls;
  model: CharacterModel | null = null;
  animator: CharacterAnimator | null = null;
  helper: THREE.SkeletonHelper | null = null;
  st: LabState;
  private raf = 0;
  private last = performance.now();
  private ground: THREE.Mesh;
  private props: Record<string, THREE.Object3D> = {};
  private targets: THREE.Mesh[] = [];
  private finishedT = 0;
  private yaw = 0;
  private time = 0;
  private disposed = false;
  onFrame?: (info: { time: number; dur: number; state: string; fps: number }) => void;
  private fpsAcc = 0;
  private fpsN = 0;
  private fps = 60;

  constructor(private container: HTMLElement, st: LabState) {
    this.st = st;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.cssText = 'width:100%;height:100%;display:block';
    this.scene.background = new THREE.Color(0x1a2230);
    this.scene.fog = new THREE.Fog(0x1a2230, 14, 40);
    const hemi = new THREE.HemisphereLight(0xc8dcff, 0x3a3530, 1.3);
    const key = new THREE.DirectionalLight(0xfff1dc, 3.2);
    key.position.set(3, 6, 4);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    const sc = key.shadow.camera;
    sc.left = sc.bottom = -5;
    sc.right = sc.top = 5;
    key.shadow.bias = -0.0005;
    key.shadow.normalBias = 0.02;
    const rim = new THREE.DirectionalLight(0x8fb8ff, 1.6);
    rim.position.set(-4, 3, -5);
    this.scene.add(hemi, key, key.target, rim);
    (this as any)._key = key;

    // ground (re-meshed for uneven mode)
    const gg = new THREE.PlaneGeometry(40, 40, 160, 160);
    gg.rotateX(-Math.PI / 2);
    const tex = this.gridTexture();
    this.ground = new THREE.Mesh(gg, new THREE.MeshStandardMaterial({ map: tex, roughness: 0.95 }));
    this.ground.receiveShadow = true;
    this.scene.add(this.ground);
    this.buildProps();
    for (let k = 0; k < 2; k++) {
      const m = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), new THREE.MeshBasicMaterial({ color: k ? 0xff7a45 : 0x45c2ff }));
      m.visible = false;
      this.targets.push(m);
      this.scene.add(m);
    }

    this.camera.position.set(2.6, 1.7, 3.6);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 1, 0);
    this.controls.enableDamping = true;
    this.controls.maxDistance = 25;
    this.controls.minDistance = 0.6;
    this.resize();
    window.addEventListener('resize', this.resize);
    this.raf = requestAnimationFrame(this.tick);
  }

  groundAt = (x: number, z: number) => (this.st.uneven ? 0.18 * Math.sin(x * 1.6) * Math.cos(z * 1.3) + 0.12 * Math.sin(z * 2.3 + x * 0.7) : 0);

  private gridTexture() {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const g = c.getContext('2d')!;
    g.fillStyle = '#3b4250';
    g.fillRect(0, 0, 256, 256);
    g.strokeStyle = '#4c5566';
    g.lineWidth = 2;
    for (let i = 0; i <= 256; i += 64) {
      g.beginPath();
      g.moveTo(i, 0);
      g.lineTo(i, 256);
      g.moveTo(0, i);
      g.lineTo(256, i);
      g.stroke();
    }
    g.strokeStyle = '#59647a';
    g.lineWidth = 4;
    g.strokeRect(0, 0, 256, 256);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(40, 40);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  private buildProps() {
    const rock = new THREE.MeshStandardMaterial({ color: 0x6b6660, roughness: 1, flatShading: true });
    const wall = new THREE.Mesh(new THREE.BoxGeometry(4, 6, 0.4, 8, 12, 1), rock);
    jitter(wall.geometry as THREE.BufferGeometry, 0.05);
    wall.position.set(0, 3, 0.62);
    const ledge = new THREE.Mesh(new THREE.BoxGeometry(3, 2.15, 1.6, 6, 4, 4), rock);
    jitter(ledge.geometry as THREE.BufferGeometry, 0.03);
    ledge.position.set(0, 1.075, 0.28 + 0.8);
    const obstacle = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.8, 0.55, 4, 2, 2), rock);
    jitter(obstacle.geometry as THREE.BufferGeometry, 0.03);
    obstacle.position.set(0, 0.4, 0.62);
    const rope = new THREE.Group();
    const r = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 7, 6), new THREE.MeshStandardMaterial({ color: 0xffc94d }));
    r.position.set(0, 3.5, 0.0);
    r.rotation.x = -0.1;
    const rw = wall.clone();
    rw.position.set(0, 3, 1.15);
    rope.add(r, rw);
    for (const [k, o] of Object.entries({ wall, ledge, obstacle, rope })) {
      o.traverse((m) => {
        (m as THREE.Mesh).castShadow = true;
        (m as THREE.Mesh).receiveShadow = true;
      });
      o.visible = false;
      this.props[k] = o;
      this.scene.add(o);
    }
  }

  setModel(model: CharacterModel) {
    if (this.model) {
      this.scene.remove(this.model.object);
      this.animator?.dispose();
      if (this.helper) this.scene.remove(this.helper);
    }
    this.model = model;
    this.scene.add(model.object);
    model.object.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = true;
      }
    });
    this.animator = new CharacterAnimator(model);
    this.helper = new THREE.SkeletonHelper(model.helperRoot);
    (this.helper.material as THREE.LineBasicMaterial).depthTest = false;
    (this.helper.material as THREE.LineBasicMaterial).linewidth = 2;
    this.helper.renderOrder = 10;
    this.scene.add(this.helper);
    this.resetRoot();
    this.applyMode(true);
  }

  resetRoot() {
    if (!this.model) return;
    this.model.object.position.set(0, 0, 0);
    this.yaw = 0;
    this.model.object.quaternion.identity();
  }

  /** re-evaluates clip / blend selection */
  applyMode(restart = false) {
    const a = this.animator;
    if (!a) return;
    a.stopAllOverlays(0.1);
    if (this.st.mode === 'blend') {
      a.setState(this.st.blend.crouch ? 'crouch' : 'loco', this.st.fade);
      this.resetRoot();
    } else {
      const d = a.lib.get(this.st.clip);
      if (!d) return;
      a.setState(d.name, this.st.fade, { restart, once: !d.loop, next: d.name });
      this.finishedT = 0;
      this.resetRoot();
      // climbing props sit in front of the character: view from behind/side
      const behind = this.st.props && ['wall', 'ledge', 'rope', 'obstacle'].includes(d.prop ?? '');
      const wantBehind = behind ? -1 : 1;
      if (Math.sign(this.camera.position.z - this.controls.target.z) !== wantBehind) {
        this.controls.target.set(0, d.prop === 'ledge' ? 1.6 : 1.3, 0);
        this.camera.position.set(2.4, 2.0, 3.6 * wantBehind);
      }
    }
    this.updateProps();
  }

  updateProps() {
    const d = this.animator?.lib.get(this.st.clip);
    const prop = this.st.mode === 'clip' && this.st.props ? d?.prop ?? 'none' : 'none';
    for (const [k, o] of Object.entries(this.props)) o.visible = k === prop;
  }

  scrub(f: number) {
    const a = this.animator;
    if (!a || this.st.mode !== 'clip') return;
    const act = a.actions.get(this.st.clip);
    const d = a.lib.get(this.st.clip);
    if (!act || !d) return;
    act.time = f * d.inPlace.duration;
  }

  private resize = () => {
    const w = this.container.clientWidth || 800,
      h = this.container.clientHeight || 600;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  private rebuildGround() {
    const g = this.ground.geometry as THREE.BufferGeometry;
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) p.setY(i, this.groundAt(p.getX(i), p.getZ(i)));
    p.needsUpdate = true;
    g.computeVertexNormals();
  }
  private lastUneven = false;

  private tick = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.tick);
    const now = performance.now();
    const rdt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.fpsAcc += rdt;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.fps = this.fpsN / this.fpsAcc;
      this.fpsAcc = 0;
      this.fpsN = 0;
    }
    const st = this.st;
    if (st.uneven !== this.lastUneven) {
      this.lastUneven = st.uneven;
      this.rebuildGround();
    }
    const a = this.animator,
      m = this.model;
    if (a && m) {
      const dt = st.paused ? 0 : rdt * st.speed;
      this.time += dt;
      const obj = m.object;
      // blend tree / locomotion test
      if (st.mode === 'blend') {
        const b = st.blend;
        const want = b.crouch ? 'crouch' : 'loco';
        if (a.state !== want) a.setState(want, 0.3);
        const l = Math.hypot(b.dirX, b.dirZ) || 1;
        a.loco.speed = b.speed;
        a.loco.dirX = b.dirX / l;
        a.loco.dirZ = b.dirZ / l;
        a.loco.snow = b.snow;
        a.loco.wind = b.wind;
        a.loco.careful = b.careful;
        if (b.moveWorld) {
          obj.position.x += (b.dirX / l) * b.speed * dt;
          obj.position.z += (b.dirZ / l) * b.speed * dt;
          if (Math.hypot(obj.position.x, obj.position.z) > 14) obj.position.set(0, 0, 0);
        }
      }
      obj.position.y = this.groundAt(obj.position.x, obj.position.z);
      const d = a.lib.get(st.clip);
      const climbing = st.mode === 'clip' && d && ['wall', 'rope'].includes(d.prop ?? '');
      if (climbing && st.props) obj.position.y = d!.prop === 'rope' ? 0.15 : 0.55;
      a.ground = climbing ? null : this.groundAt;
      a.groundIK = st.uneven ? 1 : 0.0;
      // hand IK demo
      const showT = st.handIK;
      this.targets.forEach((t, k) => {
        t.visible = showT;
        const s = k === 0 ? 1 : -1;
        t.position.set(obj.position.x + s * (0.28 + 0.12 * Math.sin(this.time * 1.3 + k)), obj.position.y + 1.35 + 0.35 * Math.sin(this.time * 0.9 + k * 2), obj.position.z + 0.45 + 0.15 * Math.cos(this.time * 1.1 + k));
      });
      a.hand.L.target = showT ? this.targets[0].position : null;
      a.hand.R.target = showT ? this.targets[1].position : null;
      a.hand.L.weight = a.hand.R.weight = 1;
      a.look = st.lookAtCam ? this.camera.position : null;
      a.lookWeight = st.lookAtCam ? 0.85 : 0;
      a.breath = 0.3;
      a.update(dt);
      // root motion
      if (st.mode === 'clip' && d) {
        if (st.rootMotion && d.rootMotion) {
          const dp = a.rootDelta.p.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
          obj.position.add(dp);
          this.yaw += (a.rootDelta.yaw * Math.PI) / 180;
          obj.quaternion.setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
          if (d.loop && obj.position.length() > 3.2) this.resetRoot();
        }
        // loop one-shots for preview
        if (!d.loop) {
          const act = a.actions.get(d.name)!;
          if (act.time >= d.inPlace.duration - 1e-3) {
            this.finishedT += rdt;
            if (this.finishedT > 0.7 && !st.paused) {
              this.finishedT = 0;
              this.resetRoot();
              a.setState(d.name, 0.0001, { restart: true, once: true, next: d.name });
            }
          }
        }
      }
      if (this.helper) this.helper.visible = st.skeleton;
      m.meshes.forEach((mesh) => {
        const mm = (mesh as THREE.Mesh).material;
        (Array.isArray(mm) ? mm : [mm]).forEach((x) => ((x as THREE.MeshStandardMaterial).wireframe = st.wireframe));
      });
      const key = (this as any)._key as THREE.DirectionalLight;
      key.position.copy(obj.position).add(new THREE.Vector3(3, 6, 4));
      key.target.position.copy(obj.position);
      if (st.mode === 'blend' && st.blend.moveWorld) {
        const tgt = obj.position.clone().add(new THREE.Vector3(0, 1, 0));
        const delta = tgt.clone().sub(this.controls.target);
        this.controls.target.add(delta);
        this.camera.position.add(delta);
      }
      const act = st.mode === 'clip' ? a.actions.get(st.clip) : null;
      this.onFrame?.({ time: act ? act.time : a.phase, dur: d && act ? d.inPlace.duration : 1, state: a.state, fps: this.fps });
    }
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  };

  /** Renders a contact sheet (every clip at time fraction f) — used for QA and documentation. */
  contactSheet(f = 0.5, cols = 8): string {
    const a = this.animator,
      m = this.model;
    if (!a || !m) return '';
    const clips = a.clips;
    const rows = Math.ceil(clips.length / cols);
    const W = this.renderer.domElement.width,
      H = this.renderer.domElement.height;
    const cw = Math.floor(W / cols),
      ch = Math.floor(H / rows);
    const mixer = new THREE.AnimationMixer(m.rigRoot);
    const cam = new THREE.PerspectiveCamera(32, cw / ch, 0.05, 50);
    this.renderer.setScissorTest(true);
    this.renderer.setClearColor(0x1a2230);
    const helperVis = this.helper?.visible;
    if (this.helper) this.helper.visible = false;
    m.object.position.set(0, 0, 0);
    m.object.quaternion.identity();
    clips.forEach((c, i) => {
      a.mixer.stopAllAction();
      const act = mixer.clipAction(c.inPlace);
      act.reset().play();
      act.time = c.inPlace.duration * f;
      mixer.update(0);
      m.rigRoot.updateMatrixWorld(true);
      m.retarget?.apply();
      for (const [k, o] of Object.entries(this.props)) o.visible = k === c.prop;
      m.object.position.y = c.prop === 'wall' ? 0.55 : c.prop === 'rope' ? 0.15 : 0;
      const y = m.object.position.y;
      const back = c.prop && c.prop !== 'none' ? -1 : 1;
      cam.position.set(2.6, y + (c.prop === 'ledge' ? 2.1 : 1.5), 3.4 * back);
      cam.lookAt(0, y + (c.prop === 'ledge' ? 1.5 : 0.95), 0);
      const x = (i % cols) * cw,
        yy = H - (Math.floor(i / cols) + 1) * ch;
      this.renderer.setViewport(x, yy, cw, ch);
      this.renderer.setScissor(x, yy, cw, ch);
      this.renderer.render(this.scene, cam);
      act.stop();
    });
    this.renderer.setScissorTest(false);
    this.renderer.setViewport(0, 0, W, H);
    if (this.helper) this.helper.visible = !!helperVis;
    const url = this.renderer.domElement.toDataURL('image/png');
    this.applyMode(true);
    return url;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    this.animator?.dispose();
    this.controls.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

function jitter(g: THREE.BufferGeometry, amp: number) {
  const p = g.attributes.position;
  const seen = new Map<string, [number, number, number]>();
  for (let i = 0; i < p.count; i++) {
    const key = `${p.getX(i).toFixed(3)},${p.getY(i).toFixed(3)},${p.getZ(i).toFixed(3)}`;
    let o = seen.get(key);
    if (!o) {
      o = [(Math.random() - 0.5) * amp, (Math.random() - 0.5) * amp, (Math.random() - 0.5) * amp];
      seen.set(key, o);
    }
    p.setXYZ(i, p.getX(i) + o[0], p.getY(i) + o[1], p.getZ(i) + o[2]);
  }
  g.computeVertexNormals();
}
