import * as THREE from 'three';
import { BONE_WORLD } from './skeleton';

/**
 * Animation library for the protagonist.
 * All clips are authored as key poses (Euler degrees, XYZ, parent-aligned frames — see skeleton.ts),
 * resampled at 30 fps through a Catmull-Rom spline for natural, non-robotic easing.
 * Locomotion cycles are generated from gait functions (perfect loops, flat feet during stance).
 */

type E = [number, number, number];
export interface Pose {
  r: Record<string, E>;
  hips: [number, number, number];
  root?: { p: [number, number, number]; yaw: number };
}

export type Category = 'Movimento básico' | 'Ações' | 'Escalada' | 'Sobrevivência';

export interface ClipDef {
  name: string;
  label: string;
  category: Category;
  loop: boolean;
  rootMotion: boolean;
  desc: string;
  clip: THREE.AnimationClip; // full clip (with Root tracks if root motion)
  inPlace: THREE.AnimationClip; // Root tracks stripped
  /** Locomotion: axis used to measure nominal speed */
  speedAxis?: 'z' | '-z' | 'x' | '-x';
  nominalSpeed?: number;
  prop?: 'wall' | 'ledge' | 'obstacle' | 'rope' | 'none';
  phaseSync?: boolean;
}

const FPS = 30;
const D = Math.PI / 180;
const TAU = Math.PI * 2;

// ---------------------------------------------------------------- pose helpers
const P = (): Pose => ({ r: {}, hips: [0, 0, 0] });
const clone = (p: Pose): Pose => ({
  r: Object.fromEntries(Object.entries(p.r).map(([k, v]) => [k, [...v] as E])),
  hips: [...p.hips] as [number, number, number],
  root: p.root ? { p: [...p.root.p] as [number, number, number], yaw: p.root.yaw } : undefined,
});
const sideName = (s: 'L' | 'R', base: string) => (s === 'L' ? 'Left' : 'Right') + base;
/** set a limb bone; Right side is mirrored automatically (Y and Z negated) */
function S(p: Pose, s: 'L' | 'R', base: string, x: number, y = 0, z = 0) {
  p.r[sideName(s, base)] = s === 'L' ? [x, y, z] : [x, -y, -z];
}
function B(p: Pose, base: string, x: number, y = 0, z = 0) {
  S(p, 'L', base, x, y, z);
  S(p, 'R', base, x, y, z);
}
function C(p: Pose, bone: string, x: number, y = 0, z = 0) {
  p.r[bone] = [x, y, z];
}
function add(p: Pose, bone: string, x: number, y = 0, z = 0) {
  const r = p.r[bone] || [0, 0, 0];
  p.r[bone] = [r[0] + x, r[1] + y, r[2] + z];
}
function addS(p: Pose, s: 'L' | 'R', base: string, x: number, y = 0, z = 0) {
  add(p, sideName(s, base), x, s === 'L' ? y : -y, s === 'L' ? z : -z);
}
/** finger curl (deg) for one hand; thumb follows */
function grip(p: Pose, s: 'L' | 'R', c: number, thumb = c * 0.6) {
  for (const f of ['Index', 'Middle', 'Ring', 'Pinky']) {
    const spread = f === 'Index' ? 1.05 : f === 'Pinky' ? 0.9 : 1;
    S(p, s, `Hand${f}1`, 0, 0, -c * 0.85 * spread);
    S(p, s, `Hand${f}2`, 0, 0, -c * 1.05 * spread);
    S(p, s, `Hand${f}3`, 0, 0, -c * 0.75 * spread);
  }
  S(p, s, 'HandThumb1', 0, -thumb * 0.6, 0);
  S(p, s, 'HandThumb2', 0, -thumb * 0.5, 0);
  S(p, s, 'HandThumb3', 0, -thumb * 0.6, 0);
}
/** keep foot flat: compensates chain pitch */
function flatFoot(p: Pose, s: 'L' | 'R', extra = 0) {
  const n = (b: string) => p.r[sideName(s, b)]?.[0] ?? 0;
  S(p, s, 'Foot', -((p.r.Hips?.[0] ?? 0) + n('UpLeg') + n('Leg')) + extra, 0, p.r[sideName(s, 'Foot')]?.[2] ?? 0);
}
export function mirrorPose(p: Pose): Pose {
  const o = P();
  for (const [k, v] of Object.entries(p.r)) {
    let n = k;
    if (k.startsWith('Left')) n = 'Right' + k.slice(4);
    else if (k.startsWith('Right')) n = 'Left' + k.slice(5);
    o.r[n] = [v[0], -v[1], -v[2]];
  }
  o.hips = [-p.hips[0], p.hips[1], p.hips[2]];
  if (p.root) o.root = { p: [-p.root.p[0], p.root.p[1], p.root.p[2]], yaw: -p.root.yaw };
  return o;
}

/** relaxed standing pose (from the A-pose bind) */
function stand(): Pose {
  const p = P();
  C(p, 'Spine', 1);
  C(p, 'Spine1', 1);
  C(p, 'Spine2', -1);
  C(p, 'Neck', 3);
  C(p, 'Head', -3);
  B(p, 'Shoulder', 0, 0, -2);
  B(p, 'Arm', 4, -6, -11);
  B(p, 'ForeArm', -14, 8, 0);
  B(p, 'Hand', 0, 4, 2);
  grip(p, 'L', 18, 8);
  grip(p, 'R', 18, 8);
  B(p, 'UpLeg', 0, 0, -1);
  B(p, 'Leg', 2, 0, 0);
  B(p, 'Foot', -2, 0, 1);
  return p;
}

// ---------------------------------------------------------------- clip assembly
const per = (x: number) => ((x % 1) + 1) % 1;
const bump = (q: number, c: number, w: number) => {
  let d = Math.abs(per(q) - c);
  d = Math.min(d, 1 - d);
  return Math.exp(-((d / w) * (d / w)));
};
const cr = (p0: number, p1: number, p2: number, p3: number, t: number) => {
  const t2 = t * t,
    t3 = t2 * t;
  return 0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
};

function bake(name: string, duration: number, samples: { t: number; pose: Pose }[]): THREE.AnimationClip {
  const bones = new Set<string>();
  let hasRoot = false;
  for (const s of samples) {
    Object.keys(s.pose.r).forEach((b) => bones.add(b));
    if (s.pose.root) hasRoot = true;
  }
  const times = samples.map((s) => s.t);
  const tracks: THREE.KeyframeTrack[] = [];
  const q = new THREE.Quaternion(),
    prev = new THREE.Quaternion(),
    e = new THREE.Euler();
  for (const b of bones) {
    const vals: number[] = [];
    let first = true;
    for (const s of samples) {
      const r = s.pose.r[b] || [0, 0, 0];
      e.set(r[0] * D, r[1] * D, r[2] * D, 'XYZ');
      q.setFromEuler(e);
      if (!first && q.dot(prev) < 0) q.set(-q.x, -q.y, -q.z, -q.w);
      prev.copy(q);
      first = false;
      vals.push(q.x, q.y, q.z, q.w);
    }
    tracks.push(new THREE.QuaternionKeyframeTrack(`${b}.quaternion`, times, vals));
  }
  const hb = BONE_WORLD.Hips;
  tracks.push(new THREE.VectorKeyframeTrack('Hips.position', times, samples.flatMap((s) => [hb.x + s.pose.hips[0], hb.y + s.pose.hips[1], hb.z + s.pose.hips[2]])));
  if (hasRoot) {
    tracks.push(new THREE.VectorKeyframeTrack('Root.position', times, samples.flatMap((s) => s.pose.root?.p ?? [0, 0, 0])));
    const rq: number[] = [];
    for (const s of samples) {
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), (s.pose.root?.yaw ?? 0) * D);
      rq.push(q.x, q.y, q.z, q.w);
    }
    tracks.push(new THREE.QuaternionKeyframeTrack('Root.quaternion', times, rq));
  }
  return new THREE.AnimationClip(name, duration, tracks);
}

/** spline-interpolated key poses */
function keyed(name: string, duration: number, keys: [number, Pose][], loop = false): THREE.AnimationClip {
  const n = Math.max(2, Math.round(duration * FPS) + 1);
  const bones = new Set<string>();
  keys.forEach(([, p]) => Object.keys(p.r).forEach((b) => bones.add(b)));
  const hasRoot = keys.some(([, p]) => p.root);
  const kp = (i: number) => {
    if (loop) {
      const m = keys.length - 1; // last key == first key for loops
      return keys[((i % m) + m) % m][1];
    }
    return keys[Math.max(0, Math.min(keys.length - 1, i))][1];
  };
  const samples: { t: number; pose: Pose }[] = [];
  for (let k = 0; k < n; k++) {
    const t = (k / (n - 1)) * duration;
    let i = 0;
    while (i < keys.length - 2 && t > keys[i + 1][0]) i++;
    const t0 = keys[i][0],
      t1 = keys[i + 1][0];
    const u = t1 > t0 ? Math.min(1, Math.max(0, (t - t0) / (t1 - t0))) : 0;
    const a = kp(i - 1),
      b = kp(i),
      c = kp(i + 1),
      d = kp(i + 2);
    const pose = P();
    for (const bn of bones) {
      const g = (p: Pose) => p.r[bn] || [0, 0, 0];
      pose.r[bn] = [0, 1, 2].map((j) => cr(g(a)[j], g(b)[j], g(c)[j], g(d)[j], u)) as E;
    }
    pose.hips = [0, 1, 2].map((j) => cr(a.hips[j], b.hips[j], c.hips[j], d.hips[j], u)) as [number, number, number];
    if (hasRoot) {
      const rp = (p: Pose) => p.root ?? { p: [0, 0, 0] as [number, number, number], yaw: 0 };
      // root motion uses monotonic interpolation (no overshoot)
      const ra = rp(b),
        rb = rp(c);
      const su = u * u * (3 - 2 * u);
      pose.root = { p: [0, 1, 2].map((j) => ra.p[j] + (rb.p[j] - ra.p[j]) * su) as [number, number, number], yaw: ra.yaw + (rb.yaw - ra.yaw) * su };
    }
    samples.push({ t, pose });
  }
  return bake(name, duration, samples);
}

/** procedural looping cycle */
function cycle(name: string, duration: number, fn: (p: number) => Pose, frames = 32): THREE.AnimationClip {
  const samples: { t: number; pose: Pose }[] = [];
  for (let k = 0; k <= frames; k++) {
    const p = k / frames;
    samples.push({ t: p * duration, pose: fn(k === frames ? 0 : p) });
    if (k === frames && samples[k].pose.root) {
      // keep root motion monotonic at loop end
      samples[k].pose = fn(0.999999);
    }
  }
  return bake(name, duration, samples);
}

// ---------------------------------------------------------------- gait generator
interface Gait {
  A: number; // thigh swing amplitude
  off: number; // thigh offset (neg = forward)
  kSwing: number;
  kStance: number;
  kBase: number;
  lean: number;
  arm: number;
  armOff: number;
  elbow: number;
  elbowX: number;
  bob: number;
  run: boolean;
  sway: number;
  twist: number;
  fingers: number;
  armZ: number;
  hipsY: number;
  heel: number;
  swingC?: number;
}

function gaitPose(p: number, g: Gait, base = stand()): Pose {
  const o = clone(base);
  const hipsRot = -g.twist * Math.cos(TAU * p);
  C(o, 'Hips', g.lean * 0.35, hipsRot, 2.2 * Math.sin(TAU * p) * (g.run ? 0.5 : 1));
  C(o, 'Spine', g.lean * 0.35 + 1, -hipsRot * 0.4, 0);
  C(o, 'Spine1', g.lean * 0.25 + 1, -hipsRot * 0.9, -1.2 * Math.sin(TAU * p));
  C(o, 'Spine2', g.lean * 0.15 - 1, -hipsRot * 0.5, 0);
  C(o, 'Neck', 3 - g.lean * 0.35, hipsRot * 0.3, 0);
  C(o, 'Head', -3 - g.lean * 0.45, 0, 0.6 * Math.sin(TAU * p));
  for (const s of ['L', 'R'] as const) {
    const q = per(p + (s === 'L' ? 0 : 0.5));
    const thigh = g.off - g.A * Math.cos(TAU * q);
    const sc = g.swingC ?? (g.run ? 0.66 : 0.72);
    const knee = g.kBase + g.kStance * bump(q, g.run ? 0.15 : 0.1, g.run ? 0.1 : 0.08) + g.kSwing * bump(q, sc, g.run ? 0.17 : 0.13);
    S(o, s, 'UpLeg', thigh - o.r.Hips[0], 0, -1.5);
    S(o, s, 'Leg', knee, 0, 0);
    // stance mask (1 on the ground)
    const st = Math.pow(0.5 + 0.5 * Math.cos(TAU * (q - 0.25)), g.run ? 1.6 : 0.8);
    const chain = thigh + knee;
    const footX = st * -chain + (1 - st) * (-chain * 0.35 - 10) + g.heel * bump(q, g.run ? 0.42 : 0.5, 0.07);
    S(o, s, 'Foot', footX, 0, 1);
    S(o, s, 'ToeBase', -22 * bump(q, g.run ? 0.42 : 0.52, 0.06), 0, 0);
    // arms (opposite to legs)
    const ac = Math.cos(TAU * q); // +1 when this leg is forward → arm back
    S(o, s, 'Arm', g.armOff + g.arm * ac, -5, g.armZ);
    S(o, s, 'ForeArm', -(g.elbow + g.elbowX * (0.5 - 0.5 * ac)), 10, 0);
    S(o, s, 'Hand', 0, 4, 3);
    grip(o, s, g.fingers, g.fingers * 0.5);
    S(o, s, 'Shoulder', 0, 0, -2 + (g.run ? 2 : 0) * ac);
  }
  const bobY = g.run ? g.bob * Math.cos(TAU * 2 * (p - 0.05)) : -g.bob * Math.cos(TAU * 2 * p);
  o.hips = [0.012 * Math.sin(TAU * p) * (g.run ? 0.4 : 1) * g.sway, g.hipsY + bobY, 0];
  return o;
}

const WALK: Gait = { A: 26, off: -2, kSwing: 52, kStance: 14, kBase: 4, lean: 3, arm: 15, armOff: 3, elbow: 16, elbowX: 10, bob: 0.018, run: false, sway: 1, twist: 5, fingers: 22, armZ: -11, hipsY: -0.012, heel: 10 };
const RUN: Gait = { A: 32, off: -8, kSwing: 92, kStance: 22, kBase: 8, lean: 9, arm: 34, armOff: 6, elbow: 78, elbowX: 14, bob: 0.03, run: true, sway: 1, twist: 8, fingers: 55, armZ: -9, hipsY: -0.045, heel: 14 };
const SPRINT: Gait = { A: 42, off: -13, kSwing: 112, kStance: 28, kBase: 10, lean: 16, arm: 55, armOff: 2, elbow: 88, elbowX: 10, bob: 0.04, run: true, sway: 1, twist: 10, fingers: 65, armZ: -8, hipsY: -0.06, heel: 18 };

// ---------------------------------------------------------------- climbing base poses
function climbIdle(): Pose {
  const p = P();
  C(p, 'Hips', -4, 0, 0);
  C(p, 'Spine', 2);
  C(p, 'Spine1', 3);
  C(p, 'Spine2', 2);
  C(p, 'Neck', -8);
  C(p, 'Head', -14);
  S(p, 'L', 'Shoulder', 0, 0, 8);
  S(p, 'R', 'Shoulder', 0, 0, 5);
  S(p, 'L', 'Arm', -152, 0, 6);
  S(p, 'L', 'ForeArm', -28, 0, 0);
  S(p, 'L', 'Hand', -18, 0, 0);
  S(p, 'R', 'Arm', -122, 0, 2);
  S(p, 'R', 'ForeArm', -52, 0, 0);
  S(p, 'R', 'Hand', -22, 0, 0);
  grip(p, 'L', 62, 40);
  grip(p, 'R', 62, 40);
  S(p, 'L', 'UpLeg', -44, 0, 10);
  S(p, 'L', 'Leg', 78);
  S(p, 'R', 'UpLeg', -18, 0, 8);
  S(p, 'R', 'Leg', 36);
  flatFoot(p, 'L', -6);
  flatFoot(p, 'R', -10);
  p.hips = [0, 0.02, -0.06];
  return p;
}

function crouchPose(): Pose {
  const p = stand();
  C(p, 'Hips', 14);
  C(p, 'Spine', 10);
  C(p, 'Spine1', 8);
  C(p, 'Spine2', 4);
  C(p, 'Neck', -8);
  C(p, 'Head', -14);
  B(p, 'UpLeg', -92, 0, 4);
  B(p, 'Leg', 118);
  flatFoot(p, 'L');
  flatFoot(p, 'R');
  B(p, 'Arm', -38, 0, -6);
  B(p, 'ForeArm', -62, 10, 0);
  p.hips = [0, -0.4, -0.04];
  return p;
}

function sitPose(): Pose {
  const p = stand();
  C(p, 'Hips', -6);
  C(p, 'Spine', 16);
  C(p, 'Spine1', 10);
  C(p, 'Spine2', 4);
  C(p, 'Neck', -4);
  C(p, 'Head', -10);
  B(p, 'UpLeg', -66, 0, 8);
  B(p, 'Leg', 108);
  flatFoot(p, 'L');
  flatFoot(p, 'R');
  B(p, 'Arm', -40, 0, 4);
  B(p, 'ForeArm', -68, 10, 0);
  grip(p, 'L', 30);
  grip(p, 'R', 30);
  p.hips = [0, -0.8, -0.05];
  return p;
}

function hangPose(): Pose {
  const p = P();
  C(p, 'Spine2', -2);
  C(p, 'Neck', -10);
  C(p, 'Head', -10);
  B(p, 'Shoulder', 0, 0, 14);
  B(p, 'Arm', -172, 0, 8);
  B(p, 'ForeArm', -8);
  B(p, 'Hand', -10);
  grip(p, 'L', 70, 45);
  grip(p, 'R', 70, 45);
  B(p, 'UpLeg', -8, 0, 2);
  B(p, 'Leg', 14);
  B(p, 'Foot', 18);
  p.hips = [0, -0.02, -0.03];
  return p;
}

// ---------------------------------------------------------------- library
function build(): Omit<ClipDef, 'inPlace'>[] {
  const L: Omit<ClipDef, 'inPlace'>[] = [];
  const def = (name: string, label: string, category: Category, clip: THREE.AnimationClip, o: Partial<ClipDef> & { desc: string }) =>
    L.push({ name, label, category, clip, loop: !!o.loop, rootMotion: !!o.rootMotion, desc: o.desc, speedAxis: o.speedAxis, prop: o.prop ?? 'none', phaseSync: o.phaseSync });

  // ===== BASIC MOVEMENT =====
  def(
    'idle',
    'Parado (idle)',
    'Movimento básico',
    cycle('idle', 4.2, (p) => {
      const o = stand();
      const br = Math.sin(TAU * p);
      const dx = 0.014 * Math.sin(TAU * p + 0.6);
      const k = (-dx / 0.88) / D;
      add(o, 'Spine1', 1.4 * br);
      add(o, 'Spine2', 1.1 * br);
      add(o, 'Neck', -0.8 * br);
      add(o, 'Head', 0.4 * br, 4 * Math.sin(TAU * p * 2 + 1) * 0.5, 0);
      B(o, 'Shoulder', 0, 0, -2 + 1.2 * br);
      addS(o, 'L', 'Arm', 1.5 * Math.sin(TAU * p + 1), 0, 0);
      addS(o, 'R', 'Arm', 1.5 * Math.sin(TAU * p + 2), 0, 0);
      o.r.LeftUpLeg = [0, 0, k - 1];
      o.r.RightUpLeg = [0, 0, k + 1];
      o.r.LeftFoot = [-2, 0, -k + 1];
      o.r.RightFoot = [-2, 0, -k - 1];
      add(o, 'Hips', 0, 0, 0);
      add(o, 'Spine', 0, 0, -k * 0.6);
      o.hips = [dx, -0.004 + 0.002 * br, 0];
      return o;
    }),
    { loop: true, desc: 'Respiração natural, troca sutil do peso entre as pernas.' },
  );
  def('walk_forward', 'Andar para frente', 'Movimento básico', cycle('walk_forward', 1.1, (p) => gaitPose(p, WALK)), { loop: true, desc: 'Ciclo de caminhada in-place, pés planos no apoio.', speedAxis: 'z', phaseSync: true });
  def(
    'walk_backward',
    'Andar para trás',
    'Movimento básico',
    cycle('walk_backward', 1.15, (p) => {
      const o = gaitPose(per(1 - p), { ...WALK, A: 17, kSwing: 40, lean: -2, arm: 9 });
      return o;
    }),
    { loop: true, desc: 'Passos curtos para trás, tronco levemente inclinado para trás.', speedAxis: '-z', phaseSync: true },
  );
  def('run', 'Correr', 'Movimento básico', cycle('run', 0.72, (p) => gaitPose(p, RUN)), { loop: true, desc: 'Corrida com fase aérea e braços dobrados.', speedAxis: 'z', phaseSync: true });
  def('sprint', 'Sprint', 'Movimento básico', cycle('sprint', 0.58, (p) => gaitPose(p, SPRINT)), { loop: true, desc: 'Arrancada máxima com inclinação forte do tronco.', speedAxis: 'z', phaseSync: true });
  const strafe = (p: number) => {
    const o = stand();
    const lAbd = 14 + 14 * Math.cos(TAU * p);
    const rAbd = 8 + 8 * Math.cos(TAU * p);
    const lLift = bump(p, 0.75, 0.12),
      rLift = bump(p, 0.25, 0.12);
    S(o, 'L', 'UpLeg', -6 * lLift - 2, 0, lAbd);
    S(o, 'L', 'Leg', 4 + 26 * lLift);
    S(o, 'R', 'UpLeg', -6 * rLift - 2, 0, rAbd - 4);
    S(o, 'R', 'Leg', 4 + 26 * rLift);
    flatFoot(o, 'L');
    flatFoot(o, 'R');
    S(o, 'L', 'Foot', o.r.LeftFoot[0], 0, -lAbd);
    S(o, 'R', 'Foot', o.r.RightFoot[0], 0, -(rAbd - 4));
    C(o, 'Spine1', 2, 0, -3);
    C(o, 'Head', -3, 0, 3);
    B(o, 'Arm', 3, -4, -9);
    addS(o, 'L', 'Arm', 0, 0, 4 * Math.cos(TAU * p));
    addS(o, 'R', 'Arm', 0, 0, -3 * Math.cos(TAU * p));
    o.hips = [0.02 * Math.sin(TAU * p), -0.015 - 0.01 * Math.cos(TAU * 2 * p), 0];
    return o;
  };
  def('strafe_left', 'Lateral esquerda', 'Movimento básico', cycle('strafe_left', 0.82, strafe), { loop: true, desc: 'Passos laterais sem cruzar as pernas.', speedAxis: 'x', phaseSync: true });
  def('strafe_right', 'Lateral direita', 'Movimento básico', cycle('strafe_right', 0.82, (p) => mirrorPose(strafe(p))), { loop: true, desc: 'Espelho exato da lateral esquerda.', speedAxis: '-x', phaseSync: true });

  const w0 = gaitPose(0, WALK),
    w5 = gaitPose(0.5, WALK);
  {
    const lean = stand();
    C(lean, 'Spine', 6);
    C(lean, 'Spine1', 4);
    lean.hips = [-0.02, -0.01, 0.02];
    S(lean, 'R', 'UpLeg', 4);
    def('walk_start', 'Começar a andar', 'Movimento básico', keyed('walk_start', 0.5, [[0, stand()], [0.22, lean], [0.5, w0]]), { desc: 'Transfere o peso e inicia o primeiro passo (aceleração).' });
    const settle = stand();
    C(settle, 'Spine', -2);
    C(settle, 'Spine1', -1);
    settle.hips = [0, -0.02, -0.01];
    def('walk_stop', 'Parar', 'Movimento básico', keyed('walk_stop', 0.65, [[0, w5], [0.3, settle], [0.65, stand()]]), { desc: 'Desaceleração natural: passo de frenagem e acomodação.' });
  }
  {
    const k1 = stand();
    k1.root = { p: [0, 0, 0], yaw: 0 };
    const k2 = stand();
    S(k2, 'L', 'UpLeg', -22, 25, 6);
    S(k2, 'L', 'Leg', 38);
    flatFoot(k2, 'L');
    C(k2, 'Spine1', 4, 15, 0);
    C(k2, 'Head', -4, 25, 0);
    k2.hips = [0.02, -0.03, 0];
    k2.root = { p: [0, 0, 0], yaw: 60 };
    const k3 = stand();
    S(k3, 'R', 'UpLeg', -20, -20, 4);
    S(k3, 'R', 'Leg', 34);
    flatFoot(k3, 'R');
    C(k3, 'Spine1', 3, 8, 0);
    k3.hips = [-0.02, -0.03, 0];
    k3.root = { p: [0, 0, 0], yaw: 145 };
    const k4 = stand();
    k4.root = { p: [0, 0, 0], yaw: 180 };
    def('turn_180', 'Giro de 180°', 'Movimento básico', keyed('turn_180', 0.9, [[0, k1], [0.3, k2], [0.62, k3], [0.9, k4]]), { rootMotion: true, desc: 'Pivô em dois passos com root motion de rotação (180°).' });
  }

  // ===== ACTIONS =====
  {
    const s0 = stand();
    s0.root = { p: [0, 0, 0], yaw: 0 };
    const crouch = stand();
    C(crouch, 'Hips', 12);
    C(crouch, 'Spine', 10);
    C(crouch, 'Spine1', 6);
    B(crouch, 'UpLeg', -52);
    B(crouch, 'Leg', 82);
    flatFoot(crouch, 'L');
    flatFoot(crouch, 'R');
    B(crouch, 'Arm', 40, 0, -6);
    B(crouch, 'ForeArm', -20);
    crouch.hips = [0, -0.17, -0.02];
    crouch.root = { p: [0, 0, 0], yaw: 0 };
    const ext = stand();
    C(ext, 'Spine', -2);
    B(ext, 'Arm', -110, 0, 10);
    B(ext, 'ForeArm', -30);
    B(ext, 'UpLeg', 4);
    B(ext, 'Foot', 30);
    ext.hips = [0, 0.04, 0];
    ext.root = { p: [0, 0.35, 0.15], yaw: 0 };
    def('jump', 'Pular', 'Ações', keyed('jump', 0.55, [[0, s0], [0.22, crouch], [0.42, ext], [0.55, ext]]), { rootMotion: true, desc: 'Impulso: agacha, estende e sai do chão.' });
  }
  def(
    'fall',
    'Caindo',
    'Ações',
    cycle('fall', 1.2, (p) => {
      const o = stand();
      C(o, 'Spine', -4 + 2 * Math.sin(TAU * p));
      C(o, 'Spine1', -3);
      C(o, 'Head', -10);
      S(o, 'L', 'Arm', -45 + 12 * Math.sin(TAU * p), 0, 55);
      S(o, 'R', 'Arm', -45 + 12 * Math.sin(TAU * p + 2), 0, 55);
      B(o, 'ForeArm', -35);
      grip(o, 'L', 10);
      grip(o, 'R', 10);
      S(o, 'L', 'UpLeg', -30 + 12 * Math.sin(TAU * p), 0, 6);
      S(o, 'L', 'Leg', 55 + 15 * Math.sin(TAU * p + 1));
      S(o, 'R', 'UpLeg', -8 + 12 * Math.sin(TAU * p + 3), 0, 6);
      S(o, 'R', 'Leg', 25 + 15 * Math.sin(TAU * p + 4));
      B(o, 'Foot', 15);
      return o;
    }),
    { loop: true, desc: 'Queda: braços abertos buscando equilíbrio, pernas reativas.' },
  );
  {
    const imp = crouchPose();
    imp.hips = [0, -0.2, 0];
    C(imp, 'Hips', 8);
    B(imp, 'UpLeg', -55);
    B(imp, 'Leg', 85);
    flatFoot(imp, 'L');
    flatFoot(imp, 'R');
    B(imp, 'Arm', -30, 0, 22);
    def('land', 'Aterrissar', 'Ações', keyed('land', 0.55, [[0, imp], [0.12, imp], [0.55, stand()]]), { desc: 'Absorção de impacto leve.' });
    const deep = crouchPose();
    C(deep, 'Spine', 26);
    C(deep, 'Spine1', 14);
    S(deep, 'R', 'Arm', -62, 0, 4);
    S(deep, 'R', 'ForeArm', -8);
    grip(deep, 'R', 5);
    S(deep, 'L', 'Arm', -20, 0, 30);
    deep.hips = [0, -0.46, 0.02];
    const mid = crouchPose();
    mid.hips = [0, -0.25, 0];
    def('land_hard', 'Aterrissagem forte', 'Ações', keyed('land_hard', 1.25, [[0, deep], [0.3, deep], [0.75, mid], [1.25, stand()]]), { desc: 'Impacto forte: mão no chão, recuperação lenta.' });
  }
  def('crouch_down', 'Agachar', 'Ações', keyed('crouch_down', 0.45, [[0, stand()], [0.45, crouchPose()]]), { desc: 'Transição para agachado.' });
  def(
    'crouch_idle',
    'Agachado',
    'Ações',
    cycle('crouch_idle', 3, (p) => {
      const o = crouchPose();
      add(o, 'Spine1', 1.5 * Math.sin(TAU * p));
      add(o, 'Head', 0, 10 * Math.sin(TAU * p), 0);
      o.hips[1] += 0.004 * Math.sin(TAU * p);
      return o;
    }),
    { loop: true, desc: 'Agachado e atento.' },
  );
  def(
    'crouch_walk',
    'Andar agachado',
    'Ações',
    cycle('crouch_walk', 1.05, (p) => {
      const o = gaitPose(p, { ...WALK, A: 17, off: -58, kBase: 90, kSwing: 28, kStance: 6, lean: 26, arm: 8, armOff: -25, elbow: 55, hipsY: -0.38, bob: 0.012 });
      return o;
    }),
    { loop: true, desc: 'Deslocamento furtivo e estável.', speedAxis: 'z', phaseSync: true },
  );
  def('stand_up', 'Levantar', 'Ações', keyed('stand_up', 0.6, [[0, crouchPose()], [0.6, stand()]]), { desc: 'Do agachado para em pé.' });
  {
    const k = (yaw: number, pitch: number, chest = 0.3) => {
      const o = stand();
      C(o, 'Neck', 3 + pitch * 0.4, yaw * 0.35, 0);
      C(o, 'Head', -3 + pitch * 0.6, yaw * 0.5, 0);
      C(o, 'Spine2', -1, yaw * chest * 0.5, 0);
      C(o, 'Spine1', 1, yaw * chest * 0.3, 0);
      return o;
    };
    def('look_around', 'Olhar ao redor', 'Ações', keyed('look_around', 5, [[0, stand()], [0.9, k(55, -4)], [1.8, k(55, -18)], [2.6, k(-10, -6)], [3.6, k(-62, 2)], [5, stand()]]), { desc: 'Examina o horizonte e o caminho acima.' });
    def('head_turn', 'Virar a cabeça', 'Ações', keyed('head_turn', 2.4, [[0, stand()], [0.5, k(48, 0, 0.1)], [1.2, k(48, 0, 0.1)], [1.8, k(-40, 2, 0.1)], [2.4, stand()]]), { desc: 'Rotação de pescoço/cabeça (também usada como camada).' });
  }
  {
    const look = stand();
    C(look, 'Neck', 18);
    C(look, 'Head', 22, 10, 0);
    C(look, 'Spine1', 6);
    const h1 = clone(look);
    S(h1, 'L', 'Arm', -24, 22, -30);
    S(h1, 'L', 'ForeArm', -88, 10, 0);
    S(h1, 'L', 'Hand', 10, 0, -10);
    grip(h1, 'L', 50);
    S(h1, 'R', 'Arm', -30, 10, -26);
    S(h1, 'R', 'ForeArm', -118, 0, 0);
    grip(h1, 'R', 55);
    const h2 = clone(h1);
    addS(h2, 'L', 'ForeArm', 10, 0, 0);
    addS(h2, 'L', 'Hand', -15, 10, 0);
    grip(h2, 'L', 70);
    const watch = stand();
    C(watch, 'Neck', 14);
    C(watch, 'Head', 16, 18, 0);
    S(watch, 'L', 'Arm', -48, 30, -22);
    S(watch, 'L', 'ForeArm', -112, -50, 0);
    S(watch, 'L', 'Hand', -10, 0, 0);
    def('check_equipment', 'Checar equipamento', 'Ações', keyed('check_equipment', 4, [[0, stand()], [0.7, h1], [1.3, h2], [1.8, h1], [2.4, watch], [3.2, watch], [4, stand()]]), { desc: 'Confere mosquetões do arnês e o altímetro de pulso.' });
  }
  {
    const g = stand();
    B(g, 'Arm', -26, 10, -12);
    B(g, 'ForeArm', -138, 0, 0);
    B(g, 'Hand', -10, 0, 0);
    grip(g, 'L', 75, 40);
    grip(g, 'R', 75, 40);
    const up = clone(g);
    B(up, 'Shoulder', 0, 0, 12);
    C(up, 'Backpack', -6);
    up.hips = [0, -0.04, 0];
    B(up, 'UpLeg', -10);
    B(up, 'Leg', 18);
    flatFoot(up, 'L');
    flatFoot(up, 'R');
    const pop = clone(g);
    B(pop, 'Shoulder', 0, 0, 6);
    C(pop, 'Backpack', 9);
    pop.hips = [0, 0.01, 0];
    def('adjust_backpack', 'Ajustar mochila', 'Ações', keyed('adjust_backpack', 2.8, [[0, stand()], [0.6, g], [1.1, up], [1.35, pop], [1.8, g], [2.8, stand()]]), { desc: 'Segura as alças, dá um impulso e reacomoda a mochila.' });
  }
  def(
    'catch_breath',
    'Recuperar o fôlego',
    'Ações',
    cycle('catch_breath', 2.2, (p) => {
      const o = stand();
      const br = Math.sin(TAU * p);
      C(o, 'Hips', 28);
      C(o, 'Spine', 12 + 2 * br);
      C(o, 'Spine1', 8 + 2.5 * br);
      C(o, 'Spine2', 4 + 2 * br);
      C(o, 'Neck', -14);
      C(o, 'Head', -18 + br * 2);
      B(o, 'UpLeg', -52, 0, 3);
      B(o, 'Leg', 42);
      flatFoot(o, 'L');
      flatFoot(o, 'R');
      B(o, 'Shoulder', 0, 0, 4 + 3 * br);
      B(o, 'Arm', -50, 4, -10);
      B(o, 'ForeArm', -12);
      B(o, 'Hand', 30);
      grip(o, 'L', 35);
      grip(o, 'R', 35);
      o.hips = [0, -0.08 + 0.006 * br, -0.07];
      return o;
    }),
    { loop: true, desc: 'Mãos nos joelhos, respiração pesada após esforço.' },
  );

  // ===== CLIMBING =====
  const ci = climbIdle();
  def(
    'climb_idle',
    'Escalar: posição base',
    'Escalada',
    cycle('climb_idle', 3, (p) => {
      const o = climbIdle();
      add(o, 'Spine1', 1.5 * Math.sin(TAU * p));
      add(o, 'Head', 0, 8 * Math.sin(TAU * p), 0);
      o.hips[1] += 0.008 * Math.sin(TAU * p);
      return o;
    }),
    { loop: true, desc: 'Mãos e pés apoiados na parede.', prop: 'wall' },
  );
  {
    const off = clone(ci);
    S(off, 'L', 'Arm', -110, 0, 10);
    S(off, 'L', 'ForeArm', -70);
    grip(off, 'L', 25);
    off.hips = [-0.03, 0.03, -0.07];
    const reach = clone(ci);
    S(reach, 'L', 'Arm', -174, 0, 8);
    S(reach, 'L', 'ForeArm', -4);
    S(reach, 'L', 'Shoulder', 0, 0, 18);
    grip(reach, 'L', 20);
    C(reach, 'Head', -26, 18, 0);
    C(reach, 'Spine1', 2, 6, -4);
    S(reach, 'R', 'ForeArm', -78);
    reach.hips = [-0.02, 0.09, -0.04];
    S(reach, 'L', 'UpLeg', -30, 0, 10);
    S(reach, 'L', 'Leg', 50);
    flatFoot(reach, 'L', -6);
    const got = clone(reach);
    S(got, 'L', 'Arm', -164);
    S(got, 'L', 'ForeArm', -16);
    grip(got, 'L', 66, 40);
    C(got, 'Head', -18, 8, 0);
    def('climb_reach_left', 'Alcançar apoio (esq.)', 'Escalada', keyed('climb_reach_left', 1.1, [[0, ci], [0.3, off], [0.7, reach], [1.1, got]]), { desc: 'Solta, estende e agarra um apoio mais alto com a mão esquerda.', prop: 'wall' });
    def('climb_reach_right', 'Alcançar apoio (dir.)', 'Escalada', keyed('climb_reach_right', 1.1, [[0, mirrorPose(ci)], [0.3, mirrorPose(off)], [0.7, mirrorPose(reach)], [1.1, mirrorPose(got)]]), { desc: 'Espelho do alcance esquerdo.', prop: 'wall' });
    const lift = clone(ci);
    S(lift, 'L', 'UpLeg', -78, 0, 18);
    S(lift, 'L', 'Leg', 112);
    flatFoot(lift, 'L', 10);
    lift.hips = [-0.04, 0.0, -0.09];
    const place = clone(ci);
    S(place, 'L', 'UpLeg', -68, 0, 14);
    S(place, 'L', 'Leg', 98);
    flatFoot(place, 'L', -8);
    place.hips = [-0.02, 0.03, -0.06];
    def('climb_foot_left', 'Trocar pé (esq.)', 'Escalada', keyed('climb_foot_left', 0.9, [[0, ci], [0.4, lift], [0.9, place]]), { desc: 'Move o pé esquerdo para um apoio mais alto.', prop: 'wall' });
    def('climb_foot_right', 'Trocar pé (dir.)', 'Escalada', keyed('climb_foot_right', 0.9, [[0, mirrorPose(ci)], [0.4, mirrorPose(lift)], [0.9, mirrorPose(place)]]), { desc: 'Move o pé direito para um apoio mais alto.', prop: 'wall' });
  }
  {
    const a = (k: number, y: number) => {
      const o = k === 0 ? clone(ci) : mirrorPose(ci);
      o.root = { p: [0, y, 0], yaw: 0 };
      return o;
    };
    const ra = clone(ci);
    S(ra, 'R', 'Arm', -172, 0, 8);
    S(ra, 'R', 'ForeArm', -6);
    S(ra, 'L', 'ForeArm', -60);
    S(ra, 'R', 'UpLeg', -70, 0, 14);
    S(ra, 'R', 'Leg', 100);
    flatFoot(ra, 'R', -6);
    ra.hips = [0.03, 0.06, -0.05];
    ra.root = { p: [0, 0.18, 0], yaw: 0 };
    const rb = mirrorPose(ra);
    rb.root = { p: [0, 0.48, 0], yaw: 0 };
    const k0 = a(0, 0);
    const k2 = a(1, 0.33);
    k2.root = { p: [0, 0.33, 0], yaw: 0 };
    const k4 = a(0, 0.66);
    def('climb_up', 'Escalar (mãos e pés)', 'Escalada', keyed('climb_up', 2.2, [[0, k0], [0.55, ra], [1.1, k2], [1.65, rb], [2.2, k4]], false), { loop: true, rootMotion: true, desc: 'Ciclo completo de escalada alternando mãos e pés (root motion vertical).', prop: 'wall' });
  }
  def(
    'hang',
    'Pendurado',
    'Escalada',
    cycle('hang', 3.2, (p) => {
      const o = hangPose();
      const sw = Math.sin(TAU * p);
      C(o, 'Hips', 4 * sw);
      B(o, 'UpLeg', -8 - 6 * sw, 0, 2);
      add(o, 'Spine', -2 * sw);
      add(o, 'Head', 0, 6 * Math.sin(TAU * p + 1), 0);
      return o;
    }),
    { loop: true, desc: 'Suspenso pelos braços, pernas soltas e balanço leve.', prop: 'ledge' },
  );
  def(
    'hang_one_arm',
    'Pendurado (um braço)',
    'Escalada',
    cycle('hang_one_arm', 2.6, (p) => {
      const o = hangPose();
      const sw = Math.sin(TAU * p);
      S(o, 'R', 'Arm', -30 + 15 * sw, 0, 25);
      S(o, 'R', 'ForeArm', -30);
      S(o, 'R', 'Shoulder', 0, 0, 0);
      grip(o, 'R', 15);
      C(o, 'Spine1', 0, 16 * sw, -4);
      C(o, 'Hips', 0, 14 * sw, -6);
      S(o, 'L', 'UpLeg', -16 - 8 * sw, 0, 6);
      S(o, 'R', 'UpLeg', -4 + 8 * sw, 0, 6);
      C(o, 'Head', -8, -10 * sw, 0);
      return o;
    }),
    { loop: true, desc: 'Um só braço segurando: corpo gira e balança (instável).', prop: 'ledge' },
  );
  {
    const h = hangPose();
    h.root = { p: [0, 0, 0], yaw: 0 };
    const mid = hangPose();
    B(mid, 'Arm', -140, 0, 20);
    B(mid, 'ForeArm', -85);
    B(mid, 'UpLeg', -30);
    B(mid, 'Leg', 50);
    C(mid, 'Head', -4);
    mid.root = { p: [0, 0.3, 0], yaw: 0 };
    const top = hangPose();
    B(top, 'Arm', -70, 0, 32);
    B(top, 'ForeArm', -128);
    B(top, 'Hand', -30);
    B(top, 'UpLeg', -42);
    B(top, 'Leg', 70);
    C(top, 'Spine', 6);
    C(top, 'Head', 6);
    top.root = { p: [0, 0.55, 0], yaw: 0 };
    def('pull_up', 'Puxar o corpo', 'Escalada', keyed('pull_up', 1.3, [[0, h], [0.65, mid], [1.3, top]]), { rootMotion: true, desc: 'Tração dos braços elevando o corpo (root motion +0,55 m).', prop: 'ledge' });
  }
  {
    const k0 = hangPose();
    k0.root = { p: [0, 0, 0], yaw: 0 };
    const k1 = hangPose();
    B(k1, 'Arm', -80, 0, 30);
    B(k1, 'ForeArm', -120);
    B(k1, 'Hand', -40);
    S(k1, 'L', 'UpLeg', -60, 0, 8);
    S(k1, 'L', 'Leg', 90);
    C(k1, 'Spine', 14);
    C(k1, 'Spine1', 8);
    k1.root = { p: [0, 1.0, 0.05], yaw: 0 };
    const k2 = stand();
    C(k2, 'Hips', 30);
    C(k2, 'Spine', 20);
    C(k2, 'Spine1', 12);
    C(k2, 'Head', -20);
    B(k2, 'Arm', 20, 0, 18);
    B(k2, 'ForeArm', -20);
    B(k2, 'Hand', 60);
    S(k2, 'L', 'UpLeg', -125, 0, 10);
    S(k2, 'L', 'Leg', 135);
    flatFoot(k2, 'L');
    S(k2, 'R', 'UpLeg', -10);
    S(k2, 'R', 'Leg', 40);
    S(k2, 'R', 'Foot', 20);
    k2.hips = [0, -0.35, 0];
    k2.root = { p: [0, 1.95, 0.3], yaw: 0 };
    const k3 = stand();
    C(k3, 'Hips', 16);
    C(k3, 'Spine', 12);
    S(k3, 'L', 'UpLeg', -60);
    S(k3, 'L', 'Leg', 70);
    flatFoot(k3, 'L');
    S(k3, 'R', 'UpLeg', -20);
    S(k3, 'R', 'Leg', 50);
    flatFoot(k3, 'R', 20);
    k3.hips = [0, -0.2, 0];
    k3.root = { p: [0, 2.1, 0.5], yaw: 0 };
    const k4 = stand();
    k4.root = { p: [0, 2.1, 0.62], yaw: 0 };
    def('mantle', 'Transpor borda (mantle)', 'Escalada', keyed('mantle', 1.7, [[0, k0], [0.45, k1], [0.9, k2], [1.25, k3], [1.7, k4]]), { rootMotion: true, desc: 'Sobe sobre a borda: tração, apoio das mãos e passo final.', prop: 'ledge' });
  }
  {
    const k0 = stand();
    k0.root = { p: [0, 0, 0], yaw: 0 };
    const k1 = stand();
    C(k1, 'Hips', 30);
    C(k1, 'Spine', 16);
    B(k1, 'Arm', -62, 0, 4);
    B(k1, 'ForeArm', -10);
    B(k1, 'Hand', 50);
    B(k1, 'UpLeg', -55);
    B(k1, 'Leg', 70);
    flatFoot(k1, 'L');
    flatFoot(k1, 'R');
    k1.hips = [0, -0.16, 0];
    k1.root = { p: [0, 0, 0.25], yaw: 0 };
    const k2 = stand();
    C(k2, 'Hips', 20, 0, -18);
    C(k2, 'Spine', 14, 0, 10);
    B(k2, 'Arm', 10, 0, 10);
    B(k2, 'Hand', 60);
    S(k2, 'L', 'UpLeg', -95, 0, 30);
    S(k2, 'L', 'Leg', 70);
    S(k2, 'R', 'UpLeg', -80, 0, 10);
    S(k2, 'R', 'Leg', 110);
    k2.hips = [-0.12, 0.25, 0];
    k2.root = { p: [0, 0.2, 0.8], yaw: 0 };
    const k3 = crouchPose();
    k3.hips = [0, -0.22, 0];
    B(k3, 'UpLeg', -50);
    B(k3, 'Leg', 80);
    flatFoot(k3, 'L');
    flatFoot(k3, 'R');
    k3.root = { p: [0, 0, 1.3], yaw: 0 };
    const k4 = stand();
    k4.root = { p: [0, 0, 1.45], yaw: 0 };
    def('climb_over', 'Transpor obstáculo', 'Escalada', keyed('climb_over', 1.5, [[0, k0], [0.35, k1], [0.75, k2], [1.1, k3], [1.5, k4]]), { rootMotion: true, desc: 'Apoia as mãos e passa as pernas sobre um bloco.', prop: 'obstacle' });
  }
  {
    const s1 = clone(ci);
    S(s1, 'R', 'Arm', -70, 0, 45);
    S(s1, 'R', 'ForeArm', -12);
    grip(s1, 'R', 5);
    C(s1, 'Spine1', 4, 18, 8);
    C(s1, 'Head', -10, -30, 0);
    S(s1, 'L', 'ForeArm', -8);
    S(s1, 'R', 'UpLeg', 4, 0, 20);
    S(s1, 'R', 'Leg', 14);
    s1.hips = [0.08, -0.16, -0.12];
    const s2 = clone(s1);
    S(s2, 'R', 'UpLeg', -55, 0, 10);
    S(s2, 'R', 'Leg', 90);
    S(s2, 'L', 'UpLeg', -10, 0, 10);
    S(s2, 'L', 'Leg', 30);
    s2.hips = [0.04, -0.12, -0.08];
    const s3 = clone(ci);
    S(s3, 'R', 'Arm', -150, 0, 10);
    S(s3, 'R', 'ForeArm', -30);
    s3.hips = [0.02, -0.04, -0.05];
    def('slip_recover', 'Escorregar e recuperar', 'Escalada', keyed('slip_recover', 1.4, [[0, ci], [0.15, s1], [0.5, s2], [0.85, s3], [1.4, ci]]), { desc: 'A mão escorrega, o corpo despenca e recupera o equilíbrio.', prop: 'wall' });
  }
  {
    const wind = clone(ci);
    S(wind, 'R', 'Arm', -178, 10, -6);
    S(wind, 'R', 'ForeArm', -135);
    S(wind, 'R', 'Hand', 20);
    grip(wind, 'R', 85, 60);
    C(wind, 'Spine2', -8, 10, 0);
    C(wind, 'Head', -20, -6, 0);
    const hit = clone(ci);
    S(hit, 'R', 'Arm', -150, 0, 4);
    S(hit, 'R', 'ForeArm', -14);
    S(hit, 'R', 'Hand', -30);
    grip(hit, 'R', 85, 60);
    C(hit, 'Spine2', 6, -4, 0);
    const hold = clone(hit);
    S(hold, 'R', 'ForeArm', -24);
    def('ice_axe_swing', 'Golpe de piolet', 'Escalada', keyed('ice_axe_swing', 1.1, [[0, ci], [0.4, wind], [0.58, hit], [0.75, hold], [1.1, hold]]), { desc: 'Prepara, golpeia e crava o piolet no gelo.', prop: 'wall' });
  }
  def(
    'rope_climb',
    'Escalada com corda',
    'Escalada',
    cycle('rope_climb', 1.5, (p) => {
      const o = P();
      const a = Math.sin(TAU * p);
      C(o, 'Hips', -38);
      C(o, 'Spine', 8);
      C(o, 'Spine1', 8);
      C(o, 'Spine2', 4);
      C(o, 'Neck', 6);
      C(o, 'Head', 4);
      S(o, 'L', 'Arm', -128 - 22 * a, 0, -6);
      S(o, 'L', 'ForeArm', -60 + 30 * a);
      S(o, 'R', 'Arm', -128 + 22 * a, 0, -6);
      S(o, 'R', 'ForeArm', -60 - 30 * a);
      grip(o, 'L', 70, 50);
      grip(o, 'R', 70, 50);
      S(o, 'L', 'UpLeg', -40 - 12 * a, 0, 12);
      S(o, 'L', 'Leg', 60 + 15 * a);
      S(o, 'R', 'UpLeg', -40 + 12 * a, 0, 12);
      S(o, 'R', 'Leg', 60 - 15 * a);
      B(o, 'Foot', -20);
      o.hips = [0, -0.25, -0.1];
      o.root = { p: [0, 0.32 * p, 0], yaw: 0 };
      return o;
    }),
    { loop: true, rootMotion: true, desc: 'Mão sobre mão na corda com os pés empurrando a parede.', prop: 'rope' },
  );
  {
    const k = (h: number) => {
      const o = clone(ci);
      S(o, 'R', 'Arm', -92, 0, -4);
      S(o, 'R', 'ForeArm', h);
      S(o, 'R', 'Hand', -10);
      grip(o, 'R', 85, 60);
      C(o, 'Head', -2, -12, 0);
      return o;
    };
    def('place_piton_wall', 'Fixar piton (parede)', 'Escalada', keyed('place_piton_wall', 1.6, [[0, ci], [0.3, k(-110)], [0.5, k(-45)], [0.7, k(-110)], [0.9, k(-45)], [1.1, k(-110)], [1.25, k(-45)], [1.6, ci]]), { desc: 'Martela um piton na rocha mantendo a outra mão no apoio.', prop: 'wall' });
  }

  // ===== SURVIVAL =====
  def(
    'walk_snow',
    'Andar na neve',
    'Sobrevivência',
    cycle('walk_snow', 1.35, (p) => {
      const o = gaitPose(p, { ...WALK, A: 20, kSwing: 72, kBase: 10, lean: 8, arm: 10, armZ: 2, elbow: 30, bob: 0.03, hipsY: -0.04, twist: 7 });
      return o;
    }),
    { loop: true, desc: 'Passos altos e cuidadosos afundando na neve, braços equilibrando.', speedAxis: 'z', phaseSync: true },
  );
  def(
    'walk_wind',
    'Andar contra o vento',
    'Sobrevivência',
    cycle('walk_wind', 1.2, (p) => {
      const o = gaitPose(p, { ...WALK, A: 17, kSwing: 50, lean: 22, arm: 6, bob: 0.012, hipsY: -0.04, kBase: 12 });
      S(o, 'L', 'Arm', -105, 20, -8);
      S(o, 'L', 'ForeArm', -125, 0, 0);
      S(o, 'L', 'Hand', -10);
      grip(o, 'L', 40);
      C(o, 'Head', 14, -8, 0);
      C(o, 'Neck', 8);
      add(o, 'Spine1', 0, 0, 2 * Math.sin(TAU * p * 2));
      return o;
    }),
    { loop: true, desc: 'Tronco inclinado contra a rajada, braço protegendo o rosto.', speedAxis: 'z', phaseSync: true },
  );
  def(
    'walk_careful',
    'Andar com cuidado (gelo)',
    'Sobrevivência',
    cycle('walk_careful', 1.3, (p) => {
      const o = gaitPose(p, { ...WALK, A: 12, kSwing: 34, kBase: 16, lean: 6, arm: 5, armZ: 18, elbow: 34, bob: 0.008, hipsY: -0.05, twist: 3 });
      return o;
    }),
    { loop: true, desc: 'Passos curtos, joelhos flexionados e braços abertos em superfície escorregadia.', speedAxis: 'z', phaseSync: true },
  );
  def(
    'cold_idle',
    'Reação ao frio',
    'Sobrevivência',
    cycle('cold_idle', 2, (p) => {
      const o = stand();
      const sh = Math.sin(TAU * p * 14);
      C(o, 'Spine', 4);
      C(o, 'Spine1', 6 + 0.8 * sh);
      C(o, 'Spine2', 4);
      C(o, 'Neck', 10);
      C(o, 'Head', 6 + 0.6 * sh);
      B(o, 'Shoulder', 0, 0, 10 + 1.2 * sh);
      B(o, 'Arm', -52, 20, -36);
      B(o, 'ForeArm', -112 + 1.5 * sh, -10, 0);
      B(o, 'Hand', 0, -10, 0);
      grip(o, 'L', 60);
      grip(o, 'R', 60);
      B(o, 'UpLeg', -6, 0, -4);
      B(o, 'Leg', 12);
      flatFoot(o, 'L');
      flatFoot(o, 'R');
      o.hips = [0, -0.02 + 0.002 * sh, 0];
      return o;
    }),
    { loop: true, desc: 'Abraça o corpo, ombros encolhidos e tremores.' },
  );
  def('sit_down', 'Sentar para descansar', 'Sobrevivência', keyed('sit_down', 1.4, [[0, stand()], [0.6, crouchPose()], [1.4, sitPose()]]), { desc: 'Transição para sentar no chão.' });
  def(
    'rest_sit',
    'Descansar (sentado)',
    'Sobrevivência',
    cycle('rest_sit', 4.5, (p) => {
      const o = sitPose();
      const br = Math.sin(TAU * p);
      add(o, 'Spine1', 1.8 * br);
      add(o, 'Spine2', 1.2 * br);
      add(o, 'Head', 0, 14 * Math.sin(TAU * p * 0.5 + 0.3) * 0.6, 0);
      return o;
    }),
    { loop: true, desc: 'Sentado recuperando stamina, respiração lenta.' },
  );
  {
    const k = (h: number) => {
      const o = crouchPose();
      S(o, 'R', 'UpLeg', 10, 0, 6);
      S(o, 'R', 'Leg', 110);
      S(o, 'R', 'Foot', 40);
      S(o, 'L', 'UpLeg', -84);
      S(o, 'L', 'Leg', 92);
      flatFoot(o, 'L');
      o.hips = [0, -0.48, 0];
      C(o, 'Spine', 22);
      C(o, 'Head', 10);
      S(o, 'L', 'Arm', -52, 0, -10);
      S(o, 'L', 'ForeArm', -30);
      S(o, 'R', 'Arm', -72, 0, -10);
      S(o, 'R', 'ForeArm', h);
      grip(o, 'R', 85, 60);
      return o;
    };
    def('place_piton_ground', 'Usar equipamento (piton)', 'Sobrevivência', keyed('place_piton_ground', 2.2, [[0, stand()], [0.5, k(-100)], [0.75, k(-40)], [1, k(-100)], [1.25, k(-40)], [1.5, k(-100)], [2.2, stand()]]), { desc: 'Ajoelha e crava um piton para a ancoragem.' });
  }
  {
    const m = stand();
    S(m, 'R', 'Arm', -52, 0, -16);
    S(m, 'R', 'ForeArm', -142, 10, 0);
    S(m, 'R', 'Hand', -20);
    grip(m, 'R', 60);
    C(m, 'Head', -14);
    C(m, 'Neck', -4);
    const m2 = clone(m);
    C(m2, 'Head', -20);
    def('use_item', 'Comer / beber', 'Sobrevivência', keyed('use_item', 2.4, [[0, stand()], [0.6, m], [1.4, m2], [1.8, m], [2.4, stand()]]), { desc: 'Leva a ração ou o chá à boca.' });
  }
  return L;
}

/** removes Root tracks (in-place version) */
export function stripRoot(clip: THREE.AnimationClip): THREE.AnimationClip {
  const c = clip.clone();
  c.tracks = c.tracks.filter((t) => !t.name.startsWith('Root.'));
  return c;
}

/** keeps only tracks for the given bones */
export function maskClip(clip: THREE.AnimationClip, bones: Set<string>, suffix: string): THREE.AnimationClip {
  const c = clip.clone();
  c.name = clip.name + suffix;
  c.tracks = c.tracks.filter((t) => bones.has(t.name.split('.')[0]));
  return c;
}

let cache: ClipDef[] | null = null;
export function getClipLibrary(): ClipDef[] {
  if (cache) return cache;
  cache = build().map((d) => ({ ...d, inPlace: stripRoot(d.clip) }));
  return cache;
}

export const CATEGORIES: Category[] = ['Movimento básico', 'Ações', 'Escalada', 'Sobrevivência'];
