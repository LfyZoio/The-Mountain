import * as THREE from 'three';

const _a = new THREE.Vector3(),
  _b = new THREE.Vector3(),
  _c = new THREE.Vector3(),
  _t = new THREE.Vector3(),
  _d = new THREE.Vector3(),
  _pl = new THREE.Vector3(),
  _e = new THREE.Vector3(),
  _f = new THREE.Vector3(),
  _g = new THREE.Vector3();
const _q = new THREE.Quaternion(),
  _bw = new THREE.Quaternion(),
  _pw = new THREE.Quaternion();

/** Rotates a bone (in world space) so that direction `from` aligns with `to`. */
export function rotateBoneWorld(bone: THREE.Object3D, from: THREE.Vector3, to: THREE.Vector3, weight = 1) {
  if (from.lengthSq() < 1e-10 || to.lengthSq() < 1e-10) return;
  _q.setFromUnitVectors(_f.copy(from).normalize(), _g.copy(to).normalize());
  if (weight < 1) _q.slerp(new THREE.Quaternion(), 1 - weight);
  applyWorldDelta(bone, _q);
}

/** newWorld = delta * world  →  local = parentWorld⁻¹ · delta · world */
export function applyWorldDelta(bone: THREE.Object3D, delta: THREE.Quaternion) {
  bone.getWorldQuaternion(_bw);
  if (bone.parent) bone.parent.getWorldQuaternion(_pw);
  else _pw.identity();
  bone.quaternion.copy(_pw.invert().multiply(delta).multiply(_bw));
  bone.updateMatrixWorld(true);
}

/** Sets the world orientation of a bone (blended by weight). */
export function setWorldQuaternion(bone: THREE.Object3D, q: THREE.Quaternion, weight = 1) {
  bone.getWorldQuaternion(_bw);
  const target = _bw.clone().slerp(q, weight);
  if (bone.parent) bone.parent.getWorldQuaternion(_pw);
  else _pw.identity();
  bone.quaternion.copy(_pw.invert().multiply(target));
  bone.updateMatrixWorld(true);
}

/**
 * Analytic two-bone IK (shoulder-elbow-wrist / hip-knee-ankle) with pole vector.
 * Lengths are preserved; `weight` blends between animated and solved pose.
 */
export function solveTwoBone(upper: THREE.Bone, lower: THREE.Bone, end: THREE.Bone, target: THREE.Vector3, pole: THREE.Vector3, weight = 1) {
  if (weight <= 0.001) return;
  upper.updateMatrixWorld(true);
  upper.getWorldPosition(_a);
  lower.getWorldPosition(_b);
  end.getWorldPosition(_c);
  const la = _a.distanceTo(_b),
    lb = _b.distanceTo(_c);
  _t.lerpVectors(_c, target, Math.min(1, weight));
  _d.subVectors(_t, _a);
  const dist = Math.max(1e-4, Math.min(_d.length(), (la + lb) * 0.9995));
  _d.normalize();
  const x = (dist * dist + la * la - lb * lb) / (2 * dist);
  const h = Math.sqrt(Math.max(0, la * la - x * x));
  _pl.subVectors(pole, _a);
  _pl.addScaledVector(_d, -_pl.dot(_d));
  if (_pl.lengthSq() < 1e-8) {
    _pl.subVectors(_b, _a).addScaledVector(_d, -_e.subVectors(_b, _a).dot(_d));
    if (_pl.lengthSq() < 1e-8) _pl.set(0, 0, 1);
  }
  _pl.normalize();
  _e.copy(_a).addScaledVector(_d, x).addScaledVector(_pl, h); // desired elbow
  rotateBoneWorld(upper, _f.subVectors(_b, _a).clone(), _g.subVectors(_e, _a).clone());
  lower.getWorldPosition(_b);
  end.getWorldPosition(_c);
  const goal = _a.clone().addScaledVector(_d, dist);
  rotateBoneWorld(lower, _f.subVectors(_c, _b).clone(), _g.subVectors(goal, _b).clone());
}
