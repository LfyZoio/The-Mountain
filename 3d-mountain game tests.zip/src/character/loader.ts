import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { BONE_DEFS, BONE_WORLD, DEFORM_BONES, HEIGHT, PRIMARY_CHILD, canonicalBoneName, createSkeleton } from './skeleton';
import { buildSegments, computeSkin } from './skinning';
import { buildStandIn } from './standIn';
import { CharacterModel, Retargeter } from './model';

const D = Math.PI / 180;
const BIND_ARM = 20 * D;

// ---------------------------------------------------------------- stand-in
export function createStandInModel(): CharacterModel {
  const s = buildStandIn();
  const object = new THREE.Group();
  object.name = 'MOUNTAIN_Protagonist';
  const rigRoot = new THREE.Group();
  rigRoot.name = 'Rig';
  rigRoot.add(s.bones.Root);
  s.group.remove(s.mesh);
  const exportRoot = new THREE.Group();
  exportRoot.name = 'Protagonist';
  exportRoot.add(rigRoot, s.mesh);
  object.add(exportRoot);
  return {
    object,
    rigRoot,
    bones: s.bones,
    skeleton: s.skeleton,
    meshes: [s.mesh],
    axe: s.axe,
    source: 'standin',
    name: 'Stand-in temporário (referência)',
    triangles: Math.round(s.triangles),
    corrections: new Map(),
    helperRoot: rigRoot,
    exportRoot,
    notes: ['Modelo provisório gerado a partir das imagens de referência — substitua pelo seu arquivo 3D.'],
  };
}

// ---------------------------------------------------------------- parsing
export async function parseModelFile(buf: ArrayBuffer, filename: string): Promise<{ scene: THREE.Object3D; animations: THREE.AnimationClip[] }> {
  const ext = filename.toLowerCase().split('.').pop();
  if (ext === 'glb' || ext === 'gltf') {
    const loader = new GLTFLoader();
    const data: ArrayBuffer | string = ext === 'gltf' ? new TextDecoder().decode(buf) : buf;
    const gltf = await new Promise<any>((res, rej) => loader.parse(data, '', res, rej));
    return { scene: gltf.scene, animations: gltf.animations || [] };
  }
  if (ext === 'fbx') {
    const obj = new FBXLoader().parse(buf, '');
    return { scene: obj, animations: (obj as any).animations || [] };
  }
  if (ext === 'obj') {
    const obj = new OBJLoader().parse(new TextDecoder().decode(buf));
    return { scene: obj, animations: [] };
  }
  throw new Error('Formato não suportado. Use .glb, .gltf, .fbx ou .obj');
}

/** wraps and normalizes: Y-up, faces +Z, feet at y=0, height = 1.8 m */
function normalize(scene: THREE.Object3D, facingDeg: number) {
  const wrap = new THREE.Group();
  wrap.name = 'ImportedModel';
  const inner = new THREE.Group();
  inner.rotation.y = facingDeg * D;
  inner.add(scene);
  wrap.add(inner);
  scene.traverse((o) => {
    const sm = o as THREE.SkinnedMesh;
    if (sm.isSkinnedMesh) sm.skeleton.pose();
  });
  wrap.updateMatrixWorld(true);
  const box = new THREE.Box3();
  scene.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      m.geometry.computeBoundingBox();
      const bb = m.geometry.boundingBox!.clone().applyMatrix4(m.matrixWorld);
      box.union(bb);
    }
  });
  const size = box.getSize(new THREE.Vector3());
  const s = HEIGHT / Math.max(1e-6, size.y);
  inner.scale.setScalar(s);
  inner.position.set(-((box.min.x + box.max.x) / 2) * s, -box.min.y * s, -((box.min.z + box.max.z) / 2) * s);
  // rotation is applied before scale/translate in inner: recompute after rotation
  wrap.updateMatrixWorld(true);
  const box2 = new THREE.Box3();
  scene.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) box2.union(m.geometry.boundingBox!.clone().applyMatrix4(m.matrixWorld));
  });
  inner.position.x -= (box2.min.x + box2.max.x) / 2;
  inner.position.z -= (box2.min.z + box2.max.z) / 2;
  inner.position.y -= box2.min.y;
  wrap.updateMatrixWorld(true);
  return wrap;
}

function setBindPositions(byName: Record<string, THREE.Bone>, world: Record<string, THREE.Vector3>) {
  for (const d of BONE_DEFS) {
    const b = byName[d.name];
    const pw = d.parent ? world[d.parent] : new THREE.Vector3();
    b.position.copy(world[d.name]).sub(pw);
    b.quaternion.identity();
  }
  byName.Root.updateMatrixWorld(true);
}

/** re-angles an arm chain to the canonical A-pose keeping segment lengths */
function reangleArm(world: Record<string, THREE.Vector3>, side: 'Left' | 'Right', lenUpper: number, lenFore: number) {
  const s = side === 'Left' ? 1 : -1;
  const dir = new THREE.Vector3(Math.sin(BIND_ARM) * s, -Math.cos(BIND_ARM), 0);
  const arm = world[`${side}Arm`];
  const oldHand = world[`${side}Hand`].clone();
  world[`${side}ForeArm`] = arm.clone().addScaledVector(dir, lenUpper);
  world[`${side}Hand`] = world[`${side}ForeArm`].clone().addScaledVector(dir, lenFore);
  const k = (lenUpper + lenFore) / 0.55;
  for (const d of BONE_DEFS) {
    if (d.name.startsWith(`${side}Hand`) && d.name !== `${side}Hand`) {
      const rel = BONE_WORLD[d.name].clone().sub(BONE_WORLD[`${side}Hand`]).multiplyScalar(k);
      world[d.name] = world[`${side}Hand`].clone().add(rel);
    }
  }
  void oldHand;
}

// ---------------------------------------------------------------- auto-rig (static mesh)
function autoRig(wrap: THREE.Object3D, name: string): CharacterModel {
  const meshes: THREE.Mesh[] = [];
  wrap.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) meshes.push(m);
  });
  if (!meshes.length) throw new Error('Nenhuma malha encontrada no arquivo.');
  // gather all vertices in normalized space for fitting
  const pts: THREE.Vector3[] = [];
  const baked: { geo: THREE.BufferGeometry; mat: THREE.Material | THREE.Material[] }[] = [];
  let tris = 0;
  for (const m of meshes) {
    const g = m.geometry.clone();
    g.applyMatrix4(m.matrixWorld);
    if (!g.attributes.normal) g.computeVertexNormals();
    g.deleteAttribute('skinIndex');
    g.deleteAttribute('skinWeight');
    baked.push({ geo: g, mat: m.material });
    tris += (g.index ? g.index.count : g.attributes.position.count) / 3;
    const p = g.attributes.position;
    const step = Math.max(1, Math.floor(p.count / 6000));
    for (let i = 0; i < p.count; i += step) pts.push(new THREE.Vector3().fromBufferAttribute(p, i));
  }
  // --- fit skeleton
  const world: Record<string, THREE.Vector3> = Object.fromEntries(Object.entries(BONE_WORLD).map(([k, v]) => [k, v.clone()]));
  const notes: string[] = [];
  const corrections = new Map<string, THREE.Quaternion>();
  for (const side of ['Left', 'Right'] as const) {
    const s = side === 'Left' ? 1 : -1;
    // legs: lateral position from the shin region
    const shin = pts.filter((p) => p.y > 0.25 && p.y < 0.5 && p.x * s > 0.02);
    if (shin.length > 10) {
      const cx = shin.reduce((a, p) => a + p.x, 0) / shin.length;
      for (const b of ['UpLeg', 'Leg', 'Foot', 'ToeBase', 'Toe_End']) world[`${side}${b}`].x = cx;
    }
    // arms: estimate from the outermost points below the shoulder
    const arm = world[`${side}Arm`];
    const cand = pts.filter((p) => p.x * s > 0.23 && p.y < 1.42 && p.y > 0.55);
    if (cand.length > 20) {
      cand.sort((a, b) => a.y - b.y);
      const tipSet = cand.slice(0, Math.max(5, Math.floor(cand.length * 0.06)));
      const tip = tipSet.reduce((a, p) => a.add(p), new THREE.Vector3()).divideScalar(tipSet.length);
      // horizontal arms (T-pose): outermost points instead
      const far = [...cand].sort((a, b) => b.x * s - a.x * s).slice(0, 8).reduce((a, p) => a.add(p), new THREE.Vector3()).divideScalar(8);
      const useFar = Math.abs(far.x) > Math.abs(tip.x) + 0.15 && far.y > 1.2;
      const t = useFar ? far : tip;
      const d = t.clone().sub(arm);
      const ang = Math.atan2(Math.abs(d.x), -d.y);
      const L = d.length();
      const k = L / 0.745;
      const dir = d.clone().normalize();
      world[`${side}ForeArm`] = arm.clone().addScaledVector(dir, 0.29 * k);
      world[`${side}Hand`] = arm.clone().addScaledVector(dir, 0.55 * k);
      for (const b of BONE_DEFS)
        if (b.name.startsWith(`${side}Hand`) && b.name !== `${side}Hand`) {
          const rel = BONE_WORLD[b.name].clone().sub(BONE_WORLD[`${side}Hand`]);
          rel.applyAxisAngle(new THREE.Vector3(0, 0, 1), (ang - BIND_ARM) * s).multiplyScalar(k);
          world[b.name] = world[`${side}Hand`].clone().add(rel);
        }
      const delta = ang - BIND_ARM;
      if (Math.abs(delta) > 2 * D) corrections.set(`${side}Arm`, new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), -delta * s));
      if (side === 'Left') notes.push(`Ângulo dos braços detectado: ${(ang / D).toFixed(0)}° (rig compensado para A-pose).`);
    }
  }
  const { root, byName, skeleton } = createSkeleton();
  setBindPositions(byName, world);
  skeleton.calculateInverses();
  const segs = buildSegments(world, DEFORM_BONES);
  const rigRoot = new THREE.Group();
  rigRoot.name = 'Rig';
  rigRoot.add(root);
  const exportRoot = new THREE.Group();
  exportRoot.name = 'Protagonist';
  exportRoot.add(rigRoot);
  const outMeshes: THREE.SkinnedMesh[] = [];
  for (const { geo, mat } of baked) {
    computeSkin(geo, segs, { falloff: 0.06 });
    const sm = new THREE.SkinnedMesh(geo, mat);
    sm.castShadow = true;
    sm.receiveShadow = true;
    sm.frustumCulled = false;
    exportRoot.add(sm);
    sm.bind(skeleton, new THREE.Matrix4());
    outMeshes.push(sm);
  }
  const object = new THREE.Group();
  object.name = 'MOUNTAIN_Protagonist';
  object.add(exportRoot);
  notes.unshift(`Auto-rig aplicado: ${DEFORM_BONES.length} ossos deformantes, pesos calculados por distância aos segmentos.`);
  return { object, rigRoot, bones: byName, skeleton, meshes: outMeshes, axe: null, source: 'autorig', name, triangles: Math.round(tris), corrections, helperRoot: rigRoot, exportRoot, notes };
}

// ---------------------------------------------------------------- retarget (existing humanoid rig)
const CORE = ['Hips', 'Spine', 'Head', 'LeftArm', 'LeftForeArm', 'LeftHand', 'RightArm', 'RightForeArm', 'RightHand', 'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'RightUpLeg', 'RightLeg', 'RightFoot'];

function findHumanoid(wrap: THREE.Object3D) {
  const bones = new Set<THREE.Bone>();
  wrap.traverse((o) => {
    const sm = o as THREE.SkinnedMesh;
    if (sm.isSkinnedMesh) sm.skeleton.bones.forEach((b) => bones.add(b));
  });
  const map: Record<string, THREE.Bone> = {};
  for (const b of bones) {
    const c = canonicalBoneName(b.name);
    if (c && !map[c]) map[c] = b;
  }
  const core = CORE.filter((c) => map[c]).length;
  return { bones: [...bones], map, core };
}

function retargetRig(wrap: THREE.Object3D, name: string, h: ReturnType<typeof findHumanoid>): CharacterModel {
  const object = new THREE.Group();
  object.name = 'MOUNTAIN_Protagonist';
  object.add(wrap);
  object.updateMatrixWorld(true);
  const tw = (b: THREE.Bone) => b.getWorldPosition(new THREE.Vector3()); // object at origin during setup
  const world: Record<string, THREE.Vector3> = Object.fromEntries(Object.entries(BONE_WORLD).map(([k, v]) => [k, v.clone()]));
  for (const [c, b] of Object.entries(h.map)) if (world[c]) world[c] = tw(b);
  // fix hierarchy end bones
  if (h.map.Head) world.HeadTop_End = world.Head.clone().add(new THREE.Vector3(0, HEIGHT - world.Head.y, 0));
  for (const side of ['Left', 'Right'] as const) {
    const lu = world[`${side}ForeArm`].distanceTo(world[`${side}Arm`]);
    const lf = world[`${side}Hand`].distanceTo(world[`${side}ForeArm`]);
    reangleArm(world, side, lu, lf);
    // toes
    if (!h.map[`${side}ToeBase`]) world[`${side}ToeBase`] = world[`${side}Foot`].clone().add(new THREE.Vector3(0, -0.06, 0.13));
    world[`${side}Toe_End`] = world[`${side}ToeBase`].clone().add(new THREE.Vector3(0, 0, 0.08));
  }
  // extras follow the torso
  world.Backpack = world.Spine2.clone().add(new THREE.Vector3(0, -0.05, -0.2));
  world.IceAxe_Pack = world.Backpack.clone().add(new THREE.Vector3(0.17, 0.12, -0.07));
  world.HeadLamp = world.Head.clone().add(new THREE.Vector3(0, 0.14, 0.1));
  const { root, byName, skeleton } = createSkeleton();
  setBindPositions(byName, world);
  const rigRoot = new THREE.Group();
  rigRoot.name = 'Rig';
  rigRoot.add(root);
  object.add(rigRoot);
  object.updateMatrixWorld(true);

  // rest data
  const objInv = new THREE.Quaternion();
  const theirs = [...h.bones].sort((a, b) => depth(a) - depth(b));
  const ourOf = new Map<THREE.Bone, string>();
  for (const [c, b] of Object.entries(h.map)) if (byName[c]) ourOf.set(b, c);
  const W = new Map<THREE.Bone, THREE.Quaternion>();
  const Cq = new Map<THREE.Bone, THREE.Quaternion>();
  for (const b of theirs) W.set(b, b.getWorldQuaternion(new THREE.Quaternion()));
  const childMapped = (c: string) => PRIMARY_CHILD[c];
  for (const b of theirs) {
    const c = ourOf.get(b);
    if (!c) continue;
    const ch = childMapped(c);
    const tb = ch ? h.map[ch] : null;
    if (ch && tb && world[ch]) {
      const our = world[ch].clone().sub(world[c]).normalize();
      const their = tw(tb).sub(tw(b)).normalize();
      Cq.set(b, new THREE.Quaternion().setFromUnitVectors(their, our));
    }
  }
  // inherit corrections for end bones (hands, head, feet)
  for (const b of theirs) {
    if (!ourOf.has(b) || Cq.has(b)) continue;
    let p = b.parent;
    while (p && !(Cq.has(p as THREE.Bone))) p = p.parent;
    Cq.set(b, p ? Cq.get(p as THREE.Bone)!.clone() : new THREE.Quaternion());
  }
  const hipsT = h.map.Hips;
  const hipsRestOur = world.Hips.clone();
  const hipsRestTheir = hipsT ? tw(hipsT) : new THREE.Vector3();
  const G = new Map<THREE.Bone, THREE.Quaternion>();
  const tmpQ = new THREE.Quaternion();
  const retarget: Retargeter = {
    targetBones: theirs,
    mapped: ourOf.size,
    apply() {
      object.getWorldQuaternion(objInv).invert();
      G.clear();
      for (const b of theirs) {
        const c = ourOf.get(b);
        let g: THREE.Quaternion;
        const parentIsBone = !!(b.parent && G.has(b.parent as THREE.Bone));
        const parentRel = parentIsBone ? G.get(b.parent as THREE.Bone)!.clone() : objInv.clone().multiply(b.parent!.getWorldQuaternion(tmpQ));
        if (c) {
          g = objInv.clone().multiply(byName[c].getWorldQuaternion(tmpQ)).multiply(Cq.get(b)!).multiply(W.get(b)!);
        } else {
          const wp = parentIsBone ? W.get(b.parent as THREE.Bone)! : parentRel;
          g = parentRel.clone().multiply(wp.clone().invert()).multiply(W.get(b)!);
        }
        G.set(b, g);
        b.quaternion.copy(parentRel.invert().multiply(g));
        b.updateMatrix();
        b.updateMatrixWorld(true);
      }
      if (hipsT) {
        const ourHips = byName.Hips.getWorldPosition(new THREE.Vector3());
        const local = object.worldToLocal(ourHips).add(hipsRestTheir).sub(hipsRestOur);
        const wpos = object.localToWorld(local);
        hipsT.position.copy(hipsT.parent!.worldToLocal(wpos));
        hipsT.updateMatrixWorld(true);
      }
    },
  };
  const meshes: THREE.Object3D[] = [];
  let tris = 0;
  wrap.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      meshes.push(m);
      m.castShadow = true;
      m.frustumCulled = false;
      tris += (m.geometry.index ? m.geometry.index.count : m.geometry.attributes.position.count) / 3;
    }
  });
  return {
    object,
    rigRoot,
    bones: byName,
    skeleton,
    meshes,
    axe: null,
    source: 'retarget',
    name,
    triangles: Math.round(tris),
    retarget,
    corrections: new Map(),
    helperRoot: theirs[0] ?? rigRoot,
    exportRoot: wrap,
    notes: [`Rig humanoide detectado: ${ourOf.size} ossos mapeados (${h.core}/${CORE.length} essenciais). Animações retargetizadas em tempo real.`],
  };
}

function depth(o: THREE.Object3D) {
  let d = 0;
  while (o.parent) {
    d++;
    o = o.parent;
  }
  return d;
}

export async function buildModelFromFile(buf: ArrayBuffer, filename: string, facingDeg = 0, forceAutoRig = false): Promise<CharacterModel> {
  const { scene } = await parseModelFile(buf, filename);
  const wrap = normalize(scene, facingDeg);
  const h = findHumanoid(wrap);
  const name = filename.replace(/\.[^.]+$/, '');
  if (!forceAutoRig && h.core >= 12) return retargetRig(wrap, name, h);
  return autoRig(wrap, name);
}

// ---------------------------------------------------------------- persistence (IndexedDB)
const DB = 'mountain-character';
function idb(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore('files');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
export interface StoredModel {
  name: string;
  buf: ArrayBuffer;
  facing: number;
  forceAutoRig: boolean;
}
export async function saveUserModel(m: StoredModel) {
  const db = await idb();
  await new Promise<void>((res, rej) => {
    const tx = db.transaction('files', 'readwrite');
    tx.objectStore('files').put(m, 'protagonist');
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  });
}
export async function loadUserModel(): Promise<StoredModel | null> {
  try {
    const db = await idb();
    return await new Promise((res) => {
      const tx = db.transaction('files', 'readonly');
      const r = tx.objectStore('files').get('protagonist');
      r.onsuccess = () => res((r.result as StoredModel) ?? null);
      r.onerror = () => res(null);
    });
  } catch {
    return null;
  }
}
export async function clearUserModel() {
  const db = await idb();
  await new Promise<void>((res) => {
    const tx = db.transaction('files', 'readwrite');
    tx.objectStore('files').delete('protagonist');
    tx.oncomplete = () => res();
    tx.onerror = () => res();
  });
}

/** Model used by the game: user model (IndexedDB) → public/models/protagonist.glb → stand-in */
export async function loadProtagonist(): Promise<CharacterModel> {
  const stored = await loadUserModel();
  if (stored) {
    try {
      return await buildModelFromFile(stored.buf, stored.name, stored.facing, stored.forceAutoRig);
    } catch (e) {
      console.warn('Falha ao carregar modelo salvo', e);
    }
  }
  try {
    const r = await fetch('models/protagonist.glb');
    if (r.ok && (r.headers.get('content-type') || '').indexOf('html') < 0) {
      const buf = await r.arrayBuffer();
      return await buildModelFromFile(buf, 'protagonist.glb', 0);
    }
  } catch {
    /* no bundled model */
  }
  return createStandInModel();
}
