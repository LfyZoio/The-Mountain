import * as THREE from 'three';

/**
 * Humanoid skeleton for "MOUNTAIN — Beyond the Summit".
 *
 * Conventions (bind pose):
 *  - Character faces +Z, up is +Y, character's LEFT is +X.
 *  - Every bone's bind orientation is identity (world-aligned). Animation
 *    rotations are therefore authored in an intuitive parent-aligned frame:
 *      X+  = pitch forward (spine/head lean forward, thigh/arm swing BACK)
 *      Z   = roll/abduction (use side multiplier for mirrored limbs)
 *  - Bind pose is a relaxed A-pose (arms ~20° from the body), matching the
 *    reference sheet of the protagonist.
 *  - Bone names follow the Mixamo humanoid convention (without prefix) so the
 *    rig is directly compatible with Unity Humanoid / Unreal retargeting.
 */

export type Side = 'Left' | 'Right';

export interface BoneDef {
  name: string;
  parent: string | null;
  /** head position in WORLD space (bind pose, meters) */
  pos: [number, number, number];
}

export const HEIGHT = 1.8;
const A = (20 * Math.PI) / 180; // arm abduction in bind pose

const defs: BoneDef[] = [];
const add = (name: string, parent: string | null, pos: [number, number, number]) => defs.push({ name, parent, pos });

add('Root', null, [0, 0, 0]);
add('Hips', 'Root', [0, 0.98, 0]);
add('Spine', 'Hips', [0, 1.08, -0.005]);
add('Spine1', 'Spine', [0, 1.21, -0.01]);
add('Spine2', 'Spine1', [0, 1.35, -0.015]);
add('Neck', 'Spine2', [0, 1.52, -0.01]);
add('Head', 'Neck', [0, 1.61, 0.005]);
add('HeadTop_End', 'Head', [0, 1.8, 0.01]);
// equipment / secondary motion
add('Backpack', 'Spine2', [0, 1.3, -0.2]);
add('IceAxe_Pack', 'Backpack', [0.17, 1.42, -0.27]);
add('HeadLamp', 'Head', [0, 1.75, 0.1]);

for (const side of ['Left', 'Right'] as Side[]) {
  const s = side === 'Left' ? 1 : -1;
  const sh: [number, number, number] = [0.075 * s, 1.47, -0.02];
  const arm: [number, number, number] = [0.2 * s, 1.45, -0.02];
  const dx = Math.sin(A) * s,
    dy = -Math.cos(A);
  const elbow: [number, number, number] = [arm[0] + dx * 0.29, arm[1] + dy * 0.29, -0.025];
  const wrist: [number, number, number] = [elbow[0] + dx * 0.26, elbow[1] + dy * 0.26, -0.01];
  add(`${side}Shoulder`, 'Spine2', sh);
  add(`${side}Arm`, `${side}Shoulder`, arm);
  add(`${side}ForeArm`, `${side}Arm`, elbow);
  add(`${side}Hand`, `${side}ForeArm`, wrist);
  // fingers: palm faces the body (-X for left), fingers point along the arm
  const palm = 0.085;
  const knuck = (off: number, fwd: number): [number, number, number] => [wrist[0] + dx * palm, wrist[1] + dy * palm, wrist[2] + fwd + off];
  const fingers: [string, number, number[]][] = [
    ['Index', 0.028, [0.04, 0.025, 0.02]],
    ['Middle', 0.008, [0.045, 0.028, 0.022]],
    ['Ring', -0.012, [0.042, 0.026, 0.02]],
    ['Pinky', -0.03, [0.033, 0.02, 0.017]],
  ];
  for (const [fname, fwd, lens] of fingers) {
    let p = knuck(0, fwd);
    let parent = `${side}Hand`;
    for (let j = 0; j < 3; j++) {
      const n = `${side}Hand${fname}${j + 1}`;
      add(n, parent, p);
      p = [p[0] + dx * lens[j], p[1] + dy * lens[j], p[2]];
      parent = n;
    }
    add(`${side}Hand${fname}4`, parent, p);
  }
  // thumb: starts at base of palm, points forward/down
  let tp: [number, number, number] = [wrist[0] + dx * 0.025 - 0.012 * s, wrist[1] + dy * 0.025, wrist[2] + 0.03];
  let parent = `${side}Hand`;
  const tl = [0.035, 0.03, 0.025];
  for (let j = 0; j < 3; j++) {
    const n = `${side}HandThumb${j + 1}`;
    add(n, parent, tp);
    tp = [tp[0] + dx * tl[j] * 0.6, tp[1] + dy * tl[j] * 0.6, tp[2] + tl[j] * 0.75];
    parent = n;
  }
  add(`${side}HandThumb4`, parent, tp);

  add(`${side}UpLeg`, 'Hips', [0.095 * s, 0.93, 0]);
  add(`${side}Leg`, `${side}UpLeg`, [0.1 * s, 0.5, 0.012]);
  add(`${side}Foot`, `${side}Leg`, [0.105 * s, 0.085, -0.01]);
  add(`${side}ToeBase`, `${side}Foot`, [0.11 * s, 0.022, 0.12]);
  add(`${side}Toe_End`, `${side}ToeBase`, [0.11 * s, 0.02, 0.2]);
}

// UE-style IK target bones (children of Root, driven at runtime, exported with the rig)
add('ik_hand_l', 'Root', [0.39, 0.92, 0]);
add('ik_hand_r', 'Root', [-0.39, 0.92, 0]);
add('ik_foot_l', 'Root', [0.105, 0.085, 0]);
add('ik_foot_r', 'Root', [-0.105, 0.085, 0]);

export const BONE_DEFS = defs;
export const BONE_INDEX: Record<string, number> = Object.fromEntries(defs.map((d, i) => [d.name, i]));
export const BONE_WORLD: Record<string, THREE.Vector3> = Object.fromEntries(defs.map((d) => [d.name, new THREE.Vector3(...d.pos)]));

/** Primary child used to define a bone's segment (for skinning / IK). */
export const PRIMARY_CHILD: Record<string, string> = {
  Root: 'Hips',
  Hips: 'Spine',
  Spine: 'Spine1',
  Spine1: 'Spine2',
  Spine2: 'Neck',
  Neck: 'Head',
  Head: 'HeadTop_End',
};
for (const s of ['Left', 'Right']) {
  Object.assign(PRIMARY_CHILD, {
    [`${s}Shoulder`]: `${s}Arm`,
    [`${s}Arm`]: `${s}ForeArm`,
    [`${s}ForeArm`]: `${s}Hand`,
    [`${s}Hand`]: `${s}HandMiddle1`,
    [`${s}UpLeg`]: `${s}Leg`,
    [`${s}Leg`]: `${s}Foot`,
    [`${s}Foot`]: `${s}ToeBase`,
    [`${s}ToeBase`]: `${s}Toe_End`,
  });
  for (const f of ['Index', 'Middle', 'Ring', 'Pinky', 'Thumb']) for (let j = 1; j <= 3; j++) PRIMARY_CHILD[`${s}Hand${f}${j}`] = `${s}Hand${f}${j + 1}`;
}

/** Bones that should be skinned (end/socket/IK bones excluded). */
export const DEFORM_BONES = defs
  .map((d) => d.name)
  .filter((n) => !n.endsWith('_End') && !n.endsWith('4') && !n.startsWith('ik_') && n !== 'Root' && n !== 'HeadLamp' && n !== 'IceAxe_Pack');

/** Creates a fresh bone hierarchy in bind pose. Returns [rootBone, bones[], skeleton]. */
export function createSkeleton(): { root: THREE.Bone; bones: THREE.Bone[]; byName: Record<string, THREE.Bone>; skeleton: THREE.Skeleton } {
  const bones: THREE.Bone[] = [];
  const byName: Record<string, THREE.Bone> = {};
  for (const d of defs) {
    const b = new THREE.Bone();
    b.name = d.name;
    const pw = d.parent ? BONE_WORLD[d.parent] : new THREE.Vector3();
    b.position.set(d.pos[0] - pw.x, d.pos[1] - pw.y, d.pos[2] - pw.z);
    if (d.parent) byName[d.parent].add(b);
    bones.push(b);
    byName[d.name] = b;
  }
  const root = byName.Root;
  root.updateMatrixWorld(true);
  const skeleton = new THREE.Skeleton(bones);
  return { root, bones, byName, skeleton };
}

/** Readable hierarchy (for the lab / documentation). */
export function hierarchyTree(): { name: string; depth: number }[] {
  const out: { name: string; depth: number }[] = [];
  const kids: Record<string, string[]> = {};
  for (const d of defs) if (d.parent) (kids[d.parent] ||= []).push(d.name);
  const walk = (n: string, depth: number) => {
    out.push({ name: n, depth });
    for (const c of kids[n] || []) walk(c, depth + 1);
  };
  walk('Root', 0);
  return out;
}

/** Mapping of common rig naming conventions → our names (retargeting). */
export function canonicalBoneName(raw: string): string | null {
  let n = raw.replace(/^mixamorig[:_]?\d*[:_]?/i, '').replace(/^(armature|rig|skeleton)[|:_.]/i, '').replace(/^[A-Za-z]+:/, '');
  const low = n.toLowerCase().replace(/[\s._-]/g, '');
  // direct match
  for (const d of defs) if (d.name.toLowerCase() === low) return d.name;
  let side: Side | null = null;
  let body = low;
  const m = low.match(/^(left|right|l|r)(.*)$/) || low.match(/^(.*?)(left|right|l|r)$/);
  if (/^(left|l)(?=[a-z])/.test(low) && !/^leg/.test(low)) {
    side = 'Left';
    body = low.replace(/^(left|l)/, '');
  } else if (/^(right|r)(?=[a-z])/.test(low)) {
    side = 'Right';
    body = low.replace(/^(right|r)/, '');
  } else if (m && /(left|l)$/.test(low)) {
    side = 'Left';
    body = low.replace(/(left|l)$/, '');
  } else if (m && /(right|r)$/.test(low)) {
    side = 'Right';
    body = low.replace(/(right|r)$/, '');
  }
  const center: Record<string, string> = {
    pelvis: 'Hips', hips: 'Hips', hip: 'Hips', root: 'Root', spine: 'Spine', spine01: 'Spine', spine1: 'Spine1', spine02: 'Spine1', chest: 'Spine1', spine2: 'Spine2', spine03: 'Spine2', upperchest: 'Spine2', neck: 'Neck', neck01: 'Neck', head: 'Head',
  };
  if (!side) return center[body] ?? null;
  const limb: Record<string, string> = {
    shoulder: 'Shoulder', clavicle: 'Shoulder', arm: 'Arm', upperarm: 'Arm', forearm: 'ForeArm', lowerarm: 'ForeArm', hand: 'Hand', upleg: 'UpLeg', thigh: 'UpLeg', upperleg: 'UpLeg', leg: 'Leg', calf: 'Leg', lowerleg: 'Leg', shin: 'Leg', foot: 'Foot', toebase: 'ToeBase', toe: 'ToeBase', ball: 'ToeBase', toes: 'ToeBase',
  };
  if (limb[body]) return side + limb[body];
  const fm = body.match(/^(?:hand)?(thumb|index|middle|ring|pinky)(?:finger)?0?(\d)$/);
  if (fm) {
    const fname = fm[1][0].toUpperCase() + fm[1].slice(1);
    return `${side}Hand${fname}${fm[2]}`;
  }
  return null;
}
