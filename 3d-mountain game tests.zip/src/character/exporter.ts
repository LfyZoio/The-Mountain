import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { ClipDef } from './clips';
import { CharacterModel } from './model';
import { hierarchyTree } from './skeleton';

/**
 * Export-ready assets:
 *  - binary glTF (.glb) with the skinned character, humanoid skeleton (incl. IK target bones)
 *    and the selected animation clips (root-motion clips keep their Root tracks,
 *    locomotion clips are exported in-place).
 *  - For imported rigs (retarget mode) clips are baked onto the ORIGINAL skeleton.
 */
export async function exportGLB(model: CharacterModel, clips: ClipDef[], rootMotion = true): Promise<Blob> {
  const saved = new Map<THREE.Object3D, { p: THREE.Vector3; q: THREE.Quaternion; s: THREE.Vector3 }>();
  const objPos = model.object.position.clone();
  const objQ = model.object.quaternion.clone();
  model.object.position.set(0, 0, 0);
  model.object.quaternion.identity();
  model.object.updateMatrixWorld(true);
  const restore = () => {
    for (const [o, t] of saved) {
      o.position.copy(t.p);
      o.quaternion.copy(t.q);
      o.scale.copy(t.s);
    }
    model.object.position.copy(objPos);
    model.object.quaternion.copy(objQ);
    model.object.updateMatrixWorld(true);
  };
  let animations: THREE.AnimationClip[];
  let input: THREE.Object3D;
  if (model.source === 'retarget' && model.retarget) {
    animations = bakeRetarget(model, clips, rootMotion, saved);
    input = model.exportRoot;
  } else {
    animations = clips.map((c) => {
      const clip = (rootMotion && c.rootMotion ? c.clip : c.inPlace).clone();
      clip.name = c.name;
      return clip;
    });
    input = model.exportRoot;
    // bind pose as rest
    for (const b of Object.values(model.bones)) saved.set(b, { p: b.position.clone(), q: b.quaternion.clone(), s: b.scale.clone() });
    model.skeleton.pose();
  }
  input.updateMatrixWorld(true);
  try {
    const result = await new Promise<ArrayBuffer>((res, rej) =>
      new GLTFExporter().parse(input, (r) => res(r as ArrayBuffer), (e) => rej(e), { binary: true, animations, onlyVisible: false }),
    );
    return new Blob([result], { type: 'model/gltf-binary' });
  } finally {
    restore();
  }
}

function bakeRetarget(model: CharacterModel, clips: ClipDef[], rootMotion: boolean, saved: Map<THREE.Object3D, any>): THREE.AnimationClip[] {
  const rt = model.retarget!;
  const mixer = new THREE.AnimationMixer(model.rigRoot);
  const out: THREE.AnimationClip[] = [];
  const bones = rt.targetBones;
  for (const b of bones) saved.set(b, { p: b.position.clone(), q: b.quaternion.clone(), s: b.scale.clone() });
  for (const b of Object.values(model.bones)) saved.set(b, { p: b.position.clone(), q: b.quaternion.clone(), s: b.scale.clone() });
  const hips = bones[0];
  for (const c of clips) {
    const clip = rootMotion && c.rootMotion ? c.clip : c.inPlace;
    const a = mixer.clipAction(clip);
    a.play();
    const n = Math.max(2, Math.round(clip.duration * 30) + 1);
    const times: number[] = [];
    const qv = new Map<THREE.Bone, number[]>();
    const hp: number[] = [];
    for (const b of bones) qv.set(b, []);
    for (let i = 0; i < n; i++) {
      const t = (i / (n - 1)) * clip.duration;
      a.time = t;
      mixer.update(0);
      model.rigRoot.updateMatrixWorld(true);
      rt.apply();
      times.push(t);
      for (const b of bones) qv.get(b)!.push(b.quaternion.x, b.quaternion.y, b.quaternion.z, b.quaternion.w);
      hp.push(hips.position.x, hips.position.y, hips.position.z);
    }
    const tracks: THREE.KeyframeTrack[] = bones.map((b) => new THREE.QuaternionKeyframeTrack(`${b.name}.quaternion`, times, qv.get(b)!));
    tracks.push(new THREE.VectorKeyframeTrack(`${hips.name}.position`, times, hp));
    out.push(new THREE.AnimationClip(c.name, clip.duration, tracks));
    a.stop();
    mixer.uncacheAction(clip);
  }
  for (const [o, t] of saved) {
    o.position.copy(t.p);
    o.quaternion.copy(t.q);
  }
  model.rigRoot.updateMatrixWorld(true);
  rt.apply();
  return out;
}

export function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/** JSON manifest: skeleton hierarchy + clip metadata (for engine import scripts) */
export function manifest(model: CharacterModel, clips: ClipDef[]) {
  return {
    character: 'MOUNTAIN — Beyond the Summit / Protagonist',
    source: model.source,
    units: 'meters',
    up: '+Y',
    forward: '+Z',
    convention: 'Mixamo-compatible humanoid names (no prefix)',
    skeleton: hierarchyTree(),
    ikTargets: ['ik_hand_l', 'ik_hand_r', 'ik_foot_l', 'ik_foot_r'],
    sockets: ['HeadLamp', 'IceAxe_Pack', 'Backpack'],
    clips: clips.map((c) => ({
      name: c.name,
      label: c.label,
      category: c.category,
      duration: +c.clip.duration.toFixed(3),
      loop: c.loop,
      rootMotion: c.rootMotion,
      inPlace: !c.rootMotion,
      nominalSpeed: c.nominalSpeed ? +c.nominalSpeed.toFixed(3) : undefined,
      description: c.desc,
    })),
  };
}
