import { useCallback, useEffect, useRef, useState } from 'react';
import { Game } from './game/Game';
import type { HudState, Toast, VictoryInfo } from './game/Game';
import { MountainDef } from './game/config';
import { Profile } from './game/progression';
import { HUD } from './ui/HUD';
import { CharacterLab } from './ui/CharacterLab';
import { DeathOverlay, HelpPanel, LoadingScreen, MainMenu, PauseMenu, ProfilePanel, ReadyOverlay, Toasts, VictoryScreen } from './ui/Menus';

type Screen = 'menu' | 'loading' | 'ready' | 'playing' | 'paused' | 'victory' | 'lab';

export default function App() {
  const profileRef = useRef<Profile | null>(null);
  if (!profileRef.current) profileRef.current = new Profile();
  const profile = profileRef.current;

  const [, force] = useState(0);
  const [screen, setScreen] = useState<Screen>('menu');
  const [def, setDef] = useState<MountainDef | null>(null);
  const [loading, setLoading] = useState({ pct: 0, label: '' });
  const [hud, setHud] = useState<HudState | null>(null);
  const [toasts, setToasts] = useState<(Toast & { id: number })[]>([]);
  const [modal, setModal] = useState<null | 'profile' | 'help'>(null);
  const [death, setDeath] = useState<string | null>(null);
  const [victory, setVictory] = useState<VictoryInfo | null>(null);
  const gameRef = useRef<Game | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const toastId = useRef(0);
  const screenRef = useRef<Screen>('menu');
  screenRef.current = screen;

  const pushToast = useCallback((t: Toast) => {
    const id = ++toastId.current;
    setToasts((l) => [...l.slice(-3), { ...t, id }]);
    setTimeout(() => setToasts((l) => l.filter((x) => x.id !== id)), t.kind === 'ach' ? 6000 : 4200);
  }, []);

  // cria / destrói o jogo conforme a montanha escolhida
  useEffect(() => {
    if (!def || !containerRef.current) return;
    let disposed = false;
    const game = new Game(containerRef.current, def, profile, {
      onHud: (h) => !disposed && setHud(h),
      onToast: (t) => !disposed && pushToast(t),
      onVictory: (v) => {
        if (disposed) return;
        setVictory(v);
        setScreen('victory');
      },
      onDeath: (on, reason) => !disposed && setDeath(on ? (reason ?? '') : null),
      onLoading: (pct, label) => !disposed && setLoading({ pct, label }),
      onPause: () => !disposed && setScreen('paused'),
      onReady: () => !disposed && setScreen('ready'),
    });
    gameRef.current = game;
    game.init().catch((e) => {
      if (e?.message !== 'disposed') console.error(e);
    });
    return () => {
      disposed = true;
      game.dispose();
      if (gameRef.current === game) gameRef.current = null;
    };
  }, [def, profile, pushToast]);

  const play = (m: MountainDef) => {
    setHud(null);
    setToasts([]);
    setDeath(null);
    setVictory(null);
    setLoading({ pct: 0, label: 'Iniciando…' });
    setScreen('loading');
    setDef(m);
  };

  const toMenu = useCallback(() => {
    setDef(null);
    setScreen('menu');
    setModal(null);
    setHud(null);
    setDeath(null);
    setVictory(null);
    setToasts([]);
    force((n) => n + 1);
  }, []);

  const pause = useCallback(() => {
    if (screenRef.current !== 'playing') return;
    gameRef.current?.pause();
    setScreen('paused');
  }, []);

  const resume = useCallback(() => {
    setModal(null);
    gameRef.current?.resume();
    setScreen('playing');
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const s = screenRef.current;
      if (e.code === 'KeyP' || (e.code === 'Escape' && s === 'playing')) {
        if (s === 'playing') pause();
        else if (s === 'paused' && e.code === 'KeyP' && !modal) resume();
      } else if (e.code === 'KeyH' && (s === 'playing' || s === 'paused')) {
        if (s === 'playing') pause();
        setModal((m) => (m === 'help' ? null : 'help'));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [pause, resume, modal]);

  const start = () => {
    gameRef.current?.begin();
    setScreen('playing');
  };

  const inGame = screen !== 'menu' && screen !== 'lab';

  return (
    <div className="fixed inset-0 bg-black overflow-hidden">
      {inGame && (
        <div
          ref={containerRef}
          className="absolute inset-0"
          onClick={() => {
            const g = gameRef.current;
            if (screenRef.current === 'playing' && g && !g.input.locked) g.input.lock();
          }}
        />
      )}

      {screen === 'menu' && (
        <MainMenu
          profile={profile}
          onPlay={play}
          onProfile={() => setModal('profile')}
          onHelp={() => setModal('help')}
          onLab={() => setScreen('lab')}
        />
      )}
      {screen === 'lab' && <CharacterLab onBack={() => setScreen('menu')} />}

      {screen === 'loading' && def && <LoadingScreen pct={loading.pct} label={loading.label} name={def.name} />}
      {screen === 'ready' && def && <ReadyOverlay name={def.name} onStart={start} onBack={toMenu} />}

      {(screen === 'playing' || screen === 'paused' || screen === 'victory') && hud && <HUD hud={hud} />}
      {(screen === 'playing' || screen === 'paused') && <Toasts toasts={toasts} />}
      {death !== null && screen === 'playing' && <DeathOverlay reason={death} />}

      {screen === 'paused' && !modal && <PauseMenu onResume={resume} onProfile={() => setModal('profile')} onHelp={() => setModal('help')} onQuit={toMenu} />}
      {screen === 'victory' && victory && <VictoryScreen v={victory} onMenu={toMenu} onContinue={() => { gameRef.current?.keepExploring(); setScreen('playing'); }} />}

      {modal === 'profile' && (
        <ProfilePanel
          profile={profile}
          onClose={() => {
            setModal(null);
            force((n) => n + 1);
          }}
          onReset={() => {
            profile.reset();
            force((n) => n + 1);
          }}
        />
      )}
      {modal === 'help' && <HelpPanel onClose={() => setModal(null)} />}
    </div>
  );
}
