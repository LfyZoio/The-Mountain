import { useEffect, useMemo, useRef, useState } from 'react';
import { LabScene, LabState } from '../character/LabScene';
import { CATEGORIES, getClipLibrary } from '../character/clips';
import { buildModelFromFile, clearUserModel, createStandInModel, loadProtagonist, loadUserModel, saveUserModel } from '../character/loader';
import { CharacterModel } from '../character/model';
import { download, exportGLB, manifest } from '../character/exporter';
import { DEFORM_BONES, hierarchyTree } from '../character/skeleton';

const initial: LabState = {
  mode: 'clip',
  clip: 'idle',
  rootMotion: true,
  skeleton: false,
  wireframe: false,
  props: true,
  uneven: false,
  handIK: false,
  lookAtCam: false,
  speed: 1,
  fade: 0.3,
  paused: false,
  blend: { speed: 1.4, dirX: 0, dirZ: 1, snow: 0, wind: 0, careful: 0, crouch: false, moveWorld: true },
};

function Toggle({ label, v, on }: { label: string; v: boolean; on: (b: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-2 text-xs py-1 cursor-pointer">
      <span className="text-white/80">{label}</span>
      <button onClick={() => on(!v)} className={`w-9 h-5 rounded-full relative transition ${v ? 'bg-sky-400' : 'bg-white/15'}`}>
        <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${v ? 'left-[18px]' : 'left-0.5'}`} />
      </button>
    </label>
  );
}

function Slider({ label, v, min, max, step, on, fmt }: { label: string; v: number; min: number; max: number; step: number; on: (n: number) => void; fmt?: (n: number) => string }) {
  return (
    <div className="text-xs py-1">
      <div className="flex justify-between text-white/70">
        <span>{label}</span>
        <span className="tabular-nums text-white">{fmt ? fmt(v) : v.toFixed(2)}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={v} onChange={(e) => on(parseFloat(e.target.value))} className="w-full accent-sky-400" />
    </div>
  );
}

export function CharacterLab({ onBack }: { onBack: () => void }) {
  const host = useRef<HTMLDivElement>(null);
  const lab = useRef<LabScene | null>(null);
  const [st, setSt] = useState<LabState>(initial);
  const [model, setModel] = useState<CharacterModel | null>(null);
  const [info, setInfo] = useState({ time: 0, dur: 1, state: '', fps: 0 });
  const [tab, setTab] = useState<'model' | 'view' | 'blend' | 'skeleton' | 'export'>('model');
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');
  const [facing, setFacing] = useState(0);
  const [forceAuto, setForceAuto] = useState(false);
  const [lastFile, setLastFile] = useState<{ buf: ArrayBuffer; name: string } | null>(null);
  const [savedName, setSavedName] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const clips = useMemo(() => getClipLibrary(), []);
  const tree = useMemo(() => hierarchyTree(), []);

  // scene lifecycle
  useEffect(() => {
    if (!host.current) return;
    const l = new LabScene(host.current, initial);
    lab.current = l;
    (window as any).__lab = l;
    let last = 0;
    l.onFrame = (i) => {
      const now = performance.now();
      if (now - last > 80) {
        last = now;
        setInfo(i);
      }
    };
    setBusy('Carregando protagonista…');
    loadProtagonist().then((m) => {
      l.setModel(m);
      setModel(m);
      setBusy('');
    });
    loadUserModel().then((s) => setSavedName(s?.name ?? null));
    return () => {
      l.dispose();
      lab.current = null;
    };
  }, []);

  const update = (patch: Partial<LabState>, reapply = false) => {
    const next = { ...st, ...patch, blend: { ...st.blend, ...(patch.blend || {}) } };
    setSt(next);
    if (lab.current) {
      lab.current.st = next;
      if (reapply) lab.current.applyMode(false);
      lab.current.updateProps();
    }
  };

  const playClip = (name: string) => {
    const next = { ...st, mode: 'clip' as const, clip: name, paused: false };
    setSt(next);
    if (lab.current) {
      lab.current.st = next;
      lab.current.applyMode(true);
    }
  };

  const onFile = async (f: File) => {
    setBusy(`Processando ${f.name}…`);
    setMsg('');
    try {
      const buf = await f.arrayBuffer();
      const m = await buildModelFromFile(buf, f.name, facing, forceAuto);
      lab.current?.setModel(m);
      setModel(m);
      setLastFile({ buf, name: f.name });
      setMsg(`✔ ${f.name} carregado (${m.source === 'retarget' ? 'retarget do rig existente' : 'auto-rig'}).`);
    } catch (e: any) {
      setMsg('✖ ' + (e?.message || String(e)));
    }
    setBusy('');
  };

  const reprocess = async (fc: number, fa: boolean) => {
    if (!lastFile) return;
    setBusy('Reprocessando…');
    try {
      const m = await buildModelFromFile(lastFile.buf, lastFile.name, fc, fa);
      lab.current?.setModel(m);
      setModel(m);
    } catch (e: any) {
      setMsg('✖ ' + (e?.message || String(e)));
    }
    setBusy('');
  };

  const doExport = async (which: 'all' | 'current') => {
    if (!model) return;
    setBusy('Exportando GLB…');
    try {
      const sel = which === 'all' ? clips : clips.filter((c) => c.name === st.clip);
      const blob = await exportGLB(model, sel, st.rootMotion);
      download(blob, which === 'all' ? 'MOUNTAIN_Protagonist_Rigged_AllClips.glb' : `MOUNTAIN_Protagonist_${st.clip}.glb`);
      setMsg(`✔ Exportado (${(blob.size / 1024 / 1024).toFixed(2)} MB, ${sel.length} clipe(s)).`);
    } catch (e: any) {
      setMsg('✖ Falha na exportação: ' + (e?.message || String(e)));
    }
    setBusy('');
  };

  const cur = clips.find((c) => c.name === st.clip);
  const list = clips.filter((c) => !filter || (c.label + c.name).toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="absolute inset-0 flex flex-col bg-[#0b1220]">
      {/* top bar */}
      <div className="h-12 shrink-0 flex items-center gap-4 px-4 border-b border-white/10 bg-black/30">
        <button className="btn btn-ghost !py-1.5 !px-3" onClick={onBack}>
          ← Menu
        </button>
        <div className="title-font text-xl tracking-widest">
          LABORATÓRIO DO PERSONAGEM <span className="text-sky-300 text-sm ml-2">MOUNTAIN — Beyond the Summit</span>
        </div>
        <div className="ml-auto text-[11px] text-white/60 flex gap-4 tabular-nums">
          <span>Estado: <b className="text-white">{info.state}</b></span>
          <span>{model ? `${model.triangles.toLocaleString('pt-BR')} triângulos` : ''}</span>
          <span>{Math.round(info.fps)} fps</span>
        </div>
      </div>
      <div className="flex-1 flex min-h-0">
        {/* clip library */}
        <div className="w-[250px] shrink-0 border-r border-white/10 flex flex-col bg-black/20">
          <div className="p-2 flex gap-1">
            <button className={`flex-1 text-xs py-1.5 rounded ${st.mode === 'clip' ? 'bg-sky-500/30 text-sky-100' : 'bg-white/5'}`} onClick={() => update({ mode: 'clip' }, true)}>
              Clipes ({clips.length})
            </button>
            <button className={`flex-1 text-xs py-1.5 rounded ${st.mode === 'blend' ? 'bg-sky-500/30 text-sky-100' : 'bg-white/5'}`} onClick={() => { update({ mode: 'blend' }, true); setTab('blend'); }}>
              Blend tree
            </button>
          </div>
          <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Buscar animação…" className="mx-2 mb-2 px-2 py-1 text-xs rounded bg-white/5 border border-white/10 outline-none" />
          <div className="overflow-auto flex-1 pb-4">
            {CATEGORIES.map((cat) => (
              <div key={cat}>
                <div className="px-3 pt-3 pb-1 text-[10px] tracking-[0.25em] text-sky-300/80 uppercase">{cat}</div>
                {list
                  .filter((c) => c.category === cat)
                  .map((c) => (
                    <button
                      key={c.name}
                      onClick={() => playClip(c.name)}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-white/5 ${st.mode === 'clip' && st.clip === c.name ? 'bg-sky-500/20 text-white border-l-2 border-sky-300' : 'text-white/75 border-l-2 border-transparent'}`}
                    >
                      <span className="flex-1">{c.label}</span>
                      {c.loop && <span className="text-[9px] text-white/40">loop</span>}
                      {c.rootMotion && <span className="text-[9px] text-amber-300/80">RM</span>}
                    </button>
                  ))}
              </div>
            ))}
          </div>
        </div>

        {/* viewport */}
        <div className="flex-1 relative min-w-0">
          <div ref={host} className="absolute inset-0" />
          {model?.source === 'standin' && (
            <div className="absolute top-3 left-3 right-3 md:right-auto md:max-w-[560px] bg-amber-500/15 border border-amber-400/40 rounded-lg px-3 py-2 text-[12px] text-amber-100">
              <b>Modelo provisório.</b> Nenhum arquivo 3D foi encontrado no projeto: recebi apenas imagens de referência. Este stand-in replica a referência só para demonstrar rig e animações. Importe seu <b>.glb / .fbx / .obj</b> na aba “Modelo” e clique em “Usar no jogo”.
            </div>
          )}
          {busy && <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-sm">{busy}</div>}
          {st.mode === 'clip' && cur && (
            <div className="absolute left-3 bottom-[76px] max-w-[420px] glass rounded-lg px-3 py-2 text-xs">
              <div className="font-bold text-sm">{cur.label} <span className="text-white/40 font-normal">· {cur.name}</span></div>
              <div className="text-white/70 mt-0.5">{cur.desc}</div>
              <div className="text-white/50 mt-1">
                {cur.clip.duration.toFixed(2)} s · {cur.loop ? 'loop' : 'único'} · {cur.rootMotion ? 'root motion' : 'in-place'}
                {cur.nominalSpeed ? ` · velocidade nominal ${cur.nominalSpeed.toFixed(2)} m/s` : ''}
              </div>
            </div>
          )}
          {/* timeline */}
          <div className="absolute left-0 right-0 bottom-0 h-16 bg-black/50 border-t border-white/10 flex items-center gap-3 px-4">
            <button className="btn btn-ghost !py-1.5 !px-3 w-20" onClick={() => update({ paused: !st.paused })}>
              {st.paused ? '▶ Play' : '❚❚ Pausa'}
            </button>
            <div className="flex-1">
              <input
                type="range"
                min={0}
                max={1}
                step={0.001}
                value={st.mode === 'clip' ? Math.min(1, info.time / info.dur) : info.time}
                onChange={(e) => {
                  if (!st.paused) update({ paused: true });
                  lab.current?.scrub(parseFloat(e.target.value));
                }}
                className="w-full accent-sky-400"
              />
              <div className="flex justify-between text-[10px] text-white/50 tabular-nums">
                <span>{st.mode === 'clip' ? `${info.time.toFixed(2)} s` : `fase ${(info.time * 100).toFixed(0)}%`}</span>
                <span>{st.mode === 'clip' ? `${info.dur.toFixed(2)} s` : 'ciclo sincronizado'}</span>
              </div>
            </div>
            <div className="w-36">
              <Slider label="Velocidade" v={st.speed} min={0.1} max={2} step={0.05} on={(v) => update({ speed: v })} fmt={(v) => v.toFixed(2) + '×'} />
            </div>
            <div className="w-36">
              <Slider label="Crossfade" v={st.fade} min={0} max={1} step={0.05} on={(v) => update({ fade: v })} fmt={(v) => v.toFixed(2) + ' s'} />
            </div>
          </div>
        </div>

        {/* right panel */}
        <div className="w-[300px] shrink-0 border-l border-white/10 flex flex-col bg-black/20">
          <div className="flex text-[11px] border-b border-white/10">
            {(
              [
                ['model', 'Modelo'],
                ['view', 'Visual'],
                ['blend', 'Blend'],
                ['skeleton', 'Esqueleto'],
                ['export', 'Exportar'],
              ] as const
            ).map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} className={`flex-1 py-2 ${tab === k ? 'text-sky-200 border-b-2 border-sky-300 bg-white/5' : 'text-white/60'}`}>
                {l}
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-auto p-3 text-xs space-y-3">
            {tab === 'model' && (
              <>
                <div className="bg-white/5 rounded-lg p-3 space-y-1">
                  <div className="text-[10px] tracking-widest text-white/50">MODELO ATUAL</div>
                  <div className="font-bold text-sm">{model?.name ?? '—'}</div>
                  <div className="text-white/70">
                    Fonte: {model?.source === 'standin' ? 'stand-in provisório' : model?.source === 'autorig' ? 'seu modelo + auto-rig' : 'seu modelo + rig existente (retarget)'}
                  </div>
                  <div className="text-white/70">Triângulos: {model?.triangles.toLocaleString('pt-BR')}</div>
                  <div className="text-white/70">Ossos: {Object.keys(model?.bones ?? {}).length} ({DEFORM_BONES.length} deformantes)</div>
                  {model?.notes.map((n, i) => (
                    <div key={i} className="text-sky-200/80 text-[11px]">
                      • {n}
                    </div>
                  ))}
                </div>
                <div className="space-y-2">
                  <div className="text-[10px] tracking-widest text-white/50">IMPORTAR SEU MODELO 3D</div>
                  <label className="block border-2 border-dashed border-sky-400/40 rounded-lg p-4 text-center cursor-pointer hover:bg-sky-400/10">
                    <div className="text-2xl">📦</div>
                    <div className="font-semibold mt-1">Selecionar .glb / .gltf / .fbx / .obj</div>
                    <div className="text-white/50 text-[10px] mt-1">Geometria, materiais e cores são preservados</div>
                    <input type="file" accept=".glb,.gltf,.fbx,.obj" className="hidden" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
                  </label>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Frente do modelo</span>
                    <select
                      value={facing}
                      onChange={(e) => {
                        const v = parseInt(e.target.value);
                        setFacing(v);
                        reprocess(v, forceAuto);
                      }}
                      className="bg-white/10 rounded px-2 py-1"
                    >
                      <option value={0}>+Z (padrão glTF)</option>
                      <option value={180}>−Z</option>
                      <option value={90}>+X</option>
                      <option value={-90}>−X</option>
                    </select>
                  </div>
                  <Toggle
                    label="Forçar auto-rig (ignorar rig do arquivo)"
                    v={forceAuto}
                    on={(b) => {
                      setForceAuto(b);
                      reprocess(facing, b);
                    }}
                  />
                  {msg && <div className={msg.startsWith('✖') ? 'text-red-300' : 'text-emerald-300'}>{msg}</div>}
                  <button
                    disabled={!lastFile}
                    className={`btn btn-primary w-full ${lastFile ? '' : 'opacity-40'}`}
                    onClick={async () => {
                      if (!lastFile) return;
                      await saveUserModel({ name: lastFile.name, buf: lastFile.buf, facing, forceAutoRig: forceAuto });
                      setSavedName(lastFile.name);
                      setMsg('✔ Modelo salvo: será o protagonista no jogo.');
                    }}
                  >
                    Usar no jogo
                  </button>
                  <div className="text-white/50 text-[11px]">
                    No jogo: {savedName ? <b className="text-white">{savedName}</b> : 'stand-in provisório'}
                    {savedName && (
                      <button
                        className="ml-2 text-red-300 underline"
                        onClick={async () => {
                          await clearUserModel();
                          setSavedName(null);
                          const m = createStandInModel();
                          lab.current?.setModel(m);
                          setModel(m);
                        }}
                      >
                        remover
                      </button>
                    )}
                  </div>
                  <div className="text-white/45 text-[11px] leading-4">
                    Alternativa para o build: coloque o arquivo em <code className="text-sky-200">public/models/protagonist.glb</code>. Modelos com rig Mixamo/UE/Blender são retargetizados; malhas estáticas recebem auto-rig.
                  </div>
                </div>
              </>
            )}
            {tab === 'view' && (
              <div>
                <Toggle label="Mostrar esqueleto" v={st.skeleton} on={(b) => update({ skeleton: b })} />
                <Toggle label="Wireframe" v={st.wireframe} on={(b) => update({ wireframe: b })} />
                <Toggle label="Props de demonstração (parede, borda, corda)" v={st.props} on={(b) => update({ props: b })} />
                <Toggle label="Root motion" v={st.rootMotion} on={(b) => update({ rootMotion: b }, true)} />
                <Toggle label="Terreno irregular (IK dos pés)" v={st.uneven} on={(b) => update({ uneven: b })} />
                <Toggle label="IK das mãos (alvos móveis)" v={st.handIK} on={(b) => update({ handIK: b })} />
                <Toggle label="Cabeça olha para a câmera" v={st.lookAtCam} on={(b) => update({ lookAtCam: b })} />
                <div className="text-white/50 mt-3 leading-4">Arraste para orbitar, role para zoom. A mochila tem movimento secundário (mola) e as mãos/pés usam IK analítico de dois ossos.</div>
              </div>
            )}
            {tab === 'blend' && (
              <div>
                <div className="text-white/60 mb-2 leading-4">Blend tree de locomoção com sincronização de fase: idle → andar → correr → sprint, mais direções (trás/laterais) e variantes de terreno. A velocidade da animação acompanha o deslocamento real (sem pés deslizando).</div>
                <button className="btn btn-ghost w-full mb-2" onClick={() => update({ mode: 'blend' }, true)}>
                  Ativar blend tree
                </button>
                <Slider label="Velocidade (m/s)" v={st.blend.speed} min={0} max={7.5} step={0.05} on={(v) => update({ blend: { ...st.blend, speed: v } })} />
                <div className="grid grid-cols-3 gap-1 my-2">
                  {[
                    ['↖', 0.7, 0.7],
                    ['↑', 0, 1],
                    ['↗', -0.7, 0.7],
                    ['←', 1, 0],
                    ['·', 0, 1],
                    ['→', -1, 0],
                    ['↙', 0.7, -0.7],
                    ['↓', 0, -1],
                    ['↘', -0.7, -0.7],
                  ].map(([l, x, z]) => (
                    <button
                      key={l as string}
                      onClick={() => update({ blend: { ...st.blend, dirX: x as number, dirZ: z as number } })}
                      className={`py-1.5 rounded ${st.blend.dirX === x && st.blend.dirZ === z ? 'bg-sky-500/40' : 'bg-white/5'}`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
                <Slider label="Neve" v={st.blend.snow} min={0} max={1} step={0.05} on={(v) => update({ blend: { ...st.blend, snow: v } })} />
                <Slider label="Vento contra" v={st.blend.wind} min={0} max={1} step={0.05} on={(v) => update({ blend: { ...st.blend, wind: v } })} />
                <Slider label="Gelo (cuidado)" v={st.blend.careful} min={0} max={1} step={0.05} on={(v) => update({ blend: { ...st.blend, careful: v } })} />
                <Toggle label="Agachado" v={st.blend.crouch} on={(b) => update({ blend: { ...st.blend, crouch: b } })} />
                <Toggle label="Deslocar no mundo (testar deslize)" v={st.blend.moveWorld} on={(b) => update({ blend: { ...st.blend, moveWorld: b } })} />
              </div>
            )}
            {tab === 'skeleton' && (
              <div className="font-mono text-[10.5px] leading-[15px]">
                {tree.map((n) => (
                  <div key={n.name} style={{ paddingLeft: n.depth * 9 }} className={n.name.startsWith('ik_') ? 'text-amber-300' : DEFORM_BONES.includes(n.name) ? 'text-white/85' : 'text-white/40'}>
                    {n.depth > 0 ? '└ ' : ''}
                    {n.name}
                  </div>
                ))}
                <div className="font-sans text-white/50 mt-3 text-[11px]">Branco: deformantes · cinza: terminais/sockets · laranja: alvos de IK.</div>
              </div>
            )}
            {tab === 'export' && (
              <div className="space-y-2">
                <div className="text-white/60 leading-4">Arquivos glTF binário prontos para Unity, Unreal, Godot e Blender (metros, +Y para cima, frente +Z).</div>
                <button className="btn btn-primary w-full" onClick={() => doExport('all')}>
                  GLB: modelo + rig + {clips.length} clipes
                </button>
                <button className="btn btn-ghost w-full" onClick={() => doExport('current')}>
                  GLB: clipe atual ({st.clip})
                </button>
                <button className="btn btn-ghost w-full" onClick={() => model && download(new Blob([JSON.stringify(manifest(model, clips), null, 2)], { type: 'application/json' }), 'MOUNTAIN_Protagonist_manifest.json')}>
                  Manifesto JSON (esqueleto + clipes)
                </button>
                <button
                  className="btn btn-ghost w-full"
                  onClick={() => {
                    const url = lab.current?.contactSheet(0.5);
                    if (url) {
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'MOUNTAIN_Protagonist_contact_sheet.png';
                      a.click();
                    }
                  }}
                >
                  Folha de contato (PNG)
                </button>
                <Toggle label="Incluir root motion nos clipes" v={st.rootMotion} on={(b) => update({ rootMotion: b })} />
                {msg && <div className={msg.startsWith('✖') ? 'text-red-300' : 'text-emerald-300'}>{msg}</div>}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
