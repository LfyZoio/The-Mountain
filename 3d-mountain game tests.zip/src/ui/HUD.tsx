import { EQUIPMENT } from '../game/config';
import type { HudState } from '../game/Game';
import { fmtTime } from '../game/progression';

const fmtAlt = (m: number) => Math.round(m).toLocaleString('pt-BR');
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

function Bar({ v, color, h = 6, glow }: { v: number; color: string; h?: number; glow?: boolean }) {
  return (
    <div className="bar-track" style={{ height: h }}>
      <div className="bar-fill" style={{ width: `${clamp01(v) * 100}%`, background: color, boxShadow: glow ? `0 0 10px ${color}` : undefined }} />
    </div>
  );
}

function Compass({ hud }: { hud: HudState }) {
  const span = 150; // graus visíveis
  const rel = (b: number) => {
    let d = b - hud.heading;
    d = ((d + 540) % 360) - 180;
    return d;
  };
  const pos = (d: number) => 50 + (d / span) * 100;
  const ticks: { d: number; label: string; major: boolean }[] = [];
  for (let b = 0; b < 360; b += 15) {
    const d = rel(b);
    if (Math.abs(d) <= span / 2) {
      const names: Record<number, string> = { 0: 'N', 90: 'L', 180: 'S', 270: 'O', 45: 'NE', 135: 'SE', 225: 'SO', 315: 'NO' };
      ticks.push({ d, label: names[b] ?? '', major: b % 45 === 0 });
    }
  }
  const sd = rel(hud.summitBearing);
  const cd = hud.campBearing != null ? rel(hud.campBearing) : null;
  return (
    <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[min(560px,56vw)]">
      <div className="glass rounded-full relative h-9 overflow-hidden" style={{ maskImage: 'linear-gradient(90deg, transparent, #000 15%, #000 85%, transparent)' }}>
        {ticks.map((t, i) => (
          <div key={i} className="absolute top-0 h-full flex flex-col items-center justify-center" style={{ left: `${pos(t.d)}%`, transform: 'translateX(-50%)' }}>
            <div className={t.major ? 'w-px h-2 bg-white/80' : 'w-px h-1.5 bg-white/40'} />
            <div className={`text-[10px] leading-3 font-bold ${t.label === 'N' ? 'text-red-400' : 'text-white/80'}`}>{t.label}</div>
          </div>
        ))}
        {Math.abs(sd) <= span / 2 && (
          <div className="absolute top-0 h-full flex items-center text-amber-300 text-sm" style={{ left: `${pos(sd)}%`, transform: 'translateX(-50%)', textShadow: '0 0 8px #fbbf24' }}>
            ◆
          </div>
        )}
        {cd != null && Math.abs(cd) <= span / 2 && (
          <div className="absolute top-0 h-full flex items-center text-cyan-300 text-sm" style={{ left: `${pos(cd)}%`, transform: 'translateX(-50%)' }}>
            ⛺
          </div>
        )}
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 -top-0.5 text-white text-[10px]">▼</div>
      <div className="text-center text-[11px] mt-1 text-white/70 tracking-widest">
        {Math.round(hud.heading).toString().padStart(3, '0')}° · <span className="text-amber-300">◆ {Math.round(hud.summitDist)} m</span>
        {hud.campBearing != null && (
          <span className="text-cyan-300">
            {' '}
            · ⛺ {Math.round(hud.campDist)} m
          </span>
        )}
      </div>
    </div>
  );
}

function Altimeter({ hud }: { hud: HudState }) {
  return (
    <div className="absolute right-4 top-4 flex gap-3 items-start">
      <div className="glass rounded-xl px-4 py-3 text-right min-w-[170px]">
        <div className="text-[10px] tracking-[0.25em] text-sky-300/80">ALTITUDE</div>
        <div className="title-font text-4xl leading-none mt-1 tabular-nums">
          {fmtAlt(hud.alt)}
          <span className="text-lg text-white/60 ml-1">m</span>
        </div>
        <div className="text-[11px] text-white/60 mt-1">
          Cume {fmtAlt(hud.summitM)} m · Máx {fmtAlt(hud.altMax)} m
        </div>
        <div className="text-[11px] text-white/80 mt-1 tabular-nums">⏱ {fmtTime(hud.time)}</div>
      </div>
      <div className="glass rounded-xl p-2 w-9 h-[210px] relative">
        <div className="absolute left-1/2 -translate-x-1/2 top-2 bottom-2 w-1 rounded bg-white/15" />
        <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-1 rounded bg-sky-400/70" style={{ height: `calc((100% - 16px) * ${hud.progress})` }} />
        <div className="absolute left-1/2 -translate-x-1/2 -top-1 text-amber-300 text-sm">⚑</div>
        {hud.camps.map((c, i) => (
          <div
            key={i}
            className={`absolute left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full border ${c.active ? 'bg-emerald-400 border-emerald-200' : 'bg-slate-700 border-slate-400'}`}
            style={{ bottom: `calc(8px + (100% - 16px) * ${c.p} - 5px)` }}
          />
        ))}
        <div className="absolute left-0 right-0 text-center text-white text-[10px]" style={{ bottom: `calc(8px + (100% - 16px) * ${hud.progress} - 7px)`, textShadow: '0 0 6px #000' }}>
          ◀ ▶
        </div>
      </div>
    </div>
  );
}

function Environment({ hud }: { hud: HudState }) {
  const rot = hud.windDir - hud.heading;
  const tempColor = hud.temp < 34.5 ? '#60a5fa' : hud.temp < 36 ? '#a5f3fc' : '#fde68a';
  return (
    <div className="absolute left-4 top-4 glass rounded-xl px-4 py-3 w-[230px] text-[12px]">
      <div className="flex items-center justify-between">
        <div className="font-bold tracking-wide">{hud.biome}</div>
        <div className="text-white/60">{hud.matName}</div>
      </div>
      <div className="text-sky-200/80 mt-0.5">{hud.weather}</div>
      <div className="flex items-center gap-3 mt-2">
        <div className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center" style={{ transform: `rotate(${rot}deg)` }}>
          <span className="text-lg text-sky-300" style={{ opacity: 0.3 + Math.min(0.7, hud.windKmh / 80) }}>
            ↑
          </span>
        </div>
        <div>
          <div className="tabular-nums text-base font-bold">{Math.round(hud.windKmh)} km/h</div>
          <div className="text-white/50 text-[10px] tracking-widest">VENTO</div>
        </div>
        <div className="ml-auto text-right">
          <div className="tabular-nums text-base font-bold" style={{ color: tempColor }}>
            {hud.temp.toFixed(1)}°
          </div>
          <div className="text-white/50 text-[10px] tracking-widest">CORPO</div>
        </div>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <span className="text-[10px] text-white/50 w-14">AMBIENTE</span>
        <span className="tabular-nums font-semibold" style={{ color: hud.ambient < -5 ? '#93c5fd' : '#e8f1fb' }}>
          {Math.round(hud.ambient)} °C
        </span>
      </div>
      <div className="mt-1.5">
        <Bar v={(hud.temp - 32) / 5.5} color={tempColor} h={4} />
      </div>
    </div>
  );
}

function Vitals({ hud }: { hud: HudState }) {
  const sc = hud.stamina > 50 ? '#4ade80' : hud.stamina > 25 ? '#fbbf24' : '#f87171';
  return (
    <div className="absolute left-4 bottom-4 w-[300px]">
      <div className="glass rounded-xl px-4 py-3">
        <div className="flex items-center justify-between text-[10px] tracking-[0.22em] text-white/70 mb-1">
          <span>STAMINA</span>
          <span className={`tabular-nums ${hud.exhausted ? 'text-red-300 pulse' : ''}`}>{hud.exhausted ? 'EXAUSTO' : Math.round(hud.stamina)}</span>
        </div>
        <div className="relative">
          <Bar v={hud.stamina / 100} color={sc} h={12} glow />
          <div className="absolute top-0 h-3 border-r-2 border-white/60" style={{ left: `${hud.staminaMax}%` }} title="Limite atual" />
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-3 text-[10px] tracking-widest text-white/60">
          <div>
            SAÚDE
            <Bar v={hud.health / 100} color="#fb7185" h={5} />
          </div>
          <div>
            ENERGIA
            <Bar v={hud.energy / 100} color="#fb923c" h={5} />
          </div>
          {hud.unlocked.oxygen && (
            <div className="col-span-2">
              OXIGÊNIO {hud.oxygenOn ? '· ATIVO' : ''}
              <Bar v={hud.oxygen / 100} color="#67e8f9" h={5} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Hotbar({ hud }: { hud: HudState }) {
  const count = (id: string): string | null => {
    switch (id) {
      case 'rope':
        return String(hud.pitons);
      case 'chalk':
        return hud.chalkT > 0 ? `${Math.ceil(hud.chalkT)}s` : String(hud.chalk);
      case 'food':
        return String(hud.food);
      case 'tea':
        return String(hud.tea);
      case 'oxygen':
        return `${Math.round(hud.oxygen)}%`;
      default:
        return null;
    }
  };
  const active = (id: string) => (id === 'lamp' && hud.lampOn) || (id === 'oxygen' && hud.oxygenOn) || (id === 'chalk' && hud.chalkT > 0) || (id === 'rope' && hud.roped);
  return (
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 glass rounded-2xl px-2 py-2 flex gap-1.5">
      {EQUIPMENT.map((e) => {
        const un = hud.unlocked[e.id];
        const c = count(e.id);
        const act = active(e.id);
        return (
          <div
            key={e.id}
            title={`${e.name} — ${e.desc}`}
            className={`relative w-[54px] h-[58px] rounded-xl flex flex-col items-center justify-center border transition ${
              act ? 'border-sky-300 bg-sky-400/20 shadow-[0_0_14px_rgba(125,211,252,0.5)]' : 'border-white/10 bg-white/5'
            } ${un ? '' : 'opacity-35'}`}
          >
            <div className="text-2xl leading-none">{un ? e.icon : '🔒'}</div>
            <div className="text-[9px] mt-1 text-white/70 tabular-nums">{un ? (c ?? (e.key ? '' : 'passivo')) : `Nv ${e.level}`}</div>
            {e.key && un && <div className="absolute -top-1.5 -left-1 bg-slate-900 border border-white/30 rounded px-1 text-[9px] font-bold">{e.key}</div>}
          </div>
        );
      })}
    </div>
  );
}

function Arms({ hud }: { hud: HudState }) {
  const hand = (name: string, key: string, h: HudState['hands'][0]) => {
    const col = h.st === 'free' ? '#94a3b8' : h.q >= 0.85 ? '#4ade80' : h.q >= 0.55 ? '#fbbf24' : '#f87171';
    return (
      <div className="flex-1 min-w-[96px]">
        <div className="flex items-center justify-between text-[10px] tracking-widest text-white/60">
          <span>
            {name} <span className="text-white/90">[{key}]</span>
          </span>
          <span style={{ color: col }}>{h.st === 'grip' ? 'SEGURA' : h.st === 'reach' ? 'ALCANÇA' : 'LIVRE'}</span>
        </div>
        <div className="mt-1 text-[9px] text-white/50">APOIO</div>
        <Bar v={Math.min(1, h.q)} color={col} h={5} />
        <div className="mt-1 text-[9px] text-white/50">ESCORREGA</div>
        <Bar v={h.slip} color={h.slip > 0.6 ? '#ef4444' : '#f59e0b'} h={5} />
      </div>
    );
  };
  const show = hud.mode === 'climb' || hud.mode === 'air';
  return (
    <div className={`absolute right-4 bottom-4 w-[300px] transition-opacity ${show ? 'opacity-100' : 'opacity-60'}`}>
      <div className="glass rounded-xl px-4 py-3">
        <div className="flex gap-4">
          {hand('MÃO ESQ.', 'Q', hud.hands[0])}
          {hand('MÃO DIR.', 'E', hud.hands[1])}
        </div>
        <div className="mt-3 text-[9px] tracking-widest text-white/50 flex justify-between">
          <span>EQUILÍBRIO</span>
          <span>{Math.abs(hud.balance) > 0.8 ? <span className="text-red-300 pulse">INSTÁVEL</span> : 'ESTÁVEL'}</span>
        </div>
        <div className="relative h-2 rounded-full bg-white/10 mt-1">
          <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/40" />
          <div
            className="absolute top-[-2px] w-3 h-3 rounded-full border border-white"
            style={{
              left: `calc(50% + ${(Math.max(-1.3, Math.min(1.3, hud.balance)) / 1.3) * 46}% - 6px)`,
              background: Math.abs(hud.balance) > 0.8 ? '#ef4444' : '#7dd3fc',
            }}
          />
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-white/70">
          <span>🪢 {hud.roped ? `Corda: ${Math.round(hud.ropeOut)} / 45 m` : 'Sem ancoragem'}</span>
          <span>📌 {hud.pitons}</span>
        </div>
      </div>
    </div>
  );
}

export function HUD({ hud }: { hud: HudState }) {
  const introVisible = hud.intro < 1;
  const showCross = hud.mode === 'ground' || hud.mode === 'air';
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* efeitos de tela */}
      <div
        className="absolute inset-0"
        style={{ background: `radial-gradient(ellipse at center, transparent 45%, rgba(190,225,255,${hud.cold * 0.55}) 100%)`, opacity: hud.cold > 0.01 ? 1 : 0 }}
      />
      <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at center, transparent 40%, rgba(220,20,40,${Math.min(0.75, hud.hurt * 0.9 + (hud.health < 25 ? 0.25 : 0))}) 100%)` }} />
      <div className="absolute inset-0 bg-white" style={{ opacity: hud.precip > 0.7 ? (hud.precip - 0.7) * 0.25 : 0 }} />
      {hud.inCave && <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, transparent 35%, rgba(0,0,0,0.6) 100%)' }} />}

      {introVisible && (
        <>
          <div className="absolute top-0 left-0 right-0 bg-black" style={{ height: `${Math.min(12, (1 - hud.intro) * 30)}%` }} />
          <div className="absolute bottom-0 left-0 right-0 bg-black" style={{ height: `${Math.min(12, (1 - hud.intro) * 30)}%` }} />
          <div className="absolute bottom-[16%] left-12 float-in">
            <div className="text-sky-300 text-xs tracking-[0.5em]">EXPEDIÇÃO</div>
            <div className="title-font text-6xl text-white" style={{ textShadow: '0 4px 30px rgba(0,0,0,.6)' }}>
              {hud.summitM.toLocaleString('pt-BR')} m
            </div>
            <div className="text-white/60 text-xs mt-2">Pressione ESPAÇO para pular</div>
          </div>
        </>
      )}

      <div style={{ opacity: introVisible ? 0 : 1, transition: 'opacity 1s' }}>
        <Compass hud={hud} />
        <Altimeter hud={hud} />
        <Environment hud={hud} />
        <Vitals hud={hud} />
        <Arms hud={hud} />
        <Hotbar hud={hud} />
        {showCross && <div className="absolute left-1/2 top-1/2 w-1.5 h-1.5 -ml-[3px] -mt-[3px] rounded-full bg-white/60" />}
        {hud.prompt && (
          <div className="absolute left-1/2 -translate-x-1/2 bottom-[118px] glass rounded-full px-5 py-2 text-sm text-center text-sky-100 max-w-[70vw]">{hud.prompt}</div>
        )}
        <div className="absolute left-4 bottom-[190px] text-[10px] text-white/45 leading-4">
          <div>
            H ajuda · G apoios {hud.hints ? 'on' : 'off'} · V vista {hud.vista ? 'on' : 'off'} · M som {hud.muted ? 'off' : 'on'} · P pausa
          </div>
        </div>
      </div>
    </div>
  );
}
