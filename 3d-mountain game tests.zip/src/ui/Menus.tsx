import { useState } from 'react';
import { ACHIEVEMENTS, EQUIPMENT, MOUNTAINS, MountainDef, xpForLevel } from '../game/config';
import { Profile, fmtTime } from '../game/progression';
import type { Toast, VictoryInfo } from '../game/Game';

// ---------- Fundo de montanhas (SVG paralaxe) ----------
function MountainBackdrop() {
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: 'linear-gradient(180deg,#0b1a33 0%,#244a7a 45%,#e2a76f 78%,#f3d3a0 100%)' }}>
      <div className="absolute inset-0 opacity-70" style={{ backgroundImage: 'radial-gradient(1.5px 1.5px at 20% 20%, #fff, transparent), radial-gradient(1px 1px at 70% 12%, #fff, transparent), radial-gradient(1.5px 1.5px at 45% 30%, #fff, transparent), radial-gradient(1px 1px at 85% 35%, #fff, transparent), radial-gradient(1px 1px at 10% 45%, #fff, transparent)' }} />
      <div className="absolute left-[62%] top-[48%] w-28 h-28 rounded-full" style={{ background: 'radial-gradient(circle,#fff6d6 0%,rgba(255,220,150,.5) 35%,transparent 70%)' }} />
      <svg className="absolute bottom-0 w-full h-[70%]" viewBox="0 0 1440 600" preserveAspectRatio="none">
        <defs>
          <linearGradient id="m1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#dfe9f5" />
            <stop offset="0.35" stopColor="#7c93b0" />
            <stop offset="1" stopColor="#38465e" />
          </linearGradient>
          <linearGradient id="m2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#566a88" />
            <stop offset="1" stopColor="#1e2a3f" />
          </linearGradient>
          <linearGradient id="m3" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#1f3a2f" />
            <stop offset="1" stopColor="#0a1812" />
          </linearGradient>
        </defs>
        <path d="M0 600 L0 330 L180 210 L300 290 L520 70 L610 150 L700 40 L800 170 L930 110 L1100 280 L1250 190 L1440 320 L1440 600Z" fill="url(#m1)" opacity="0.95" />
        <path d="M700 40 L650 130 L690 110 L720 150 L760 100 L800 170 L770 90Z" fill="#fff" opacity="0.9" />
        <path d="M0 600 L0 430 L140 350 L260 420 L420 320 L560 430 L720 360 L900 450 L1060 370 L1240 440 L1440 380 L1440 600Z" fill="url(#m2)" />
        <path d="M0 600 L0 500 Q120 440 240 490 T480 480 T720 500 T960 470 T1200 500 T1440 470 L1440 600Z" fill="url(#m3)" />
        {Array.from({ length: 46 }).map((_, i) => {
          const x = i * 32 + ((i * 17) % 20);
          const y = 520 + ((i * 29) % 40);
          return <path key={i} d={`M${x} ${y} l9 -34 l9 34z M${x + 2} ${y - 16} l7 -28 l7 28z`} fill="#0a2016" />;
        })}
      </svg>
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, transparent 40%, rgba(2,6,14,.7) 100%)' }} />
    </div>
  );
}

// ---------- Menu principal ----------
export function MainMenu({
  profile,
  onPlay,
  onProfile,
  onHelp,
  onLab,
}: {
  profile: Profile;
  onPlay: (m: MountainDef) => void;
  onProfile: () => void;
  onHelp: () => void;
  onLab: () => void;
}) {
  const li = profile.levelInfo();
  const [sel, setSel] = useState(0);
  const unlocked = (m: MountainDef) => !m.requires || profile.isConquered(m.requires);
  const cur = MOUNTAINS[sel];
  return (
    <div className="absolute inset-0">
      <MountainBackdrop />
      <div className="absolute inset-0 overflow-auto">
        <div className="min-h-full max-w-6xl mx-auto px-6 py-8 flex flex-col">
          <header className="flex items-start justify-between float-in">
            <div>
              <div className="text-sky-200 text-xs tracking-[0.6em]">SIMULADOR DE ALPINISMO</div>
              <h1 className="title-font text-5xl md:text-7xl text-white leading-none mt-1" style={{ textShadow: '0 6px 40px rgba(0,0,0,.6)' }}>
                MOUNTAIN<span className="block text-2xl md:text-3xl text-sky-300 tracking-[0.3em] mt-2">BEYOND THE SUMMIT</span>
              </h1>
            </div>
            <div className="glass rounded-xl px-4 py-3 w-[260px]">
              <div className="flex items-center justify-between">
                <div className="text-[10px] tracking-[0.3em] text-sky-200">ALPINISTA</div>
                <div className="title-font text-2xl">NÍVEL {li.level}</div>
              </div>
              <div className="bar-track mt-2" style={{ height: 8 }}>
                <div className="bar-fill" style={{ width: `${li.frac * 100}%`, background: 'linear-gradient(90deg,#38bdf8,#a78bfa)' }} />
              </div>
              <div className="text-[10px] text-white/60 mt-1 flex justify-between">
                <span>
                  {li.cur} / {li.need} XP
                </span>
                <span>{Object.keys(profile.data.conquered).length}/3 cumes</span>
              </div>
              <div className="flex gap-2 mt-3">
                <button className="btn btn-ghost !py-1.5 !px-3 flex-1" onClick={onProfile}>
                  Perfil
                </button>
                <button className="btn btn-ghost !py-1.5 !px-3 flex-1" onClick={onHelp}>
                  Controles
                </button>
              </div>
              <button className="btn btn-ghost !py-1.5 !px-3 w-full mt-2 !text-sky-200" onClick={onLab}>
                🧍 Personagem: rig & animações
              </button>
            </div>
          </header>

          <main className="mt-auto pt-10 grid md:grid-cols-3 gap-4">
            {MOUNTAINS.map((m, i) => {
              const un = unlocked(m);
              const c = profile.data.conquered[m.id];
              return (
                <button
                  key={m.id}
                  onClick={() => setSel(i)}
                  className={`text-left glass rounded-2xl p-5 transition float-in ${sel === i ? 'ring-2 ring-sky-300 bg-sky-900/30' : 'hover:bg-white/10'} ${un ? '' : 'opacity-60'}`}
                  style={{ animationDelay: `${i * 0.08}s` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="title-font text-2xl">{m.name.toUpperCase()}</div>
                    <div className="text-xs text-amber-300 tabular-nums">{m.summitM.toLocaleString('pt-BR')} m</div>
                  </div>
                  <div className="text-sky-200 text-xs mt-0.5">{m.subtitle}</div>
                  <div className="mt-3 flex gap-1 items-center text-[10px] text-white/60">
                    DIFICULDADE
                    {Array.from({ length: 5 }).map((_, k) => (
                      <span key={k} className={k < m.difficulty ? 'text-orange-400' : 'text-white/20'}>
                        ▲
                      </span>
                    ))}
                  </div>
                  <div className="mt-2 text-[11px] text-white/70">{c ? `✔ Conquistada ${c.count}× · Recorde ${fmtTime(c.best)}` : un ? 'Ainda não conquistada' : `🔒 Conquiste ${MOUNTAINS.find((x) => x.id === m.requires)?.name}`}</div>
                </button>
              );
            })}
          </main>

          <section className="mt-4 glass rounded-2xl p-5 flex flex-col md:flex-row md:items-center gap-4 float-in">
            <div className="flex-1">
              <div className="title-font text-xl">{cur.name.toUpperCase()}</div>
              <p className="text-sm text-white/75 mt-1">{cur.desc}</p>
              <div className="text-[11px] text-white/50 mt-2">Tempo de referência: {fmtTime(cur.parTime)} · Clima: {cur.severity < 0.8 ? 'moderado' : cur.severity < 1.1 ? 'severo' : 'extremo'}</div>
            </div>
            <button disabled={!unlocked(cur)} className={`btn btn-primary text-base !px-10 !py-4 ${unlocked(cur) ? '' : 'opacity-40 cursor-not-allowed'}`} onClick={() => unlocked(cur) && onPlay(cur)}>
              {unlocked(cur) ? 'Iniciar expedição' : 'Bloqueada'}
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}

// ---------- Painel de perfil ----------
export function ProfilePanel({ profile, onClose, onReset }: { profile: Profile; onClose: () => void; onReset: () => void }) {
  const [tab, setTab] = useState<'stats' | 'ach' | 'equip' | 'rec'>('stats');
  const d = profile.data;
  const li = profile.levelInfo();
  const s = d.stats;
  const tabs: [typeof tab, string][] = [
    ['stats', 'Estatísticas'],
    ['ach', 'Conquistas'],
    ['equip', 'Equipamentos'],
    ['rec', 'Registro de montanhas'],
  ];
  const stat = (label: string, v: string) => (
    <div className="bg-white/5 rounded-lg px-3 py-2 border border-white/5">
      <div className="text-[10px] tracking-widest text-white/50">{label}</div>
      <div className="text-lg font-bold tabular-nums">{v}</div>
    </div>
  );
  return (
    <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-4 z-40">
      <div className="panel rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <div className="title-font text-3xl">PERFIL DO ALPINISTA</div>
            <div className="text-xs text-white/60">
              Nível {li.level} · {d.xp} XP · próximo nível em {xpForLevel(li.level + 1) - d.xp} XP
            </div>
          </div>
          <button className="btn btn-ghost" onClick={onClose}>
            Fechar
          </button>
        </div>
        <div className="flex gap-1 px-6 pt-3">
          {tabs.map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`px-4 py-2 rounded-t-lg text-sm font-semibold ${tab === k ? 'bg-sky-400/20 text-sky-200 border-b-2 border-sky-300' : 'text-white/60 hover:text-white'}`}>
              {l}
            </button>
          ))}
        </div>
        <div className="p-6 overflow-auto">
          {tab === 'stats' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {stat('GANHO DE ALTITUDE', `${Math.round(s.totalClimb).toLocaleString('pt-BR')} m`)}
              {stat('ALTITUDE MÁXIMA', `${Math.round(s.maxAlt).toLocaleString('pt-BR')} m`)}
              {stat('TEMPO DE JOGO', fmtTime(s.time))}
              {stat('TEMPO ESCALANDO', fmtTime(s.climbSeconds))}
              {stat('DISTÂNCIA A PÉ', `${(s.distance / 1000).toFixed(2)} km`)}
              {stat('CUMES', String(s.summits))}
              {stat('QUEDAS', String(s.falls))}
              {stat('MAIOR QUEDA', `${Math.round(s.maxFall)} m`)}
              {stat('PITONS FIXADOS', String(s.pitons))}
              {stat('SALVO PELA CORDA', String(s.ropeSaves))}
              {stat('ACAMPAMENTOS', String(s.camps))}
              {stat('DESFALECIMENTOS', String(s.deaths))}
              {stat('CAVERNAS', String(s.caves))}
              {stat('GELO ESCALADO', `${Math.round(s.iceClimb)} m`)}
            </div>
          )}
          {tab === 'ach' && (
            <div className="grid md:grid-cols-2 gap-3">
              {ACHIEVEMENTS.map((a) => {
                const got = d.achievements[a.id];
                return (
                  <div key={a.id} className={`flex gap-3 rounded-xl p-3 border ${got ? 'bg-amber-400/10 border-amber-300/40' : 'bg-white/5 border-white/5 opacity-60'}`}>
                    <div className="text-3xl">{got ? a.icon : '🔒'}</div>
                    <div>
                      <div className="font-bold">{a.name}</div>
                      <div className="text-xs text-white/70">{a.desc}</div>
                      <div className="text-[10px] text-amber-300 mt-1">+{a.xp} XP {got ? `· ${new Date(got).toLocaleDateString('pt-BR')}` : ''}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          {tab === 'equip' && (
            <div className="grid md:grid-cols-2 gap-3">
              {EQUIPMENT.map((e) => {
                const un = li.level >= e.level;
                return (
                  <div key={e.id} className={`flex gap-3 rounded-xl p-3 border ${un ? 'bg-sky-400/10 border-sky-300/30' : 'bg-white/5 border-white/5 opacity-60'}`}>
                    <div className="text-3xl">{un ? e.icon : '🔒'}</div>
                    <div>
                      <div className="font-bold">
                        {e.name} {e.key && <span className="text-[10px] border border-white/30 rounded px-1 ml-1">{e.key}</span>}
                      </div>
                      <div className="text-xs text-white/70">{e.desc}</div>
                      <div className="text-[10px] mt-1 text-sky-300">{un ? 'Desbloqueado' : `Desbloqueia no nível ${e.level}`}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          {tab === 'rec' && (
            <div className="grid gap-3">
              {MOUNTAINS.map((m) => {
                const c = d.conquered[m.id];
                return (
                  <div key={m.id} className="flex items-center justify-between bg-white/5 rounded-xl p-4 border border-white/5">
                    <div>
                      <div className="title-font text-xl">{m.name.toUpperCase()}</div>
                      <div className="text-xs text-white/60">
                        {m.summitM.toLocaleString('pt-BR')} m · referência {fmtTime(m.parTime)}
                      </div>
                    </div>
                    {c ? (
                      <div className="text-right">
                        <div className="text-emerald-300 font-bold">✔ Conquistada ({c.count}×)</div>
                        <div className="text-sm tabular-nums">Recorde: {fmtTime(c.best)}</div>
                        <div className="text-[10px] text-white/50">Última: {new Date(c.last).toLocaleDateString('pt-BR')}</div>
                      </div>
                    ) : (
                      <div className="text-white/50">Não conquistada</div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
        <div className="px-6 py-3 border-t border-white/10 flex justify-end">
          <button
            className="text-xs text-red-300/80 hover:text-red-300"
            onClick={() => {
              if (confirm('Apagar todo o progresso salvo?')) onReset();
            }}
          >
            Apagar progresso
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- Ajuda / controles ----------
export function HelpPanel({ onClose }: { onClose: () => void }) {
  const row = (k: string, d: string) => (
    <div className="flex gap-3 items-start text-sm">
      <div className="min-w-[110px] text-right">
        {k.split(' + ').map((x, i) => (
          <span key={i} className="inline-block border border-white/30 bg-white/10 rounded px-1.5 py-0.5 text-[11px] font-bold ml-1">
            {x}
          </span>
        ))}
      </div>
      <div className="text-white/80">{d}</div>
    </div>
  );
  return (
    <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="panel rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-auto p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="title-font text-3xl">CONTROLES</div>
          <button className="btn btn-ghost" onClick={onClose}>
            Fechar
          </button>
        </div>
        <div className="grid md:grid-cols-2 gap-x-8 gap-y-2">
          <div className="space-y-2">
            <div className="text-sky-300 text-xs tracking-[0.3em] mb-1">MOVIMENTO</div>
            {row('W A S D', 'Andar / mirar o alcance na parede')}
            {row('Mouse', 'Câmera (setas também giram)')}
            {row('Shift', 'Correr · na parede: apoiar os pés (menos carga)')}
            {row('Espaço', 'Pular · na parede: salto dinâmico (dyno)')}
            {row('Z', 'Soltar-se · na borda: descer pela parede')}
            {row('X', 'Agachar (segurar)')}
            {row('B', 'Modo cauteloso: caminhar com strafe')}
            {row('V', 'Modo vista (ver a dimensão da montanha)')}
            <div className="text-sky-300 text-xs tracking-[0.3em] mt-4 mb-1">ESCALADA</div>
            {row('Q', 'Mão esquerda (ou botão esquerdo do mouse)')}
            {row('E', 'Mão direita (ou botão direito do mouse)')}
          </div>
          <div className="space-y-2">
            <div className="text-sky-300 text-xs tracking-[0.3em] mb-1">EQUIPAMENTOS</div>
            {row('R', 'Fixar piton e amarrar a corda')}
            {row('C', 'Magnésio (aderência)')}
            {row('F', 'Comer ração')}
            {row('T', 'Beber chá quente')}
            {row('L', 'Lanterna')}
            {row('O', 'Cilindro de oxigênio')}
            <div className="text-sky-300 text-xs tracking-[0.3em] mt-4 mb-1">SISTEMA</div>
            {row('G', 'Alternar indicadores de apoio')}
            {row('H', 'Ajuda')}
            {row('P', 'Pausar')}
            {row('M', 'Silenciar')}
          </div>
        </div>
        <div className="mt-5 text-sm text-white/75 bg-white/5 rounded-xl p-4 border border-white/10 space-y-1.5">
          <div className="font-bold text-sky-200">Como escalar</div>
          <p>1. Ande contra uma parede íngreme: o alpinista se agarra. Ao chegar a uma borda suave, ele sobe sozinho.</p>
          <p>
            2. <b>Segure Q ou E</b> para soltar aquela mão e estender o braço; <b>mire com WASD</b> e <b>solte a tecla</b> para agarrar. Nunca solte as duas mãos ao mesmo tempo.
          </p>
          <p>
            3. Pontos <span className="text-emerald-300">verdes</span> = ótimo apoio · <span className="text-amber-300">amarelos</span> = médio · <span className="text-red-300">vermelhos</span> = ruim. Gelo exige piolet; rocha solta esfarela.
          </p>
          <p>4. Com uma só mão o corpo balança: use A/D para se equilibrar e Shift para firmar os pés. Fixe pitons (R) a cada ~15 m: a corda segura sua queda.</p>
          <p>5. Visite acampamentos 🚩 para salvar progresso, se aquecer e reabastecer. Fique de olho no frio, no vento e na energia.</p>
        </div>
      </div>
    </div>
  );
}

// ---------- Telas de estado ----------
export function LoadingScreen({ pct, label, name }: { pct: number; label: string; name: string }) {
  const tips = ['Pontos verdes na parede indicam bons apoios.', 'Fixe pitons com frequência: a corda só segura o que você já subiu.', 'Cavernas protegem do vento e do frio — mas escondem o escuro.', 'Mãos cansadas escorregam. Descanse em platôs para recuperar o fôlego.', 'Acima da linha de neve, o piolet é essencial para escalar gelo.'];
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center" style={{ background: 'radial-gradient(ellipse at center,#12233d,#050a12)' }}>
      <div className="title-font text-5xl text-white">{name.toUpperCase()}</div>
      <div className="text-sky-300 text-xs tracking-[0.4em] mt-2">PREPARANDO A EXPEDIÇÃO</div>
      <div className="w-[min(420px,80vw)] mt-8">
        <div className="bar-track" style={{ height: 8 }}>
          <div className="bar-fill" style={{ width: `${pct * 100}%`, background: 'linear-gradient(90deg,#38bdf8,#a78bfa)' }} />
        </div>
        <div className="text-xs text-white/60 mt-2 text-center">{label}</div>
      </div>
      <div className="absolute bottom-12 text-sm text-white/50 max-w-md text-center px-6">💡 {tips[Math.floor(pct * 10) % tips.length]}</div>
    </div>
  );
}

export function ReadyOverlay({ name, onStart, onBack }: { name: string; onStart: () => void; onBack: () => void }) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-end pb-[12vh] bg-gradient-to-t from-black/70 via-black/10 to-black/30">
      <div className="text-sky-200 text-xs tracking-[0.6em]">ACAMPAMENTO BASE</div>
      <div className="title-font text-6xl md:text-8xl text-white mt-2" style={{ textShadow: '0 6px 40px rgba(0,0,0,.6)' }}>
        {name.toUpperCase()}
      </div>
      <button className="btn btn-primary text-lg !px-12 !py-4 mt-8" onClick={onStart}>
        Clique para iniciar a escalada
      </button>
      <button className="text-xs text-white/60 mt-4 hover:text-white" onClick={onBack}>
        ← Voltar ao menu
      </button>
      <div className="text-[11px] text-white/50 mt-3">O jogo usará captura do mouse. Pressione P ou Esc para pausar.</div>
    </div>
  );
}

export function PauseMenu({ onResume, onProfile, onHelp, onQuit }: { onResume: () => void; onProfile: () => void; onHelp: () => void; onQuit: () => void }) {
  return (
    <div className="absolute inset-0 z-30 bg-black/60 backdrop-blur-sm flex items-center justify-center">
      <div className="panel rounded-2xl p-8 w-[min(380px,90vw)] flex flex-col gap-3 text-center">
        <div className="title-font text-4xl">PAUSADO</div>
        <button className="btn btn-primary" onClick={onResume}>
          Continuar
        </button>
        <button className="btn btn-ghost" onClick={onProfile}>
          Perfil e conquistas
        </button>
        <button className="btn btn-ghost" onClick={onHelp}>
          Controles
        </button>
        <button className="btn btn-ghost !text-red-300" onClick={onQuit}>
          Abandonar expedição
        </button>
      </div>
    </div>
  );
}

export function DeathOverlay({ reason }: { reason: string }) {
  const txt: Record<string, string> = {
    fall: 'Uma queda fatal.',
    cold: 'Hipotermia: o frio venceu.',
    rock: 'Atingido por uma pedra.',
    water: 'Engolido pelas águas geladas.',
    shock: 'O impacto da corda foi violento demais.',
    health: 'Seu corpo não aguentou.',
  };
  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/70">
      <div className="title-font text-6xl text-red-400">VOCÊ DESFALECEU</div>
      <div className="text-white/80 mt-2">{txt[reason] ?? ''}</div>
      <div className="text-white/50 text-sm mt-6">Retornando ao último acampamento…</div>
    </div>
  );
}

export function VictoryScreen({ v, onMenu, onContinue }: { v: VictoryInfo; onMenu: () => void; onContinue: () => void }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="panel rounded-3xl p-8 w-[min(560px,94vw)] text-center float-in" style={{ boxShadow: '0 0 80px rgba(251,191,36,.25)' }}>
        <div className="text-amber-300 text-xs tracking-[0.6em]">CUME CONQUISTADO</div>
        <div className="title-font text-5xl mt-1">{v.mountain.toUpperCase()}</div>
        {v.record && <div className="inline-block mt-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-bold tracking-widest">NOVO RECORDE!</div>}
        <div className="grid grid-cols-3 gap-3 mt-6">
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">TEMPO</div>
            <div className="text-2xl font-bold tabular-nums">{fmtTime(v.time)}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">RECORDE</div>
            <div className="text-2xl font-bold tabular-nums">{fmtTime(v.best)}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">XP GANHO</div>
            <div className="text-2xl font-bold text-sky-300 tabular-nums">+{v.xp}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">SUBIDA</div>
            <div className="text-xl font-bold tabular-nums">{v.climbed.toLocaleString('pt-BR')} m</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">PITONS</div>
            <div className="text-xl font-bold tabular-nums">{v.pitons}</div>
          </div>
          <div className="bg-white/5 rounded-xl p-3">
            <div className="text-[10px] tracking-widest text-white/50">QUEDAS</div>
            <div className="text-xl font-bold tabular-nums">{v.falls}</div>
          </div>
        </div>
        {v.achievements.length > 0 && (
          <div className="mt-5 text-sm">
            <div className="text-amber-300 text-xs tracking-widest mb-2">CONQUISTAS DESBLOQUEADAS</div>
            <div className="flex flex-wrap gap-2 justify-center">
              {v.achievements.map((id) => {
                const a = ACHIEVEMENTS.find((x) => x.id === id)!;
                return (
                  <span key={id} className="bg-amber-400/15 border border-amber-300/30 rounded-full px-3 py-1 text-xs">
                    {a.icon} {a.name}
                  </span>
                );
              })}
            </div>
          </div>
        )}
        <div className="flex gap-3 mt-8 justify-center">
          <button className="btn btn-ghost" onClick={onContinue}>
            Continuar explorando
          </button>
          <button className="btn btn-primary" onClick={onMenu}>
            Menu principal
          </button>
        </div>
      </div>
    </div>
  );
}

export function Toasts({ toasts }: { toasts: (Toast & { id: number })[] }) {
  const color = (k: Toast['kind']) => (k === 'warn' ? 'border-red-400/50 bg-red-950/60' : k === 'good' ? 'border-emerald-400/50 bg-emerald-950/60' : k === 'ach' ? 'border-amber-300/60 bg-amber-950/70' : 'border-sky-300/30 bg-slate-900/70');
  return (
    <div className="absolute top-[78px] left-1/2 -translate-x-1/2 flex flex-col gap-2 items-center z-10 pointer-events-none max-w-[80vw]">
      {toasts.map((t) => (
        <div key={t.id} className={`toast-in backdrop-blur-md border rounded-xl px-4 py-2 text-sm flex items-center gap-2 ${color(t.kind)}`}>
          {t.icon && <span className="text-lg">{t.icon}</span>}
          <span>{t.text}</span>
        </div>
      ))}
    </div>
  );
}
