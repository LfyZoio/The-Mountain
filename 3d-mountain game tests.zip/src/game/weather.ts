import * as THREE from 'three';
import { Noise, clamp, lerp, smoothstep } from './noise';

export type WeatherKind = 'clear' | 'fog' | 'snow' | 'blizzard';

export const WEATHER_NAMES: Record<WeatherKind, string> = {
  clear: 'Céu limpo',
  fog: 'Neblina densa',
  snow: 'Neve leve',
  blizzard: 'Nevasca violenta',
};

interface Preset {
  fog: number;
  precip: number;
  wind: number;
  light: number;
  cloud: number;
  temp: number;
  wet: number;
  top: THREE.Color;
  horizon: THREE.Color;
}

const P = (fog: number, precip: number, wind: number, light: number, cloud: number, temp: number, wet: number, top: number, horizon: number): Preset => ({
  fog,
  precip,
  wind,
  light,
  cloud,
  temp,
  wet,
  top: new THREE.Color(top),
  horizon: new THREE.Color(horizon),
});

const PRESETS: Record<WeatherKind, Preset> = {
  clear: P(0.00085, 0, 0.75, 1, 0.3, 2, 0, 0x2c64b8, 0xaecbe8),
  fog: P(0.0042, 0, 0.4, 0.55, 0.85, -1, 0.35, 0x8d9aa8, 0xb8c1c9),
  snow: P(0.0026, 0.55, 1.0, 0.62, 0.85, -4, 0.6, 0x707d8c, 0xa8b2bc),
  blizzard: P(0.0072, 1, 1.9, 0.36, 1, -9, 1, 0x4a5560, 0x8b959e),
};

export class Weather {
  kind: WeatherKind = 'clear';
  next: WeatherKind = 'clear';
  timer = 80;
  fog = PRESETS.clear.fog;
  precip = 0;
  windMul = PRESETS.clear.wind;
  light = 1;
  cloud = 0.3;
  tempOff = 2;
  wet = 0;
  top = PRESETS.clear.top.clone();
  horizon = PRESETS.clear.horizon.clone();
  private noise = new Noise(4242);
  private rnd = Math.random;
  windAngle = Math.random() * 6.28;

  update(dt: number, alt01: number, severity: number) {
    this.timer -= dt;
    if (this.timer <= 0) {
      const w: [WeatherKind, number][] = [
        ['clear', 0.5],
        ['fog', 0.2],
        ['snow', 0.2 + 0.15 * alt01],
        ['blizzard', (0.03 + 0.28 * smoothstep(0.1, 0.6, alt01)) * severity],
      ];
      const tot = w.reduce((a, b) => a + b[1], 0);
      let r = this.rnd() * tot;
      let pick: WeatherKind = 'clear';
      for (const [k, v] of w) {
        r -= v;
        if (r <= 0) {
          pick = k;
          break;
        }
      }
      this.kind = pick;
      this.timer = 70 + this.rnd() * 80;
    }
    const p = PRESETS[this.kind];
    const k = 1 - Math.exp(-dt * 0.35);
    this.fog = lerp(this.fog, p.fog, k);
    this.precip = lerp(this.precip, p.precip, k);
    this.windMul = lerp(this.windMul, p.wind, k);
    this.light = lerp(this.light, p.light, k);
    this.cloud = lerp(this.cloud, p.cloud, k);
    this.tempOff = lerp(this.tempOff, p.temp, k);
    this.wet = lerp(this.wet, p.wet, k);
    this.top.lerp(p.top, k);
    this.horizon.lerp(p.horizon, k);
  }

  force(kind: WeatherKind) {
    this.kind = kind;
    this.timer = 90;
  }

  /** Vento (m/s) em um ponto. */
  wind(t: number, y: number, exposure: number, severity: number, peak: number, out: THREE.Vector3): number {
    const a = y / peak;
    const base = (1.5 + 24 * smoothstep(0.2, 0.95, a)) * Math.sqrt(severity) * this.windMul * exposure;
    const gust = 0.72 + 0.28 * Math.sin(t * 0.6) * Math.sin(t * 0.23 + 2) + 0.35 * (this.noise.value(t * 0.4, 3.3) - 0.5);
    const speed = clamp(base * gust, 0, 48);
    const ang = this.windAngle + 0.4 * Math.sin(t * 0.03);
    out.set(Math.cos(ang) * speed, 0, Math.sin(ang) * speed);
    return speed;
  }
}

// ---------- Partículas de neve (GPU) ----------
export class SnowParticles {
  points: THREE.Points;
  mat: THREE.ShaderMaterial;
  constructor(count = 7000, public box = 80) {
    const g = new THREE.BufferGeometry();
    const seed = new Float32Array(count * 4);
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      seed[i * 4] = Math.random();
      seed[i * 4 + 1] = Math.random();
      seed[i * 4 + 2] = Math.random();
      seed[i * 4 + 3] = Math.random();
    }
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 4));
    this.mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uCenter: { value: new THREE.Vector3() },
        uWind: { value: new THREE.Vector3() },
        uBox: { value: box },
        uIntensity: { value: 0 },
        uFall: { value: 2.2 },
        uPixel: { value: 800 },
        uColor: { value: new THREE.Color(1, 1, 1) },
      },
      vertexShader: `
        attribute vec4 aSeed;
        uniform float uTime; uniform vec3 uCenter; uniform vec3 uWind; uniform float uBox;
        uniform float uIntensity; uniform float uFall; uniform float uPixel;
        varying float vAlpha;
        void main(){
          vec3 vel = vec3(uWind.x, -uFall*(0.6+0.8*aSeed.w), uWind.z);
          vec3 p = aSeed.xyz*uBox + vel*uTime + vec3(sin(uTime*0.8+aSeed.w*30.0)*0.6, 0.0, cos(uTime*0.7+aSeed.w*20.0)*0.6);
          p = mod(p - uCenter + uBox*0.5, uBox) - uBox*0.5;
          vec3 world = uCenter + p;
          vec4 mv = viewMatrix*vec4(world, 1.0);
          gl_Position = projectionMatrix*mv;
          float d = length(p)/(uBox*0.5);
          vAlpha = (1.0 - smoothstep(0.65, 1.0, d)) * step(aSeed.w, uIntensity);
          float size = 0.05 + 0.1*aSeed.z;
          gl_PointSize = max(size*uPixel/max(-mv.z, 0.1), 1.6);
        }`,
      fragmentShader: `
        uniform vec3 uColor; varying float vAlpha;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.15, d) * vAlpha;
          if (a < 0.01) discard;
          gl_FragColor = vec4(uColor, a*0.85);
        }`,
    });
    this.points = new THREE.Points(g, this.mat);
    this.points.frustumCulled = false;
  }

  update(time: number, center: THREE.Vector3, wind: THREE.Vector3, intensity: number, fall: number, pixel: number) {
    const u = this.mat.uniforms;
    u.uTime.value = time % 2000;
    u.uCenter.value.copy(center);
    u.uWind.value.copy(wind).multiplyScalar(0.85);
    u.uIntensity.value = intensity;
    u.uFall.value = fall;
    u.uPixel.value = pixel;
    this.points.visible = intensity > 0.01;
  }
}
