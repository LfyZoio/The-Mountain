import * as THREE from 'three';
import { Terrain } from './terrain';

export interface Camp {
  index: number;
  name: string;
  pos: THREE.Vector3; // chão
  isCave: boolean;
  y01: number;
  downhill: THREE.Vector2; // direção horizontal morro abaixo (normalizada)
}

export interface Cave {
  center: THREE.Vector3;
  R: number;
  H: number;
  gapAngle: number; // ângulo (atan2(dz,dx)) do centro da abertura
  gap: number;
  campIndex: number;
}

export interface Layout {
  camps: Camp[];
  caves: Cave[];
  summit: THREE.Vector3;
}

const FRACTIONS = [0, 0.13, 0.27, 0.4, 0.54, 0.68, 0.82];
const NAMES = ['Acampamento Base', 'Acampamento Pinheiral', 'Abrigo da Gruta', 'Posto dos Penhascos', 'Gruta de Cristal', 'Platô do Vento', 'Abrigo do Cume'];
const CAVE_CAMPS = new Set([2, 4, 6]);

/** Define pontos de interesse e aplica plataformas ao terreno antes de gerar a malha. */
export function planLayout(t: Terrain): Layout {
  const def = t.def;
  // cume: máximo na região central
  let best = -1e9,
    sx = 0,
    sz = 0;
  for (let x = -def.radius * 0.35; x <= def.radius * 0.35; x += 3) {
    for (let z = -def.radius * 0.35; z <= def.radius * 0.35; z += 3) {
      const h = t.rawHeight(x, z);
      if (h > best) {
        best = h;
        sx = x;
        sz = z;
      }
    }
  }
  const summitY = best - 2.2;
  t.mods.push({ x: sx, z: sz, y: summitY, flat: 3, blend: 8 });

  const camps: Camp[] = [];
  const caves: Cave[] = [];
  FRACTIONS.forEach((f, k) => {
    const target = k === 0 ? 13 : f * def.peak;
    const ang = def.theta0 + k * 0.78;
    const cx = Math.cos(ang),
      cz = Math.sin(ang);
    let px = cx * def.radius * 0.85,
      pz = cz * def.radius * 0.85;
    for (let r = def.radius * 1.0; r > 0; r -= 1.5) {
      const x = cx * r,
        z = cz * r;
      if (t.rawHeight(x, z) >= target) {
        px = x;
        pz = z;
        break;
      }
    }
    const y = t.rawHeight(px, pz);
    const isCave = CAVE_CAMPS.has(k);
    t.mods.push({ x: px, z: pz, y, flat: isCave ? 10 : 6, blend: isCave ? 7 : 9 });
    // direção morro abaixo
    const e = 6;
    const gx = t.rawHeight(px + e, pz) - t.rawHeight(px - e, pz);
    const gz = t.rawHeight(px, pz + e) - t.rawHeight(px, pz - e);
    let dx = -gx,
      dz = -gz;
    const l = Math.hypot(dx, dz);
    if (l < 0.01) {
      dx = cx;
      dz = cz;
    } else {
      dx /= l;
      dz /= l;
    }
    camps.push({
      index: k,
      name: NAMES[k],
      pos: new THREE.Vector3(px, y, pz),
      isCave,
      y01: y / def.peak,
      downhill: new THREE.Vector2(dx, dz),
    });
    if (isCave) {
      caves.push({
        center: new THREE.Vector3(px, y, pz),
        R: 11.5,
        H: 7.5,
        gapAngle: Math.atan2(dz, dx),
        gap: 1.25,
        campIndex: k,
      });
    }
  });
  return { camps, caves, summit: new THREE.Vector3(sx, summitY, sz) };
}
