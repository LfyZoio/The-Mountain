import { ACHIEVEMENTS, EQUIPMENT, EquipId, xpForLevel } from './config';

export interface Stats {
  totalClimb: number;
  falls: number;
  maxFall: number;
  distance: number;
  time: number;
  pitons: number;
  deaths: number;
  summits: number;
  camps: number;
  maxAlt: number;
  ropeSaves: number;
  iceClimb: number;
  caves: number;
  climbSeconds: number;
}

export interface Conquest {
  best: number;
  count: number;
  last: number;
}

export interface ProfileData {
  xp: number;
  stats: Stats;
  achievements: Record<string, number>;
  conquered: Record<string, Conquest>;
}

const KEY = 'mountain-climbing-3d.profile.v1';

const emptyStats = (): Stats => ({
  totalClimb: 0,
  falls: 0,
  maxFall: 0,
  distance: 0,
  time: 0,
  pitons: 0,
  deaths: 0,
  summits: 0,
  camps: 0,
  maxAlt: 0,
  ropeSaves: 0,
  iceClimb: 0,
  caves: 0,
  climbSeconds: 0,
});

export class Profile {
  data: ProfileData;
  constructor() {
    this.data = { xp: 0, stats: emptyStats(), achievements: {}, conquered: {} };
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const d = JSON.parse(raw);
        this.data = {
          xp: d.xp || 0,
          stats: { ...emptyStats(), ...(d.stats || {}) },
          achievements: d.achievements || {},
          conquered: d.conquered || {},
        };
      }
    } catch {
      /* perfil corrompido: recomeça */
    }
  }

  save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.data));
    } catch {
      /* ignore */
    }
  }

  reset() {
    this.data = { xp: 0, stats: emptyStats(), achievements: {}, conquered: {} };
    this.save();
  }

  get level() {
    let l = 1;
    while (this.data.xp >= xpForLevel(l + 1)) l++;
    return l;
  }

  levelInfo() {
    const l = this.level;
    const base = xpForLevel(l);
    const next = xpForLevel(l + 1);
    return { level: l, cur: this.data.xp - base, need: next - base, frac: (this.data.xp - base) / (next - base) };
  }

  /** Retorna os novos níveis alcançados (se houver). */
  addXp(n: number): number[] {
    const before = this.level;
    this.data.xp += Math.round(n);
    const after = this.level;
    const ups: number[] = [];
    for (let l = before + 1; l <= after; l++) ups.push(l);
    return ups;
  }

  has(id: string) {
    return !!this.data.achievements[id];
  }

  unlockAch(id: string): number {
    if (this.has(id)) return 0;
    const a = ACHIEVEMENTS.find((x) => x.id === id);
    if (!a) return 0;
    this.data.achievements[id] = Date.now();
    return a.xp;
  }

  equipUnlocked(id: EquipId) {
    const e = EQUIPMENT.find((x) => x.id === id)!;
    return this.level >= e.level;
  }

  isConquered(id: string) {
    return !!this.data.conquered[id];
  }
}

export const fmtTime = (s: number) => {
  s = Math.max(0, Math.floor(s));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return (h > 0 ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(sec).padStart(2, '0');
};
