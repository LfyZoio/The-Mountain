// Utilidades matemáticas e ruído procedural determinístico.

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Noise {
  constructor(public seed: number) {}

  private h(ix: number, iy: number, period = 0) {
    if (period > 0) {
      ix = ((ix % period) + period) % period;
      iy = ((iy % period) + period) % period;
    }
    let h = Math.imul(ix, 374761393) ^ Math.imul(iy, 668265263) ^ Math.imul(this.seed + 1, 1274126177);
    h = Math.imul(h ^ (h >>> 13), 1103515245);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }

  /** Ruído de valor 0..1 */
  value(x: number, y: number, period = 0) {
    const ix = Math.floor(x),
      iy = Math.floor(y);
    const fx = x - ix,
      fy = y - iy;
    const u = fx * fx * (3 - 2 * fx);
    const v = fy * fy * (3 - 2 * fy);
    const a = this.h(ix, iy, period),
      b = this.h(ix + 1, iy, period),
      c = this.h(ix, iy + 1, period),
      d = this.h(ix + 1, iy + 1, period);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }

  fbm(x: number, y: number, oct = 5, lac = 2, gain = 0.5) {
    let s = 0,
      a = 0.5,
      f = 1,
      n = 0;
    for (let i = 0; i < oct; i++) {
      s += a * this.value(x * f, y * f);
      n += a;
      a *= gain;
      f *= lac;
    }
    return s / n;
  }

  /** fbm periódico (para texturas que repetem) */
  fbmTile(x: number, y: number, period: number, oct = 4) {
    let s = 0,
      a = 0.5,
      f = 1,
      n = 0;
    for (let i = 0; i < oct; i++) {
      s += a * this.value(x * f, y * f, period * f);
      n += a;
      a *= 0.5;
      f *= 2;
    }
    return s / n;
  }

  ridged(x: number, y: number, oct = 5) {
    let s = 0,
      a = 0.5,
      f = 1,
      n = 0;
    for (let i = 0; i < oct; i++) {
      let v = 1 - Math.abs(this.value(x * f, y * f) * 2 - 1);
      v *= v;
      s += a * v;
      n += a;
      a *= 0.5;
      f *= 2.03;
    }
    return s / n;
  }
}
