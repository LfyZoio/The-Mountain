import { clamp, lerp, smoothstep } from './noise';

export interface SurvivalCtx {
  effort: number; // 0..1
  resting: boolean;
  ambient: number; // °C
  insulation: number; // 0..1
  altFrac: number;
  nearFire: boolean;
  inCave: boolean;
  wet: number;
}

export class Survival {
  stamina = 100;
  staminaMax = 100;
  health = 100;
  energy = 100;
  temp = 37;
  oxygen = 100;
  oxygenOn = false;
  lampOn = false;
  exhausted = false;
  o2 = 1;
  chalkTimer = 0;
  heatPending = 0;
  hurtFlash = 0;
  items = { pitons: 8, chalk: 4, food: 3, tea: 2 };
  private noHeal = 0;

  useStamina(n: number): boolean {
    if (this.stamina < n) {
      this.stamina = 0;
      this.exhausted = true;
      return false;
    }
    this.stamina -= n;
    return true;
  }

  damage(n: number) {
    this.health = Math.max(0, this.health - n);
    this.hurtFlash = Math.min(1, this.hurtFlash + n / 30);
    this.noHeal = 6;
  }

  restock() {
    this.items.pitons = Math.max(this.items.pitons, 8);
    this.items.chalk = Math.max(this.items.chalk, 4);
    this.items.food = Math.max(this.items.food, 3);
    this.items.tea = Math.max(this.items.tea, 2);
    this.oxygen = 100;
  }

  update(dt: number, c: SurvivalCtx) {
    // oxigênio / ar rarefeito
    let o2 = 1 - smoothstep(0.55, 1.0, c.altFrac) * 0.5;
    if (this.oxygenOn && this.oxygen > 0) {
      o2 = 1;
      this.oxygen = Math.max(0, this.oxygen - 0.55 * dt);
      if (this.oxygen <= 0) this.oxygenOn = false;
    }
    this.o2 = o2;

    // temperatura corporal
    const metabolic = 0.006 + 0.014 * c.effort;
    const loss = (this.temp - c.ambient) * 0.00064 * (1 - c.insulation) * (1 + c.wet * 0.15);
    let d = metabolic - loss;
    if (c.nearFire) d += 0.06;
    if (this.heatPending > 0) {
      const h = Math.min(this.heatPending, 0.25 * dt);
      this.heatPending -= h;
      this.temp += h;
    }
    this.temp = clamp(this.temp + d * dt, 28, 37.6);

    // energia
    this.energy = clamp(this.energy - (0.1 + 0.35 * c.effort) * dt, 0, 100);

    // limite de stamina
    let cap = 100 * (0.5 + 0.5 * o2);
    if (this.temp < 36) cap *= 1 - clamp((36 - this.temp) * 0.14, 0, 0.7);
    if (this.energy < 20) cap *= 0.6 + 0.4 * (this.energy / 20);
    this.staminaMax = lerp(this.staminaMax, cap, Math.min(1, dt * 2));
    this.stamina = Math.min(this.stamina, this.staminaMax);

    if (c.resting) {
      const regen = (c.nearFire ? 28 : 15) * o2 * (this.energy > 0 ? 1 : 0.5);
      this.stamina = Math.min(this.staminaMax, this.stamina + regen * dt);
    }
    if (this.stamina <= 0.5) this.exhausted = true;
    else if (this.stamina > 25) this.exhausted = false;

    // saúde
    if (this.temp < 33.5) this.damage((33.5 - this.temp) * 0.6 * dt);
    if (this.energy <= 0) this.damage(0.4 * dt);
    this.noHeal = Math.max(0, this.noHeal - dt);
    if (this.noHeal <= 0 && this.temp > 35 && this.energy > 15 && this.health < 100) {
      this.health = Math.min(100, this.health + (c.nearFire ? 3 : 0.35) * dt);
    }
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 1.2);
    this.chalkTimer = Math.max(0, this.chalkTimer - dt);
  }

  respawn() {
    this.health = 70;
    this.stamina = this.staminaMax = 100;
    this.temp = Math.max(this.temp, 36);
    this.energy = Math.max(this.energy, 35);
    this.exhausted = false;
    this.heatPending = 0;
  }
}
