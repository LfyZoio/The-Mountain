import * as THREE from 'three';
import { Terrain } from './terrain';
import { mulberry32 } from './noise';

/** Partículas de impacto: poeira, magnésio, detritos. */
export class FX {
  points: THREE.Points;
  private N = 400;
  private pos: Float32Array;
  private col: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private head = 0;
  private rnd = mulberry32(77);

  constructor() {
    this.pos = new Float32Array(this.N * 3).fill(-99999);
    this.col = new Float32Array(this.N * 3);
    this.vel = new Float32Array(this.N * 3);
    this.life = new Float32Array(this.N);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    const m = new THREE.PointsMaterial({ size: 0.16, vertexColors: true, transparent: true, depthWrite: false, opacity: 0.9 });
    this.points = new THREE.Points(g, m);
    this.points.frustumCulled = false;
  }

  burst(p: THREE.Vector3, color: number, n: number, speed: number, up = 1) {
    const c = new THREE.Color(color);
    for (let i = 0; i < n; i++) {
      const k = this.head;
      this.head = (this.head + 1) % this.N;
      this.pos[k * 3] = p.x;
      this.pos[k * 3 + 1] = p.y;
      this.pos[k * 3 + 2] = p.z;
      this.vel[k * 3] = (this.rnd() - 0.5) * speed;
      this.vel[k * 3 + 1] = this.rnd() * speed * up;
      this.vel[k * 3 + 2] = (this.rnd() - 0.5) * speed;
      this.col[k * 3] = c.r;
      this.col[k * 3 + 1] = c.g;
      this.col[k * 3 + 2] = c.b;
      this.life[k] = 0.6 + this.rnd() * 0.7;
    }
  }

  update(dt: number) {
    for (let k = 0; k < this.N; k++) {
      if (this.life[k] <= 0) continue;
      this.life[k] -= dt;
      if (this.life[k] <= 0) {
        this.pos[k * 3 + 1] = -99999;
        continue;
      }
      this.vel[k * 3 + 1] -= 14 * dt;
      this.pos[k * 3] += this.vel[k * 3] * dt;
      this.pos[k * 3 + 1] += this.vel[k * 3 + 1] * dt;
      this.pos[k * 3 + 2] += this.vel[k * 3 + 2] * dt;
    }
    (this.points.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.points.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
}

/** Pedras rolando morro abaixo: obstáculo natural nos penhascos. */
export class Rockfall {
  group = new THREE.Group();
  private rocks: { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; r: number; cd: number }[] = [];
  private timer = 14;
  private warnCd = 0;

  constructor() {
    const geo = new THREE.IcosahedronGeometry(1, 1);
    const mat = new THREE.MeshStandardMaterial({ color: 0x4d4741, roughness: 1, flatShading: true });
    for (let i = 0; i < 8; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.visible = false;
      this.group.add(mesh);
      this.rocks.push({ mesh, vel: new THREE.Vector3(), life: 0, r: 0.6, cd: 0 });
    }
  }

  reset() {
    for (const r of this.rocks) {
      r.life = 0;
      r.mesh.visible = false;
    }
  }

  update(
    dt: number,
    player: THREE.Vector3,
    terrain: Terrain,
    enabled: boolean,
    intensity: number,
    onWarn: () => void,
    onHit: (speed: number, dir: THREE.Vector3) => void,
    onImpact: (p: THREE.Vector3, speed: number) => void,
  ) {
    this.warnCd = Math.max(0, this.warnCd - dt);
    if (enabled) {
      this.timer -= dt;
      if (this.timer <= 0) {
        this.timer = (14 + Math.random() * 12) / Math.max(0.3, intensity);
        const free = this.rocks.find((r) => r.life <= 0);
        if (free) {
          terrain.heightAt(player.x, player.z);
          let ax = terrain.gx,
            az = terrain.gz;
          const l = Math.hypot(ax, az);
          if (l < 0.25) {
            ax = -player.x;
            az = -player.z;
          }
          const ll = Math.hypot(ax, az) || 1;
          ax /= ll;
          az /= ll;
          const side = (Math.random() - 0.5) * 14;
          const dist = 30 + Math.random() * 18;
          const x = player.x + ax * dist - az * side;
          const z = player.z + az * dist + ax * side;
          free.r = 0.5 + Math.random() * 0.5;
          free.mesh.position.set(x, terrain.heightAt(x, z) + free.r + 1, z);
          free.mesh.scale.setScalar(free.r);
          free.vel.set(-ax * 3, 0, -az * 3);
          free.life = 22;
          free.cd = 0;
          free.mesh.visible = true;
          if (this.warnCd <= 0) {
            onWarn();
            this.warnCd = 35;
          }
        }
      }
    }
    for (const r of this.rocks) {
      if (r.life <= 0) continue;
      r.life -= dt;
      r.cd = Math.max(0, r.cd - dt);
      r.vel.y -= 24 * dt;
      r.mesh.position.addScaledVector(r.vel, dt);
      r.mesh.rotation.x += r.vel.z * dt * 0.5;
      r.mesh.rotation.z -= r.vel.x * dt * 0.5;
      const p = r.mesh.position;
      const h = terrain.heightAt(p.x, p.z);
      if (p.y - r.r < h) {
        p.y = h + r.r;
        const gx = terrain.gx,
          gz = terrain.gz;
        const l = Math.sqrt(gx * gx + 1 + gz * gz);
        const nx = -gx / l,
          ny = 1 / l,
          nz = -gz / l;
        const vn = r.vel.x * nx + r.vel.y * ny + r.vel.z * nz;
        if (vn < 0) {
          if (-vn > 7) onImpact(p, -vn);
          r.vel.x -= nx * vn * 1.35;
          r.vel.y -= ny * vn * 1.35;
          r.vel.z -= nz * vn * 1.35;
          r.vel.x *= 0.985;
          r.vel.z *= 0.985;
        }
      }
      const d = p.distanceTo(player);
      if (d > 140) r.life = 0;
      if (r.life <= 0) r.mesh.visible = false;
      if (r.cd <= 0 && d < r.r + 0.85) {
        const sp = r.vel.length();
        if (sp > 4) {
          r.cd = 1.5;
          onHit(sp, r.vel);
        }
      }
    }
  }
}
