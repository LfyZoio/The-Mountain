import * as THREE from 'three';
import { Terrain } from './terrain';
import { clamp, lerp, smoothstep } from './noise';

/** Câmera em terceira pessoa cinematográfica: órbita, colisão com o terreno, modo vista e intro. */
export class CameraRig {
  yaw = 0;
  pitch = 0.28;
  dist = 5.5;
  fov = 62;
  vista = false;
  introT = 0; // 0..1 (1 = terminou)
  introDur = 9;
  private occl = 1;
  private idle = 0;
  private shake = 0;
  private lookAt = new THREE.Vector3();
  private tmp = new THREE.Vector3();
  private tmp2 = new THREE.Vector3();

  constructor(
    public camera: THREE.PerspectiveCamera,
    private terrain: Terrain,
  ) {}

  startIntro(summit: THREE.Vector3) {
    this.introT = 0;
    this.summit = summit.clone();
  }
  private summit = new THREE.Vector3();

  addShake(v: number) {
    this.shake = Math.min(1.5, this.shake + v);
  }

  update(
    dt: number,
    time: number,
    target: THREE.Vector3,
    opts: { climbing: boolean; wallYaw: number; look: { dx: number; dy: number }; sprint: boolean; wind: number; falling: boolean },
  ) {
    const { dx, dy } = opts.look;
    if (dx !== 0 || dy !== 0) this.idle = 0;
    else this.idle += dt;
    this.yaw -= dx * 0.0024;
    this.pitch = clamp(this.pitch + dy * 0.0024, -0.45, 1.25);

    // intro cinematográfica
    if (this.introT < 1) {
      this.introT = Math.min(1, this.introT + dt / this.introDur);
      const e = this.introT * this.introT * (3 - 2 * this.introT);
      const a = 0.6 + this.introT * 2.2;
      const rr = lerp(this.terrain.def.radius * 1.15, 22, smoothstep(0.35, 1, this.introT));
      const cx = lerp(0, target.x, e),
        cz = lerp(0, target.z, e);
      const py = lerp(this.terrain.def.peak * 0.75, target.y + 4, e);
      const desired = this.tmp.set(cx + Math.cos(a + e * 2) * rr * (1 - e * 0.0), py, cz + Math.sin(a + e * 2) * rr);
      this.camera.position.lerp(desired, this.introT < 0.02 ? 1 : 0.2);
      this.lookAt.lerpVectors(this.summit, target, smoothstep(0.25, 1, this.introT));
      this.camera.lookAt(this.lookAt);
      this.camera.fov = lerp(this.camera.fov, 55, 0.05);
      this.camera.updateProjectionMatrix();
      if (this.introT >= 1) {
        // alinha órbita com a posição final para uma transição suave
        const dx = this.camera.position.x - target.x,
          dz = this.camera.position.z - target.z;
        const hd = Math.hypot(dx, dz);
        this.yaw = Math.atan2(dx, dz);
        this.pitch = clamp(Math.atan2(this.camera.position.y - target.y - 0.5, hd), -0.4, 1.2);
        this.dist = Math.hypot(hd, this.camera.position.y - target.y);
      }
      return;
    }

    // alinha atrás do jogador quando escalando e parado
    if (opts.climbing && this.idle > 1.2) {
      const diff = Math.atan2(Math.sin(opts.wallYaw - this.yaw), Math.cos(opts.wallYaw - this.yaw));
      this.yaw += diff * Math.min(1, dt * 1.2);
    }

    const wantDist = this.vista ? 80 : opts.climbing ? 4.4 : 5.6;
    const wantPitch = this.vista ? Math.max(this.pitch, 0.35) : this.pitch;
    this.dist = lerp(this.dist, wantDist, 1 - Math.exp(-dt * 2.5));
    const fovT = this.vista ? 72 : opts.sprint ? 68 : opts.falling ? 72 : 62;
    this.fov = lerp(this.fov, fovT, 1 - Math.exp(-dt * 3));

    const cp = Math.cos(wantPitch);
    const dir = this.tmp.set(Math.sin(this.yaw) * cp, Math.sin(wantPitch), Math.cos(this.yaw) * cp);
    const head = this.tmp2.copy(target);
    head.y += 0.5;
    // colisão com o terreno por marcha de raio
    let f = 1;
    const steps = 18;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const px = head.x + dir.x * this.dist * t;
      const py = head.y + dir.y * this.dist * t;
      const pz = head.z + dir.z * this.dist * t;
      if (py < this.terrain.heightAt(px, pz) + 0.7) {
        f = Math.max(0.12, t - 1 / steps);
        break;
      }
    }
    this.occl = f < this.occl ? f : lerp(this.occl, f, 1 - Math.exp(-dt * 2));
    const d = this.dist * this.occl;
    const cam = this.camera.position;
    cam.set(head.x + dir.x * d, head.y + dir.y * d, head.z + dir.z * d);
    const gh = this.terrain.heightAt(cam.x, cam.z) + 0.8;
    if (cam.y < gh) cam.y = gh;

    this.shake = Math.max(0, this.shake - dt * 1.5);
    const sh = this.shake * 0.12 + Math.max(0, opts.wind - 18) / 40 * 0.04;
    if (sh > 0.001) {
      cam.x += (Math.sin(time * 41) + Math.sin(time * 23)) * sh * 0.5;
      cam.y += Math.sin(time * 37 + 1) * sh * 0.5;
    }
    this.lookAt.copy(head);
    this.lookAt.y += this.vista ? 6 : 0.1;
    this.camera.lookAt(this.lookAt);
    if (Math.abs(this.camera.fov - this.fov) > 0.05) {
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
    }
  }

  /** Direção horizontal (para frente) da câmera. */
  forward(out: THREE.Vector3) {
    return out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
  }
  right(out: THREE.Vector3) {
    return out.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
  }
}
