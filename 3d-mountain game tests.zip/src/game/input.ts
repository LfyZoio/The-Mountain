export class Input {
  keys = new Set<string>();
  pressed = new Set<string>();
  mouseDX = 0;
  mouseDY = 0;
  buttons = [false, false, false];
  locked = false;
  private el: HTMLElement;
  private handlers: [any, string, any][] = [];

  constructor(el: HTMLElement) {
    this.el = el;
    const on = (t: any, ev: string, fn: any, opt?: any) => {
      t.addEventListener(ev, fn, opt);
      this.handlers.push([t, ev, fn]);
    };
    on(window, 'keydown', (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
      if (!e.repeat) this.pressed.add(e.code);
      this.keys.add(e.code);
    });
    on(window, 'keyup', (e: KeyboardEvent) => this.keys.delete(e.code));
    on(window, 'blur', () => {
      this.keys.clear();
      this.buttons = [false, false, false];
    });
    on(window, 'mousemove', (e: MouseEvent) => {
      if (this.locked) {
        this.mouseDX += e.movementX;
        this.mouseDY += e.movementY;
      }
    });
    on(el, 'mousedown', (e: MouseEvent) => {
      this.buttons[e.button] = true;
      e.preventDefault();
    });
    on(window, 'mouseup', (e: MouseEvent) => {
      this.buttons[e.button] = false;
    });
    on(el, 'contextmenu', (e: Event) => e.preventDefault());
    on(document, 'pointerlockchange', () => {
      this.locked = document.pointerLockElement === this.el;
    });
  }

  lock() {
    try {
      const r = this.el.requestPointerLock() as unknown as Promise<void> | undefined;
      if (r && typeof r.catch === 'function') r.catch(() => {});
    } catch {
      /* ignora */
    }
  }

  unlock() {
    if (document.pointerLockElement === this.el) document.exitPointerLock();
  }

  down(code: string) {
    return this.keys.has(code);
  }

  hit(code: string) {
    return this.pressed.has(code);
  }

  endFrame() {
    this.pressed.clear();
    this.mouseDX = 0;
    this.mouseDY = 0;
  }

  dispose() {
    for (const [t, ev, fn] of this.handlers) t.removeEventListener(ev, fn);
    this.unlock();
  }
}
