import * as THREE from 'three';
import { MountainDef } from './config';
import { Noise, clamp, lerp, smoothstep } from './noise';

export type Mat = 'grass' | 'rock' | 'scree' | 'snow' | 'ice' | 'sand';

export interface SurfaceInfo {
  h: number;
  nx: number;
  ny: number;
  nz: number;
  slope: number;
  mat: Mat;
}

export interface Modifier {
  x: number;
  z: number;
  y: number;
  flat: number;
  blend: number;
}

export const MAT_GRIP: Record<Mat, number> = {
  grass: 0.62,
  rock: 0.9,
  scree: 0.5,
  snow: 0.55,
  ice: 0.3,
  sand: 0.6,
};

export const MAT_NAMES: Record<Mat, string> = {
  grass: 'Terra',
  rock: 'Rocha',
  scree: 'Pedra solta',
  snow: 'Neve',
  ice: 'Gelo',
  sand: 'Areia',
};

export class Terrain {
  readonly N = 512;
  readonly size: number;
  readonly half: number;
  readonly sp: number;
  heights: Float32Array;
  mods: Modifier[] = [];
  private nA: Noise;
  private nB: Noise;
  private nC: Noise;
  gx = 0;
  gz = 0;

  constructor(public def: MountainDef) {
    this.half = def.half;
    this.size = def.half * 2;
    this.sp = this.size / this.N;
    this.heights = new Float32Array((this.N + 1) * (this.N + 1));
    this.nA = new Noise(def.seed);
    this.nB = new Noise(def.seed * 7 + 3);
    this.nC = new Noise(def.seed * 13 + 5);
  }

  /** Altura natural, sem plataformas de acampamento. */
  rawHeight(x: number, z: number): number {
    const d = this.def;
    const R = d.radius,
      P = d.peak;
    const wx = x + 70 * (this.nA.fbm(x * 0.0035 + 7, z * 0.0035 + 3, 3) - 0.5) * 2;
    const wz = z + 70 * (this.nA.fbm(x * 0.0035 + 31, z * 0.0035 + 19, 3) - 0.5) * 2;
    const r = Math.hypot(wx, wz);
    const t = clamp(1 - r / R, 0, 1);
    let h = P * 0.88 * Math.pow(t, 1.3);
    h += P * 0.14 * Math.exp(-Math.pow(r / (R * 0.12), 2));
    const ridge = this.nB.ridged(x * 0.0055, z * 0.0055, 5);
    h += (ridge - 0.45) * P * 0.26 * smoothstep(0.02, 0.35, t);
    h += (this.nA.fbm(x * 0.012, z * 0.012, 4) - 0.5) * 12 * (0.4 + 0.6 * smoothstep(0, 0.3, t));
    const rr = Math.hypot(x, z);
    h += 9 - 18 * smoothstep(R * 0.92, d.half * 0.93, rr);

    // terraços: patamares + paredões
    const a = h / P;
    const strength = lerp(0.12, 1.0, smoothstep(0.1, 0.4, a));
    const trail = smoothstep(0.3, 0.55, this.nC.fbm(x * 0.007 + 11, z * 0.007 + 5, 3));
    const mask = lerp(1, trail, 1 - smoothstep(0.35, 0.6, a));
    const step = 15 + 5 * this.nC.value(x * 0.004 + 3, z * 0.004 + 9);
    const off = 12 * (this.nC.fbm(x * 0.011, z * 0.011, 3) - 0.5);
    const tt = (h + off) / step;
    const i = Math.floor(tt);
    const f = tt - i;
    const terr = (i + smoothstep(0.62, 1.0, f)) * step - off;
    return lerp(h, terr, strength * mask);
  }

  finalHeight(x: number, z: number): number {
    let h = this.rawHeight(x, z);
    for (const m of this.mods) {
      const d = Math.hypot(x - m.x, z - m.z);
      if (d < m.flat + m.blend) {
        const w = d < m.flat ? 1 : 1 - smoothstep(m.flat, m.flat + m.blend, d);
        h = lerp(h, m.y, w);
      }
    }
    return h;
  }

  buildGrid() {
    const N1 = this.N + 1;
    for (let j = 0; j < N1; j++) {
      const z = -this.half + j * this.sp;
      for (let i = 0; i < N1; i++) {
        const x = -this.half + i * this.sp;
        this.heights[j * N1 + i] = this.finalHeight(x, z);
      }
    }
  }

  /** Interpolação triangular idêntica à malha renderizada. Atualiza gx/gz. */
  sample(x: number, z: number): number {
    const N = this.N,
      N1 = N + 1;
    let u = (x + this.half) / this.sp;
    let v = (z + this.half) / this.sp;
    u = clamp(u, 0, N - 0.0001);
    v = clamp(v, 0, N - 0.0001);
    const i = Math.floor(u),
      j = Math.floor(v);
    const fx = u - i,
      fz = v - j;
    const H = this.heights;
    const h00 = H[j * N1 + i],
      h10 = H[j * N1 + i + 1],
      h01 = H[(j + 1) * N1 + i],
      h11 = H[(j + 1) * N1 + i + 1];
    if (fx + fz <= 1) {
      this.gx = (h10 - h00) / this.sp;
      this.gz = (h01 - h00) / this.sp;
      return h00 + fx * (h10 - h00) + fz * (h01 - h00);
    }
    this.gx = (h11 - h01) / this.sp;
    this.gz = (h11 - h10) / this.sp;
    return h11 + (1 - fx) * (h01 - h11) + (1 - fz) * (h10 - h11);
  }

  heightAt(x: number, z: number) {
    return this.sample(x, z);
  }

  slopeAt(x: number, z: number) {
    this.sample(x, z);
    return Math.hypot(this.gx, this.gz);
  }

  surface(x: number, z: number, out: SurfaceInfo): SurfaceInfo {
    const h = this.sample(x, z);
    const gx = this.gx,
      gz = this.gz;
    const l = Math.sqrt(gx * gx + 1 + gz * gz);
    out.h = h;
    out.nx = -gx / l;
    out.ny = 1 / l;
    out.nz = -gz / l;
    out.slope = Math.hypot(gx, gz);
    out.mat = this.materialAt(x, z, h, out.slope);
    return out;
  }

  materialAt(x: number, z: number, h: number, slope: number): Mat {
    const a = h / this.def.peak;
    if (h < 1.6) return 'sand';
    const n = this.nB.fbm(x * 0.02 + 90, z * 0.02 + 40, 3);
    if (a < 0.2 + (n - 0.5) * 0.06 && slope < 1.05) return 'grass';
    const snowLine = 0.5 + (n - 0.5) * 0.12;
    if (a > snowLine) {
      const ice = this.nC.fbm(x * 0.03 + 5, z * 0.03 + 77, 3);
      if (slope > 1.7 && ice > 0.47 && a < 0.93) return 'ice';
      if (slope < 1.1) return 'snow';
      return 'rock';
    }
    const sc = this.nA.fbm(x * 0.03 + 13, z * 0.03 + 8, 3);
    if (slope < 1.25 && sc > 0.56 && a > 0.2) return 'scree';
    return 'rock';
  }

  /** Variação local de aderência: "presas" melhores e piores na parede. */
  gripNoise(x: number, y: number, z: number): number {
    const n1 = this.nC.value((x + z) * 1.4, y * 1.7);
    const n2 = this.nC.value((x - z) * 1.4 + 40, y * 1.7 + 50);
    return 0.5 + 0.85 * ((n1 + n2) * 0.5);
  }

  windExposure(x: number, z: number, y: number): number {
    const a = y / this.def.peak;
    const ridge = smoothstep(0.5, 0.66, this.nA.fbm(x * 0.006 + 300, z * 0.006 + 100, 3));
    return (1 + ridge * 1.1) * (a > 0.25 ? 1 : 0.6);
  }

  biome(y: number, inCave: boolean): string {
    if (inCave) return 'Caverna';
    const a = y / this.def.peak;
    if (a < 0.2) return 'Floresta';
    if (a < 0.45) return 'Penhascos Rochosos';
    if (a < 0.72) return 'Montanha Congelada';
    return 'Zona do Pico';
  }

  /** Cria malha renderizável com cores por vértice. */
  buildMesh(): THREE.Mesh {
    const N = this.N,
      N1 = N + 1;
    const pos = new Float32Array(N1 * N1 * 3);
    const nor = new Float32Array(N1 * N1 * 3);
    const col = new Float32Array(N1 * N1 * 3);
    const uv = new Float32Array(N1 * N1 * 2);
    const H = this.heights;
    const c = new THREE.Color();
    const tmp = new THREE.Color();
    const dark = this.def.id === 'titan' ? 0.62 : this.def.id === 'gelado' ? 0.85 : 1;
    for (let j = 0; j < N1; j++) {
      for (let i = 0; i < N1; i++) {
        const k = j * N1 + i;
        const x = -this.half + i * this.sp;
        const z = -this.half + j * this.sp;
        const h = H[k];
        const hl = H[j * N1 + Math.max(i - 1, 0)];
        const hr = H[j * N1 + Math.min(i + 1, N)];
        const hu = H[Math.max(j - 1, 0) * N1 + i];
        const hd = H[Math.min(j + 1, N) * N1 + i];
        const gx = (hr - hl) / (2 * this.sp);
        const gz = (hd - hu) / (2 * this.sp);
        const l = Math.sqrt(gx * gx + 1 + gz * gz);
        pos[k * 3] = x;
        pos[k * 3 + 1] = h;
        pos[k * 3 + 2] = z;
        nor[k * 3] = -gx / l;
        nor[k * 3 + 1] = 1 / l;
        nor[k * 3 + 2] = -gz / l;
        uv[k * 2] = x * 0.1 + z * 0.07;
        uv[k * 2 + 1] = h * 0.1 + (x - z) * 0.05;
        const slope = Math.hypot(gx, gz);
        const mat = this.materialAt(x, z, h, slope);
        this.colorFor(mat, x, h, z, slope, dark, c, tmp);
        col[k * 3] = c.r;
        col[k * 3 + 1] = c.g;
        col[k * 3 + 2] = c.b;
      }
    }
    const idx = new Uint32Array(N * N * 6);
    let p = 0;
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const a = j * N1 + i,
          b = a + 1,
          cc = a + N1,
          d = cc + 1;
        idx[p++] = a;
        idx[p++] = cc;
        idx[p++] = b;
        idx[p++] = b;
        idx[p++] = cc;
        idx[p++] = d;
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    g.computeBoundingSphere();
    const mat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.96,
      metalness: 0,
      map: this.detailTexture(),
    });
    const mesh = new THREE.Mesh(g, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    return mesh;
  }

  private colorFor(mat: Mat, x: number, h: number, z: number, slope: number, dark: number, out: THREE.Color, tmp: THREE.Color) {
    const n = this.nB.value(x * 0.09, z * 0.09);
    const a = h / this.def.peak;
    switch (mat) {
      case 'sand':
        out.setRGB(0.62, 0.56, 0.4).multiplyScalar(0.85 + n * 0.3);
        break;
      case 'grass':
        out.setRGB(0.17, 0.33, 0.12);
        tmp.setRGB(0.3, 0.42, 0.16);
        out.lerp(tmp, n);
        out.multiplyScalar(1 - slope * 0.25);
        break;
      case 'scree':
        out.setRGB(0.42, 0.4, 0.37).multiplyScalar(0.85 + n * 0.3);
        break;
      case 'snow': {
        out.setRGB(0.93, 0.96, 1.0);
        out.multiplyScalar(0.93 + n * 0.07);
        break;
      }
      case 'ice':
        out.setRGB(0.5, 0.74, 0.88).multiplyScalar(0.9 + n * 0.2);
        break;
      default: {
        const strata = 0.5 + 0.5 * Math.sin(h * 0.45 + this.nA.value(x * 0.02, z * 0.02) * 7);
        out.setRGB(0.27, 0.24, 0.21);
        tmp.setRGB(0.5, 0.45, 0.4);
        out.lerp(tmp, strata * 0.7 + n * 0.3);
        // tom mais quente nas partes baixas
        if (a < 0.3) out.r *= 1.12;
        out.multiplyScalar(dark);
        // poeira de neve acima da linha de neve
        const dust = smoothstep(0.5, 0.75, a) * smoothstep(2.4, 1.2, slope) * 0.75;
        if (dust > 0) {
          tmp.setRGB(0.9, 0.93, 0.97);
          out.lerp(tmp, dust);
        }
      }
    }
  }

  private detailTexture(): THREE.Texture {
    const S = 256;
    const cv = document.createElement('canvas');
    cv.width = cv.height = S;
    const ctx = cv.getContext('2d')!;
    const img = ctx.createImageData(S, S);
    const nz = new Noise(99);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const v = nz.fbmTile((x / S) * 8, (y / S) * 8, 8, 5);
        const g = clamp(0.8 + (v - 0.5) * 1.3, 0.4, 1) * 255;
        const k = (y * S + x) * 4;
        img.data[k] = img.data[k + 1] = img.data[k + 2] = g;
        img.data[k + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const tex = new THREE.CanvasTexture(cv);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  }
}
