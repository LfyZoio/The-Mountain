// Áudio procedural: vento contínuo + efeitos pontuais (sem arquivos externos).
export class GameAudio {
  ctx: AudioContext | null = null;
  private windGain!: GainNode;
  private windFilter!: BiquadFilterNode;
  private master!: GainNode;
  private buf!: AudioBuffer;
  muted = false;

  start() {
    if (this.ctx) {
      void this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AC();
    } catch {
      return;
    }
    const ctx = this.ctx!;
    this.master = ctx.createGain();
    this.master.gain.value = 0.6;
    this.master.connect(ctx.destination);
    const len = ctx.sampleRate * 3;
    this.buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      last = last * 0.96 + (Math.random() * 2 - 1) * 0.04;
      d[i] = last * 6;
    }
    const src = ctx.createBufferSource();
    src.buffer = this.buf;
    src.loop = true;
    this.windFilter = ctx.createBiquadFilter();
    this.windFilter.type = 'bandpass';
    this.windFilter.frequency.value = 400;
    this.windFilter.Q.value = 0.6;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0;
    src.connect(this.windFilter).connect(this.windGain).connect(this.master);
    src.start();
  }

  setWind(speed: number, muffle: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const k = Math.min(1, speed / 40);
    this.windGain.gain.setTargetAtTime((0.04 + 0.5 * k) * muffle, t, 0.3);
    this.windFilter.frequency.setTargetAtTime((250 + 900 * k) * (0.4 + 0.6 * muffle), t, 0.3);
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.6;
  }

  blip(freq: number, dur: number, type: OscillatorType = 'sine', vol = 0.2, slide = 0) {
    if (!this.ctx || this.muted) return;
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), ctx.currentTime + dur);
    g.gain.value = vol;
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g).connect(this.master);
    o.start();
    o.stop(ctx.currentTime + dur);
  }

  grab() {
    this.blip(180, 0.08, 'triangle', 0.15, -60);
  }
  slip() {
    this.blip(700, 0.25, 'sawtooth', 0.08, -500);
  }
  thud(power: number) {
    this.blip(90, 0.3, 'sine', Math.min(0.6, 0.15 + power * 0.02), -60);
  }
  piton() {
    this.blip(1500, 0.12, 'square', 0.07, -400);
    setTimeout(() => this.blip(1800, 0.1, 'square', 0.06, -500), 120);
  }
  chime() {
    this.blip(660, 0.25, 'sine', 0.15);
    setTimeout(() => this.blip(880, 0.35, 'sine', 0.15), 140);
    setTimeout(() => this.blip(1320, 0.5, 'sine', 0.12), 300);
  }
  rumble() {
    this.blip(55, 1.2, 'sawtooth', 0.12, -20);
  }
}
