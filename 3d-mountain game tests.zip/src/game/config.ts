// Configuração central: montanhas, equipamentos e conquistas.

export interface MountainDef {
  id: string;
  name: string;
  subtitle: string;
  desc: string;
  seed: number;
  peak: number; // altura real em unidades de mundo (m)
  radius: number; // raio da base
  half: number; // meio-tamanho da malha
  baseM: number; // altitude exibida ao nível do mar da ilha
  summitM: number; // altitude exibida do cume
  severity: number; // intensidade do clima
  parTime: number; // tempo de referência (s)
  requires?: string; // id da montanha que precisa ser conquistada
  difficulty: number; // 1..5
  theta0: number;
}

export const MOUNTAINS: MountainDef[] = [
  {
    id: 'aurora',
    name: 'Monte Aurora',
    subtitle: 'A escalada de iniciação',
    desc: 'Florestas de pinheiros, paredões de granito e um pico gelado de 3.800 m. Ideal para aprender a dominar corda, aderência e equilíbrio.',
    seed: 11,
    peak: 330,
    radius: 520,
    half: 650,
    baseM: 300,
    summitM: 3800,
    severity: 0.65,
    parTime: 1500,
    difficulty: 2,
    theta0: 1.2,
  },
  {
    id: 'gelado',
    name: 'Pico Gelado',
    subtitle: 'Muralhas de gelo e tempestades',
    desc: 'Uma muralha congelada com ventos cortantes e cavernas de cristal. Exige piolet, crampons e gestão rigorosa do frio.',
    seed: 27,
    peak: 430,
    radius: 600,
    half: 750,
    baseM: 400,
    summitM: 5100,
    severity: 0.95,
    parTime: 2100,
    requires: 'aurora',
    difficulty: 4,
    theta0: 3.4,
  },
  {
    id: 'titan',
    name: 'Titã Negro',
    subtitle: 'O gigante das tempestades',
    desc: 'A montanha mais alta do arquipélago: 6.900 m de rocha negra, ar rarefeito e nevascas sem fim. Apenas para lendas.',
    seed: 83,
    peak: 560,
    radius: 700,
    half: 850,
    baseM: 500,
    summitM: 6900,
    severity: 1.25,
    parTime: 2900,
    requires: 'gelado',
    difficulty: 5,
    theta0: 5.1,
  },
];

export type EquipId = 'rope' | 'chalk' | 'food' | 'tea' | 'lamp' | 'axe' | 'jacket' | 'crampons' | 'oxygen';

export interface EquipDef {
  id: EquipId;
  name: string;
  icon: string;
  key: string; // tecla para uso ('' = passivo)
  level: number;
  desc: string;
}

export const EQUIPMENT: EquipDef[] = [
  { id: 'rope', name: 'Corda & Pitons', icon: '🪢', key: 'R', level: 1, desc: 'Fixa pitons na rocha. A corda segura quedas até o comprimento já percorrido acima do último piton.' },
  { id: 'chalk', name: 'Magnésio', icon: '🤍', key: 'C', level: 1, desc: 'Melhora a aderência das mãos por 90 s.' },
  { id: 'food', name: 'Ração Energética', icon: '🍫', key: 'F', level: 1, desc: 'Restaura energia e um pouco de fôlego.' },
  { id: 'tea', name: 'Chá Térmico', icon: '🍵', key: 'T', level: 1, desc: 'Aquece o corpo rapidamente.' },
  { id: 'lamp', name: 'Lanterna de Capacete', icon: '🔦', key: 'L', level: 2, desc: 'Ilumina cavernas e nevascas.' },
  { id: 'axe', name: 'Piolet', icon: '🪓', key: '', level: 2, desc: 'Passivo: grande aderência em gelo e neve.' },
  { id: 'jacket', name: 'Jaqueta Térmica', icon: '🧥', key: '', level: 3, desc: 'Passivo: reduz muito a perda de calor.' },
  { id: 'crampons', name: 'Crampons', icon: '👢', key: '', level: 4, desc: 'Passivo: pés firmes no gelo e inclinações maiores caminháveis.' },
  { id: 'oxygen', name: 'Cilindro de Oxigênio', icon: '🫁', key: 'O', level: 5, desc: 'Compensa o ar rarefeito em grandes altitudes.' },
];

export interface AchDef {
  id: string;
  name: string;
  desc: string;
  xp: number;
  icon: string;
}

export const ACHIEVEMENTS: AchDef[] = [
  { id: 'first_steps', name: 'Primeiros Passos', desc: 'Deixe o acampamento base.', xp: 30, icon: '👣' },
  { id: 'first_climb', name: 'Mãos na Rocha', desc: 'Inicie sua primeira escalada livre.', xp: 40, icon: '🧗' },
  { id: 'first_piton', name: 'Cordada', desc: 'Fixe seu primeiro piton.', xp: 40, icon: '🪢' },
  { id: 'rope_save', name: 'Salvo pela Corda', desc: 'Seja segurado pela corda em uma queda.', xp: 100, icon: '🛟' },
  { id: 'big_fall', name: 'Queda Livre', desc: 'Sobreviva a uma queda de mais de 25 m.', xp: 120, icon: '🪂' },
  { id: 'camp3', name: 'Rota Aberta', desc: 'Ative 3 acampamentos em uma escalada.', xp: 80, icon: '⛺' },
  { id: 'cave', name: 'Espeleólogo', desc: 'Entre em uma caverna.', xp: 60, icon: '🕳️' },
  { id: 'ice_master', name: 'Mestre do Gelo', desc: 'Escale 30 m em paredes de gelo.', xp: 150, icon: '🧊' },
  { id: 'blizzard', name: 'Olho da Tempestade', desc: 'Enfrente uma nevasca acima de 1.500 m.', xp: 120, icon: '🌨️' },
  { id: 'above_clouds', name: 'Acima das Nuvens', desc: 'Passe de 60% da altura da montanha.', xp: 100, icon: '☁️' },
  { id: 'cold_survivor', name: 'Sangue Frio', desc: 'Recupere-se de uma hipotermia (< 34,5 °C).', xp: 100, icon: '🥶' },
  { id: 'summit', name: 'Cume Conquistado', desc: 'Alcance o topo de uma montanha.', xp: 400, icon: '🏔️' },
  { id: 'free_solo', name: 'Purista', desc: 'Conquiste um cume sem fixar nenhum piton.', xp: 300, icon: '🦅' },
  { id: 'speed', name: 'Recorde de Velocidade', desc: 'Conquiste um cume abaixo do tempo de referência.', xp: 300, icon: '⏱️' },
  { id: 'marathon', name: 'Maratonista Vertical', desc: 'Acumule 5.000 m de ganho de altitude.', xp: 200, icon: '📈' },
  { id: 'veteran', name: 'Veterano', desc: 'Alcance o nível 5.', xp: 150, icon: '⭐' },
  { id: 'three_peaks', name: 'Três Gigantes', desc: 'Conquiste as três montanhas.', xp: 800, icon: '👑' },
];

export const xpForLevel = (lvl: number) => 75 * (lvl - 1) * lvl; // XP total para atingir o nível

export const WORLD = {
  gravity: 24,
  walkSlope: 1.25,
  waterY: 0,
};
