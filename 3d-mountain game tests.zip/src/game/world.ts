import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Terrain } from './terrain';
import { Layout, Camp, Cave } from './layout';
import { Noise, mulberry32, smoothstep, clamp } from './noise';

export interface LightSource {
  pos: THREE.Vector3;
  color: number;
  intensity: number;
  dist: number;
}

function paint(g: THREE.BufferGeometry, r: number, gg: number, b: number) {
  const n = g.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = r;
    arr[i * 3 + 1] = gg;
    arr[i * 3 + 2] = b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}

// ---------- Céu ----------
export class SkyDome {
  mesh: THREE.Mesh;
  mat: THREE.ShaderMaterial;
  constructor() {
    this.mat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uTop: { value: new THREE.Color(0x2a62b8) },
        uHorizon: { value: new THREE.Color(0xa9c8e6) },
        uSunDir: { value: new THREE.Vector3(0.5, 0.6, 0.3).normalize() },
        uSunColor: { value: new THREE.Color(1, 0.9, 0.7) },
        uGlow: { value: 1 },
      },
      vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
      fragmentShader: `
        uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunDir; uniform vec3 uSunColor; uniform float uGlow;
        varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = clamp(d.y, 0.0, 1.0);
          vec3 col = mix(uHorizon, uTop, pow(h, 0.45));
          if (d.y < 0.0) col = mix(uHorizon, uHorizon*0.85, clamp(-d.y*5.0, 0.0, 1.0));
          float s = max(dot(d, uSunDir), 0.0);
          col += uSunColor * (pow(s, 900.0) * 3.0 + pow(s, 10.0) * 0.28 * uGlow);
          gl_FragColor = vec4(col, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    });
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(4000, 32, 16), this.mat);
    this.mesh.renderOrder = -10;
    this.mesh.frustumCulled = false;
  }
}

// ---------- Nuvens ----------
function cloudTexture(): THREE.Texture {
  const S = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const ctx = cv.getContext('2d')!;
  const rnd = mulberry32(5);
  ctx.clearRect(0, 0, S, S);
  for (let i = 0; i < 34; i++) {
    const a = rnd() * Math.PI * 2;
    const d = rnd() * S * 0.26;
    const x = S / 2 + Math.cos(a) * d * 1.3;
    const y = S / 2 + Math.sin(a) * d * 0.6;
    const r = S * (0.1 + rnd() * 0.17);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, 'rgba(255,255,255,0.34)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, S, S);
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class Clouds {
  group = new THREE.Group();
  sprites: { s: THREE.Sprite; speed: number; base: number }[] = [];
  constructor(def: { peak: number; radius: number }, seed: number) {
    const tex = cloudTexture();
    const rnd = mulberry32(seed + 1000);
    const make = (x: number, y: number, z: number, w: number, h: number, base: number) => {
      const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: base, color: 0xffffff });
      const s = new THREE.Sprite(mat);
      s.position.set(x, y, z);
      s.scale.set(w, h, 1);
      this.group.add(s);
      this.sprites.push({ s, speed: 1 + rnd() * 2.5, base });
    };
    for (let i = 0; i < 70; i++) {
      const a = rnd() * Math.PI * 2;
      const r = def.radius * (0.5 + rnd() * 1.7);
      make(Math.cos(a) * r, def.peak * (0.1 + rnd() * 1.3), Math.sin(a) * r, 220 + rnd() * 380, 80 + rnd() * 120, 0.5 + rnd() * 0.4);
    }
    // mar de nuvens
    for (let i = 0; i < 50; i++) {
      const a = rnd() * Math.PI * 2;
      const r = def.radius * (0.45 + rnd() * 1.4);
      make(Math.cos(a) * r, def.peak * (0.3 + rnd() * 0.06), Math.sin(a) * r, 380 + rnd() * 420, 90 + rnd() * 60, 0.75);
    }
  }
  update(dt: number, wind: THREE.Vector3, cover: number, tint: THREE.Color, half: number) {
    for (const c of this.sprites) {
      c.s.position.x += wind.x * 0.1 * c.speed * dt;
      c.s.position.z += wind.z * 0.1 * c.speed * dt;
      if (c.s.position.x > half * 2) c.s.position.x -= half * 4;
      if (c.s.position.x < -half * 2) c.s.position.x += half * 4;
      if (c.s.position.z > half * 2) c.s.position.z -= half * 4;
      if (c.s.position.z < -half * 2) c.s.position.z += half * 4;
      const m = c.s.material as THREE.SpriteMaterial;
      m.opacity = c.base * (0.45 + 0.55 * cover);
      m.color.copy(tint);
    }
  }
}

// ---------- Colisões circulares (árvores, pedras) ----------
export class Colliders {
  cell = 12;
  map = new Map<number, number[]>();
  list: { x: number; z: number; r: number; h: number }[] = [];
  private key(i: number, j: number) {
    return i * 73856093 ^ j * 19349663;
  }
  add(x: number, z: number, r: number, h: number) {
    const idx = this.list.length;
    this.list.push({ x, z, r, h });
    const k = this.key(Math.floor(x / this.cell), Math.floor(z / this.cell));
    const arr = this.map.get(k);
    if (arr) arr.push(idx);
    else this.map.set(k, [idx]);
  }
  /** Empurra posição para fora de colisores; retorna true se houve contato. */
  resolve(p: THREE.Vector3, feetY: number, terrain: Terrain, pr = 0.4): boolean {
    let hit = false;
    const ci = Math.floor(p.x / this.cell),
      cj = Math.floor(p.z / this.cell);
    for (let i = ci - 1; i <= ci + 1; i++) {
      for (let j = cj - 1; j <= cj + 1; j++) {
        const arr = this.map.get(this.key(i, j));
        if (!arr) continue;
        for (const idx of arr) {
          const c = this.list[idx];
          const dx = p.x - c.x,
            dz = p.z - c.z;
          const rr = c.r + pr;
          const d2 = dx * dx + dz * dz;
          if (d2 < rr * rr) {
            const base = terrain.heightAt(c.x, c.z);
            if (feetY > base + c.h) continue;
            const d = Math.sqrt(d2) || 0.001;
            p.x = c.x + (dx / d) * rr;
            p.z = c.z + (dz / d) * rr;
            hit = true;
          }
        }
      }
    }
    return hit;
  }
}

// ---------- Mundo ----------
export class World {
  group = new THREE.Group();
  colliders = new Colliders();
  lightSources: LightSource[] = [];
  campVisuals: { ring: THREE.Mesh; flame: THREE.Mesh; flag: THREE.Mesh; camp: Camp; beam: THREE.Mesh }[] = [];
  summitFlag!: THREE.Group;
  summitBeam!: THREE.Mesh;
  water: THREE.Mesh;
  crystals: THREE.Mesh[] = [];
  private noise: Noise;
  private clock = 0;

  constructor(
    private terrain: Terrain,
    private layout: Layout,
  ) {
    this.noise = new Noise(terrain.def.seed + 500);
    this.water = this.makeWater();
    this.group.add(this.water);
    this.makeTrees();
    this.makeRocks();
    for (const c of layout.camps) this.makeCamp(c);
    for (const cv of layout.caves) this.makeCave(cv);
    this.makeSummit();
  }

  private nearMod(x: number, z: number, scale = 0.8) {
    for (const m of this.terrain.mods) {
      if (Math.hypot(x - m.x, z - m.z) < m.flat + m.blend * scale) return true;
    }
    return false;
  }

  private makeWater() {
    const g = new THREE.PlaneGeometry(9000, 9000);
    g.rotateX(-Math.PI / 2);
    const m = new THREE.MeshStandardMaterial({
      color: 0x1d5a78,
      roughness: 0.12,
      metalness: 0.15,
      transparent: true,
      opacity: 0.88,
    });
    const mesh = new THREE.Mesh(g, m);
    mesh.position.y = 0;
    mesh.receiveShadow = true;
    return mesh;
  }

  private makeTrees() {
    const t = this.terrain;
    const parts = [
      paint(new THREE.CylinderGeometry(0.18, 0.3, 2.4, 6).translate(0, 1.2, 0), 0.3, 0.2, 0.12),
      paint(new THREE.ConeGeometry(2.2, 3.6, 7).translate(0, 3.2, 0), 0.1, 0.27, 0.12),
      paint(new THREE.ConeGeometry(1.7, 3.2, 7).translate(0, 4.9, 0), 0.12, 0.31, 0.13),
      paint(new THREE.ConeGeometry(1.2, 2.8, 7).translate(0, 6.4, 0), 0.15, 0.35, 0.15),
    ];
    const geo = mergeGeometries(parts)!;
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9 });
    const MAX = 4200;
    const mesh = new THREE.InstancedMesh(geo, mat, MAX);
    const rnd = mulberry32(t.def.seed * 3);
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const col = new THREE.Color();
    let n = 0;
    for (let k = 0; k < 26000 && n < MAX; k++) {
      const a = rnd() * Math.PI * 2;
      const r = Math.sqrt(rnd()) * t.def.radius * 1.05;
      const x = Math.cos(a) * r,
        z = Math.sin(a) * r;
      const h = t.heightAt(x, z);
      const al = h / t.def.peak;
      const slope = Math.hypot(t.gx, t.gz);
      if (h < 2.5 || al > 0.27 || slope > 0.8) continue;
      const dens = this.noise.fbm(x * 0.012, z * 0.012, 3);
      if (dens < 0.42 || rnd() > 1 - smoothstep(0.1, 0.27, al)) continue;
      if (this.nearMod(x, z, 1)) continue;
      const s = 0.9 + rnd() * 0.9;
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * 6.28);
      m4.compose(new THREE.Vector3(x, h - 0.2, z), q, new THREE.Vector3(s, s * (0.9 + rnd() * 0.3), s));
      mesh.setMatrixAt(n, m4);
      const snow = smoothstep(0.12, 0.27, al);
      col.setRGB(0.8 + rnd() * 0.4, 0.85 + rnd() * 0.3, 0.8 + rnd() * 0.3).lerp(new THREE.Color(1.6, 1.7, 1.8), snow * 0.6);
      mesh.setColorAt(n, col);
      this.colliders.add(x, z, 0.35 * s, 12);
      n++;
    }
    mesh.count = n;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    this.group.add(mesh);
  }

  private makeRocks() {
    const t = this.terrain;
    const geo = new THREE.IcosahedronGeometry(1, 1);
    const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i),
        y = p.getY(i),
        z = p.getZ(i);
      const k = 0.7 + 0.55 * this.noise.value(x * 1.7 + 10, y * 1.7 + z * 2.1);
      p.setXYZ(i, x * k, y * k * 0.8, z * k);
    }
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ roughness: 0.95, flatShading: true });
    const MAX = 1800;
    const mesh = new THREE.InstancedMesh(geo, mat, MAX);
    const rnd = mulberry32(t.def.seed * 5);
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const col = new THREE.Color();
    let n = 0;
    for (let k = 0; k < 14000 && n < MAX; k++) {
      const a = rnd() * Math.PI * 2;
      const r = Math.sqrt(rnd()) * t.def.radius * 1.0;
      const x = Math.cos(a) * r,
        z = Math.sin(a) * r;
      const h = t.heightAt(x, z);
      const slope = Math.hypot(t.gx, t.gz);
      const al = h / t.def.peak;
      if (h < 1.5 || al > 0.95) continue;
      const prob = slope > 0.55 ? 0.7 : 0.1;
      if (rnd() > prob) continue;
      if (this.nearMod(x, z, 1)) continue;
      const s = 0.5 + Math.pow(rnd(), 3) * 4.2;
      e.set(rnd() * 6, rnd() * 6, rnd() * 6);
      q.setFromEuler(e);
      m4.compose(new THREE.Vector3(x, h + s * 0.15, z), q, new THREE.Vector3(s * 1.2, s, s * 1.2));
      mesh.setMatrixAt(n, m4);
      const sn = smoothstep(0.5, 0.8, al) * 0.7;
      const b = 0.3 + rnd() * 0.25;
      col.setRGB(b * 1.05, b, b * 0.92).lerp(new THREE.Color(0.9, 0.93, 0.97), sn);
      mesh.setColorAt(n, col);
      if (s > 1.6) this.colliders.add(x, z, s * 0.95, s * 0.9);
      n++;
    }
    mesh.count = n;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    this.group.add(mesh);
  }

  private makeCamp(c: Camp) {
    const g = new THREE.Group();
    g.position.copy(c.pos);
    const flameMat = new THREE.MeshBasicMaterial({ color: 0xff8a2a });
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.1, 6).translate(0, 0.55, 0), flameMat);
    flame.position.set(-1.8, 0.25, 1.2);
    g.add(flame);
    for (let i = 0; i < 4; i++) {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.0, 5), new THREE.MeshStandardMaterial({ color: 0x3a2514 }));
      log.rotation.z = Math.PI / 2;
      log.rotation.y = (i / 4) * Math.PI;
      log.position.set(-1.8, 0.1, 1.2);
      g.add(log);
    }
    if (!c.isCave) {
      const tent = new THREE.Mesh(
        new THREE.ConeGeometry(2.4, 2.0, 4).translate(0, 1.0, 0),
        new THREE.MeshStandardMaterial({ color: 0xe0612a, roughness: 0.8 }),
      );
      tent.rotation.y = Math.PI / 4;
      tent.position.set(2.2, 0, -1.2);
      tent.castShadow = true;
      g.add(tent);
      this.colliders.add(c.pos.x + 2.2, c.pos.z - 1.2, 1.8, 2);
    }
    const poleH = 6;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, poleH, 6).translate(0, poleH / 2, 0), new THREE.MeshStandardMaterial({ color: 0xdddddd }));
    pole.position.set(0.8, 0, 2.4);
    pole.castShadow = true;
    g.add(pole);
    const flag = new THREE.Mesh(
      new THREE.PlaneGeometry(1.7, 1.0).translate(0.85, 0, 0),
      new THREE.MeshStandardMaterial({ color: 0xff3b30, side: THREE.DoubleSide, emissive: 0x330000 }),
    );
    flag.position.set(0.85, poleH - 0.7, 2.4);
    g.add(flag);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(3.2, 0.07, 6, 48).rotateX(Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.55 }),
    );
    ring.position.y = 0.15;
    g.add(ring);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.5, 70, 10, 1, true).translate(0, 35, 0),
      new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
    );
    g.add(beam);
    this.group.add(g);
    this.campVisuals.push({ ring, flame, flag, camp: c, beam });
    this.lightSources.push({
      pos: new THREE.Vector3(c.pos.x - 1.8, c.pos.y + 1.4, c.pos.z + 1.2),
      color: 0xff9a4a,
      intensity: 55,
      dist: 28,
    });
  }

  private makeCave(cv: Cave) {
    const rnd = mulberry32(cv.campIndex * 77 + 3);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x4a4540, roughness: 0.97, flatShading: true, side: THREE.DoubleSide });
    const phiStart = cv.gapAngle + Math.PI + cv.gap / 2; // sphere phi: dir = (-cos phi, sin phi)
    // phi correspondente à direção (dx,dz)=(cos a, sin a): phi = atan2(dz, -dx) = PI - a
    const phiE = Math.PI - cv.gapAngle;
    const dome = new THREE.SphereGeometry(cv.R, 28, 12, phiE + cv.gap / 2, Math.PI * 2 - cv.gap, 0, Math.PI / 2);
    void phiStart;
    const dp = dome.attributes.position;
    for (let i = 0; i < dp.count; i++) {
      const x = dp.getX(i),
        y = dp.getY(i),
        z = dp.getZ(i);
      const k = 1 + (this.noise.value(x * 0.35 + 5, z * 0.35 + y * 0.3) - 0.5) * 0.25;
      dp.setXYZ(i, x * k, y * (cv.H / cv.R) * k, z * k);
    }
    dome.computeVertexNormals();
    const d = new THREE.Mesh(dome, rockMat);
    d.position.copy(cv.center);
    d.castShadow = true;
    d.receiveShadow = true;
    this.group.add(d);
    // saia
    const thetaE = Math.atan2(Math.cos(cv.gapAngle), Math.sin(cv.gapAngle)); // cylinder: x = r sin t, z = r cos t
    const skirt = new THREE.CylinderGeometry(cv.R, cv.R * 1.02, 16, 28, 4, true, thetaE + cv.gap / 2, Math.PI * 2 - cv.gap);
    const sp = skirt.attributes.position;
    for (let i = 0; i < sp.count; i++) {
      const x = sp.getX(i),
        y = sp.getY(i),
        z = sp.getZ(i);
      const k = 1 + (this.noise.value(x * 0.3 + 9, z * 0.3 + y * 0.4) - 0.5) * 0.2;
      sp.setXYZ(i, x * k, y, z * k);
    }
    skirt.computeVertexNormals();
    const sk = new THREE.Mesh(skirt, rockMat);
    sk.position.set(cv.center.x, cv.center.y - 8 + 0.3, cv.center.z);
    sk.castShadow = true;
    sk.receiveShadow = true;
    this.group.add(sk);
    // estalactites
    const stalMat = new THREE.MeshStandardMaterial({ color: 0x6a645c, roughness: 0.9, flatShading: true });
    for (let i = 0; i < 16; i++) {
      const a = rnd() * 6.28;
      const r = rnd() * cv.R * 0.78;
      const ceil = cv.H * Math.sqrt(Math.max(0.05, 1 - (r / cv.R) ** 2));
      const len = 0.8 + rnd() * 1.8;
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.28 + rnd() * 0.25, len, 5).rotateX(Math.PI), stalMat);
      s.position.set(cv.center.x + Math.cos(a) * r, cv.center.y + ceil - len / 2 - 0.2, cv.center.z + Math.sin(a) * r);
      this.group.add(s);
    }
    // cristais
    const cMat = new THREE.MeshStandardMaterial({ color: 0x66e0ff, emissive: 0x2aa8d8, emissiveIntensity: 2.2, roughness: 0.2, flatShading: true });
    for (let i = 0; i < 14; i++) {
      const a = rnd() * 6.28;
      const r = cv.R * (0.55 + rnd() * 0.3);
      const ang = Math.atan2(Math.sin(a), Math.cos(a));
      const diff = Math.abs(Math.atan2(Math.sin(ang - cv.gapAngle), Math.cos(ang - cv.gapAngle)));
      if (diff < cv.gap) continue;
      const h = 0.7 + rnd() * 1.6;
      const cr = new THREE.Mesh(new THREE.OctahedronGeometry(0.35, 0).scale(1, h * 1.8, 1), cMat);
      cr.position.set(cv.center.x + Math.cos(a) * r, cv.center.y + h * 0.4, cv.center.z + Math.sin(a) * r);
      cr.rotation.set((rnd() - 0.5) * 0.5, rnd() * 6, (rnd() - 0.5) * 0.5);
      this.group.add(cr);
      this.crystals.push(cr);
    }
    this.lightSources.push({ pos: new THREE.Vector3(cv.center.x, cv.center.y + 3.2, cv.center.z), color: 0x55ccff, intensity: 25, dist: 18 });
  }

  private makeSummit() {
    const s = this.layout.summit;
    const g = new THREE.Group();
    g.position.copy(s);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 9, 6).translate(0, 4.5, 0), new THREE.MeshStandardMaterial({ color: 0xeeeeee, metalness: 0.5, roughness: 0.4 }));
    pole.castShadow = true;
    g.add(pole);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(3, 1.8).translate(1.5, 0, 0), new THREE.MeshStandardMaterial({ color: 0xffc22e, emissive: 0x553300, side: THREE.DoubleSide }));
    flag.position.y = 8;
    g.add(flag);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.9, 0.9, 400, 12, 1, true).translate(0, 200, 0),
      new THREE.MeshBasicMaterial({ color: 0xffd36b, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }),
    );
    g.add(beam);
    this.summitFlag = g;
    this.summitBeam = beam;
    this.group.add(g);
  }

  setCampActive(index: number, active: boolean) {
    const v = this.campVisuals.find((c) => c.camp.index === index);
    if (!v) return;
    (v.ring.material as THREE.MeshBasicMaterial).color.set(active ? 0x6dff8a : 0x66ccff);
    (v.beam.material as THREE.MeshBasicMaterial).color.set(active ? 0x6dff8a : 0x66ccff);
  }

  update(dt: number) {
    this.clock += dt;
    for (const v of this.campVisuals) {
      v.flame.scale.set(1 + Math.sin(this.clock * 13 + v.camp.index) * 0.12, 1 + Math.sin(this.clock * 17 + v.camp.index * 2) * 0.25, 1);
      v.flag.rotation.y = Math.sin(this.clock * 2.2 + v.camp.index) * 0.35;
    }
    this.summitFlag.children[1].rotation.y = Math.sin(this.clock * 2.5) * 0.3;
    for (let i = 0; i < this.crystals.length; i++) {
      const m = this.crystals[i].material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = 2 + Math.sin(this.clock * 1.5) * 0.4;
    }
  }

  // ---------- Cavernas: colisão e detecção ----------
  caveAt(p: THREE.Vector3): Cave | null {
    for (const c of this.layout.caves) {
      const dx = p.x - c.center.x,
        dz = p.z - c.center.z;
      const d = Math.hypot(dx, dz);
      if (d < c.R - 1.2 && p.y > c.center.y - 2 && p.y < c.center.y + c.H) return c;
    }
    return null;
  }

  /** Mantém o jogador fora da casca da caverna, exceto pela entrada; limita o teto. */
  resolveCaves(p: THREE.Vector3, vel: THREE.Vector3) {
    for (const c of this.layout.caves) {
      const dx = p.x - c.center.x,
        dz = p.z - c.center.z;
      const d = Math.hypot(dx, dz);
      if (d > c.R + 3 || p.y > c.center.y + c.H + 3 || p.y < c.center.y - 18) continue;
      const ang = Math.atan2(dz, dx);
      const diff = Math.abs(Math.atan2(Math.sin(ang - c.gapAngle), Math.cos(ang - c.gapAngle)));
      const inGap = diff < c.gap / 2 + 0.12;
      if (!inGap && d > c.R - 1.4 && d < c.R + 1.0) {
        const inside = d < c.R - 0.2;
        const nd = inside ? c.R - 1.4 : c.R + 1.0;
        p.x = c.center.x + (dx / (d || 1)) * nd;
        p.z = c.center.z + (dz / (d || 1)) * nd;
        const nx = dx / (d || 1),
          nz = dz / (d || 1);
        const vn = vel.x * nx + vel.z * nz;
        if (vn * (inside ? 1 : -1) > 0) {
          vel.x -= nx * vn;
          vel.z -= nz * vn;
        }
      }
      if (d < c.R - 1.2) {
        const ceil = c.center.y + c.H * Math.sqrt(Math.max(0.02, 1 - (d / c.R) ** 2)) - 1.0;
        if (p.y > ceil) {
          p.y = ceil;
          if (vel.y > 0) vel.y = 0;
        }
      }
    }
  }

  dispose() {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
  }
}

export { clamp };
