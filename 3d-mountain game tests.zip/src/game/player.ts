import * as THREE from 'three';
import { Terrain, SurfaceInfo, Mat, MAT_GRIP } from './terrain';
import { World } from './world';
import { Survival } from './survival';
import { Input } from './input';
import { WORLD } from './config';
import { clamp, smoothstep } from './noise';

export type PState = 'ground' | 'air' | 'climb' | 'dead';

export interface Hand {
  gripped: boolean;
  reaching: boolean;
  pos: THREE.Vector3;
  cand: THREE.Vector3;
  candQ: number;
  candMat: Mat;
  quality: number;
  slip: number;
  fatigue: number;
  mat: Mat;
  crumble: number;
  held: boolean;
  cd: number;
}

export interface PlayerCtx {
  camForward: THREE.Vector3;
  camRight: THREE.Vector3;
  wind: THREE.Vector3;
  windSpeed: number;
  wet: number;
  axe: boolean;
  crampons: boolean;
  rope: boolean;
}

const UP = new THREE.Vector3(0, 1, 0);
const mkHand = (): Hand => ({
  gripped: false,
  reaching: false,
  pos: new THREE.Vector3(),
  cand: new THREE.Vector3(),
  candQ: 0,
  candMat: 'rock',
  quality: 0,
  slip: 0,
  fatigue: 0,
  mat: 'rock',
  crumble: 0,
  held: false,
  cd: 0,
});

const SAMPLES: [number, number][] = [[0, 0]];
for (const rho of [0.16, 0.3]) for (let k = 0; k < 8; k++) SAMPLES.push([Math.cos((k * Math.PI) / 4) * rho, Math.sin((k * Math.PI) / 4) * rho]);

export class Player {
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  state: PState = 'ground';
  face = new THREE.Vector3(0, 0, -1);
  n = new THREE.Vector3(0, 1, 0);
  u = new THREE.Vector3(0, 1, 0);
  r = new THREE.Vector3(1, 0, 0);
  f = new THREE.Vector3(0, 0, -1);
  hands: [Hand, Hand] = [mkHand(), mkHand()];
  balance = 0;
  balV = 0;
  braced = false;
  anchors: THREE.Vector3[] = [];
  ropeOut = 0;
  ropeCaught = false;
  surf: SurfaceInfo = { h: 0, nx: 0, ny: 1, nz: 0, slope: 0, mat: 'grass' };
  walkPhase = 0;
  speedNorm = 0;
  wallTimer = 0;
  airTime = 0;
  fallStartY = 0;
  catchCd = 0;
  effort = 0;
  resting = true;
  sprinting = false;
  moving = false;
  prompt = '';
  inWater = false;
  distWalked = 0;
  climbSpeedY = 0;
  inCave = false;
  crouching = false;
  walkMode = false;
  ctx: PlayerCtx;

  private tc = new THREE.Vector3();
  private tq = new THREE.Vector3();
  private t1 = new THREE.Vector3();
  private t2 = new THREE.Vector3();
  private hold = { p: new THREE.Vector3(), q: 0, mat: 'rock' as Mat };
  private go = { q: 0, mat: 'rock' as Mat };
  private noiseT = Math.random() * 100;
  private failMsgCd = 0;
  private lastPosY = 0;

  constructor(
    private terrain: Terrain,
    private world: World,
    private surv: Survival,
    private input: Input,
    private emit: (type: string, data?: any) => void,
  ) {
    this.ctx = {
      camForward: new THREE.Vector3(0, 0, -1),
      camRight: new THREE.Vector3(1, 0, 0),
      wind: new THREE.Vector3(),
      windSpeed: 0,
      wet: 0,
      axe: false,
      crampons: false,
      rope: true,
    };
  }

  // ---------------- utilidades de superfície ----------------
  get walkLimit() {
    const m = this.surf.mat;
    return WORLD.walkSlope + (this.ctx.crampons && (m === 'snow' || m === 'ice') ? 0.25 : 0) - (m === 'ice' && !this.ctx.crampons ? 0.2 : 0);
  }

  projectToSurface(p: THREE.Vector3, offset: number, out: THREE.Vector3) {
    out.copy(p);
    for (let i = 0; i < 3; i++) {
      const h = this.terrain.heightAt(out.x, out.z);
      const gx = this.terrain.gx,
        gz = this.terrain.gz;
      const l = Math.sqrt(gx * gx + 1 + gz * gz);
      const nx = -gx / l,
        ny = 1 / l,
        nz = -gz / l;
      const d = (out.y - h) * ny;
      const delta = offset - d;
      out.x += nx * delta;
      out.y += ny * delta;
      out.z += nz * delta;
    }
    return out;
  }

  private gripMul(mat: Mat) {
    let m = 1;
    if ((mat === 'ice' || mat === 'snow') && this.ctx.axe) m *= mat === 'ice' ? 2.1 : 1.5;
    if (this.surv.chalkTimer > 0) m *= 1.2;
    m *= 1 - 0.28 * this.ctx.wet * (mat === 'rock' ? 1 : 0.5);
    if (this.surv.temp < 35.5) m *= Math.max(0.5, 1 - (35.5 - this.surv.temp) * 0.12);
    return m;
  }

  gripAt(x: number, z: number) {
    const t = this.terrain;
    const h = t.heightAt(x, z);
    const s = Math.hypot(t.gx, t.gz);
    const mat = t.materialAt(x, z, h, s);
    const q = MAT_GRIP[mat] * t.gripNoise(x, h, z) * this.gripMul(mat);
    this.go.q = Math.min(1.2, q);
    this.go.mat = mat;
    return this.go;
  }

  private updateFrame() {
    this.projectToSurface(this.pos, 0, this.tc);
    this.terrain.surface(this.tc.x, this.tc.z, this.surf);
    this.n.set(this.surf.nx, this.surf.ny, this.surf.nz);
    this.f.copy(this.n).negate();
    this.r.crossVectors(this.f, UP);
    if (this.r.lengthSq() < 1e-4) this.r.set(1, 0, 0);
    this.r.normalize();
    this.u.crossVectors(this.r, this.f).normalize();
  }

  private bestHold(center: THREE.Vector3, aimR = 0, aimU = 0) {
    let best = -1e9;
    for (const [a, b] of SAMPLES) {
      this.tq.copy(center).addScaledVector(this.r, a).addScaledVector(this.u, b);
      this.projectToSurface(this.tq, 0.05, this.tq);
      const g = this.gripAt(this.tq.x, this.tq.z);
      const score = g.q - 0.4 * Math.hypot(a, b) + 0.5 * (a * aimR + b * aimU);
      if (score > best) {
        best = score;
        this.hold.p.copy(this.tq);
        this.hold.q = g.q;
        this.hold.mat = g.mat;
      }
    }
    return this.hold;
  }

  private shoulder(i: number, out: THREE.Vector3) {
    return out.copy(this.pos).addScaledVector(this.u, 0.45).addScaledVector(this.r, (i === 0 ? -1 : 1) * 0.2);
  }

  get gripped() {
    return (this.hands[0].gripped ? 1 : 0) + (this.hands[1].gripped ? 1 : 0);
  }

  get speedMs() {
    return this.vel.length();
  }

  // ---------------- ciclo de vida ----------------
  spawn(p: THREE.Vector3, keepRope = false) {
    this.pos.set(p.x, this.terrain.heightAt(p.x, p.z) + 0.95, p.z);
    this.vel.set(0, 0, 0);
    this.state = 'ground';
    for (const h of this.hands) {
      h.gripped = h.reaching = h.held = false;
      h.slip = h.fatigue = h.crumble = 0;
    }
    this.balance = this.balV = 0;
    if (!keepRope) {
      this.anchors.length = 0;
      this.ropeOut = 0;
    }
    this.ropeCaught = false;
    this.airTime = 0;
    this.lastPosY = this.pos.y;
  }

  kill(reason: string) {
    if (this.state === 'dead') return;
    this.state = 'dead';
    this.vel.set(0, 0, 0);
    for (const h of this.hands) h.gripped = h.reaching = false;
    this.emit('death', { reason });
  }

  // ---------------- transições ----------------
  private startClimb(x: number, z: number) {
    this.pos.set(x, this.terrain.heightAt(x, z) + 0.9, z);
    this.projectToSurface(this.pos, 0.46, this.pos);
    this.updateFrame();
    this.state = 'climb';
    this.vel.set(0, 0, 0);
    this.ropeCaught = false;
    this.balance = this.balV = 0;
    for (let i = 0; i < 2; i++) {
      const h = this.hands[i];
      this.shoulder(i, this.t1).addScaledVector(this.u, 0.55);
      const b = this.bestHold(this.t1);
      h.pos.copy(b.p);
      h.quality = b.q;
      h.mat = b.mat;
      h.gripped = true;
      h.reaching = false;
      h.slip = 0;
      h.crumble = 0;
      h.held = false;
    }
    this.emit('climbStart');
  }

  private letGo(impulse = 1) {
    this.state = 'air';
    this.vel.copy(this.n).multiplyScalar(0.6 * impulse).addScaledVector(this.u, -1.2 * impulse);
    for (const h of this.hands) h.gripped = h.reaching = false;
    this.airTime = 0;
    this.fallStartY = this.pos.y;
    this.catchCd = 0.25;
    this.ropeCaught = false;
  }

  private standUp(pos?: THREE.Vector3) {
    if (pos) this.pos.copy(pos);
    this.pos.y = this.terrain.heightAt(this.pos.x, this.pos.z) + 0.95;
    this.state = 'ground';
    this.vel.set(0, 0, 0);
    for (const h of this.hands) h.gripped = h.reaching = false;
    this.face.set(this.f.x, 0, this.f.z);
    if (this.face.lengthSq() < 1e-4) this.face.set(0, 0, -1);
    this.face.normalize();
    this.ropeCaught = false;
  }

  private mantle(point: THREE.Vector3) {
    this.t2.set(this.f.x, 0, this.f.z);
    if (this.t2.lengthSq() < 1e-4) this.t2.copy(this.face);
    this.t2.normalize();
    const p = this.t1.set(point.x + this.t2.x * 0.7, 0, point.z + this.t2.z * 0.7);
    this.f.set(this.t2.x, 0, this.t2.z);
    this.standUp(p);
    this.surv.useStamina(6);
    this.emit('mantle');
  }

  private releaseHand(i: number, reason: 'slip' | 'crumble' | 'manual') {
    const h = this.hands[i];
    h.gripped = false;
    h.reaching = reason === 'manual';
    h.slip = 0;
    h.crumble = 0;
    if (reason !== 'manual') {
      this.balV += (i === 0 ? 1 : -1) * 0.9;
      this.emit('slip', { hand: i, reason });
    }
    if (!this.hands[0].gripped && !this.hands[1].gripped) this.letGo(1);
  }

  // ---------------- ações de equipamento ----------------
  placePiton(): boolean {
    if (this.state !== 'climb' && this.state !== 'ground') return false;
    if (!this.ctx.rope) return false;
    if (this.surv.items.pitons <= 0) {
      this.emit('msg', { text: 'Sem pitons! Reabasteça em um acampamento.', kind: 'warn' });
      return false;
    }
    if (!this.surv.useStamina(5)) return false;
    const p = new THREE.Vector3();
    if (this.state === 'climb') {
      this.t1.copy(this.pos).addScaledVector(this.u, 0.35);
      this.projectToSurface(this.t1, 0.04, p);
    } else {
      p.set(this.pos.x + this.face.x * 0.6, 0, this.pos.z + this.face.z * 0.6);
      p.y = this.terrain.heightAt(p.x, p.z) + 0.1;
    }
    const mat = this.terrain.materialAt(p.x, p.z, p.y, this.terrain.slopeAt(p.x, p.z));
    if (mat === 'snow' || mat === 'scree' || mat === 'sand') {
      this.emit('msg', { text: 'Superfície solta: o piton não fixa. Procure rocha ou gelo.', kind: 'warn' });
      return false;
    }
    this.anchors.push(p);
    if (this.anchors.length > 14) this.anchors.shift();
    this.ropeOut = 1.0;
    this.surv.items.pitons--;
    this.emit('piton', { p });
    return true;
  }

  // ---------------- atualização principal ----------------
  update(dt: number) {
    if (this.state === 'dead') return;
    this.noiseT += dt;
    this.failMsgCd = Math.max(0, this.failMsgCd - dt);
    this.catchCd = Math.max(0, this.catchCd - dt);
    for (const h of this.hands) h.cd = Math.max(0, h.cd - dt);
    this.prompt = '';
    this.braced = false;
    this.sprinting = false;
    this.moving = false;

    this.lastPosY = this.pos.y;
    if (this.state === 'ground') this.updateGround(dt);
    else if (this.state === 'air') this.updateAir(dt);
    else if (this.state === 'climb') this.updateClimb(dt);

    // barreira do mundo
    const lim = this.terrain.half * 0.9;
    const rr = Math.hypot(this.pos.x, this.pos.z);
    if (rr > lim) {
      this.pos.x *= lim / rr;
      this.pos.z *= lim / rr;
    }
    this.world.resolveCaves(this.pos, this.vel);

    // ropeOut / alcance da corda
    if (this.anchors.length && this.state !== 'air') {
      const A = this.anchors[this.anchors.length - 1];
      const d = this.pos.distanceTo(A);
      if (d > this.ropeOut) this.ropeOut = d;
      if (this.ropeOut > 45) {
        this.anchors.length = 0;
        this.emit('msg', { text: 'A corda acabou! Fixe pitons com mais frequência.', kind: 'warn' });
      } else if (this.ropeOut > 38 && this.failMsgCd <= 0) {
        this.emit('msg', { text: 'Corda quase no fim — fixe um novo piton (R).', kind: 'info' });
        this.failMsgCd = 8;
      }
    }
    this.climbSpeedY = (this.pos.y - this.lastPosY) / Math.max(dt, 1e-4);
  }

  // ---------------- chão ----------------
  private updateGround(dt: number) {
    const inp = this.input;
    const ix = (inp.down('KeyD') ? 1 : 0) - (inp.down('KeyA') ? 1 : 0);
    const iy = (inp.down('KeyW') ? 1 : 0) - (inp.down('KeyS') ? 1 : 0);
    const dir = this.t1.set(0, 0, 0).addScaledVector(this.ctx.camForward, iy).addScaledVector(this.ctx.camRight, ix);
    const wants = dir.lengthSq() > 0.01;
    if (wants) dir.normalize();
    this.moving = wants;
    this.terrain.surface(this.pos.x, this.pos.z, this.surf);
    const mat = this.surf.mat;
    const onIce = mat === 'ice' && !this.ctx.crampons;
    const feetY = this.pos.y - 0.95;
    this.inWater = feetY < 0.2;

    if (inp.hit('KeyB')) {
      this.walkMode = !this.walkMode;
      this.emit('msg', { text: this.walkMode ? 'Modo cauteloso: caminhar olhando para a frente da câmera (strafe)' : 'Modo normal de movimento', kind: 'info' });
    }
    this.crouching = inp.down('KeyX');
    const sprint = wants && !this.crouching && (inp.down('ShiftLeft') || inp.down('ShiftRight')) && this.surv.stamina > 8 && !this.surv.exhausted;
    this.sprinting = sprint;
    let maxSp = sprint ? 7.2 : this.crouching ? 1.2 : this.walkMode ? 1.35 : 4.0;
    if (this.surv.exhausted) maxSp *= 0.7;
    if (this.inWater) maxSp *= 0.55;
    if (wants) {
      const rise = this.terrain.gx * dir.x + this.terrain.gz * dir.z;
      maxSp *= clamp(1 - Math.max(0, rise) * 0.5, 0.45, 1.15);
    }
    const accel = onIce ? 2.2 : 11;
    const tx = wants ? dir.x * maxSp : 0,
      tz = wants ? dir.z * maxSp : 0;
    const k = Math.min(1, accel * dt);
    this.vel.x += (tx - this.vel.x) * k;
    this.vel.z += (tz - this.vel.z) * k;
    this.vel.y = 0;
    // vento empurra
    this.vel.x += this.ctx.wind.x * 0.25 * dt;
    this.vel.z += this.ctx.wind.z * 0.25 * dt;
    if (onIce && this.surf.slope > 0.35) {
      this.terrain.sample(this.pos.x, this.pos.z);
      this.vel.x -= this.terrain.gx * 6 * dt;
      this.vel.z -= this.terrain.gz * 6 * dt;
    }
    if (sprint) this.surv.stamina = Math.max(0, this.surv.stamina - 9 * dt);

    // tentativa de movimento
    const nx = this.pos.x + this.vel.x * dt,
      nz = this.pos.z + this.vel.z * dt;
    const hNew = this.terrain.heightAt(nx, nz);
    const slopeNew = Math.hypot(this.terrain.gx, this.terrain.gz);
    const horiz = Math.hypot(this.vel.x, this.vel.z);
    const limit = this.walkLimit;
    let blocked = false;
    if (slopeNew > limit && horiz > 0.2) {
      blocked = true;
      const uphill = hNew > feetY - 0.02;
      const zKey = inp.down('KeyZ') || inp.down('ControlLeft');
      this.terrain.surface(nx, nz, this.surf);
      if (uphill) {
        // parede à frente: empurre para escalar
        const toward = -(this.surf.nx * dir.x + this.surf.nz * dir.z) / Math.max(0.001, Math.hypot(this.surf.nx, this.surf.nz));
        if (wants && toward > 0.3) {
          this.wallTimer += dt;
          this.prompt = 'Escalando…';
          if (this.wallTimer > 0.16 && this.surv.stamina > 5 && !this.surv.exhausted) {
            this.wallTimer = 0;
            this.startClimb(nx, nz);
            return;
          }
        } else this.wallTimer = 0;
      } else {
        this.wallTimer = 0;
        this.prompt = 'Borda! Segure Z para descer pela parede, ou Espaço para saltar';
        if (zKey && this.surv.stamina > 5) {
          this.startClimb(nx, nz);
          return;
        }
      }
      this.vel.x *= 0.2;
      this.vel.z *= 0.2;
    } else {
      this.wallTimer = 0;
    }
    if (!blocked) {
      const dd = Math.hypot(nx - this.pos.x, nz - this.pos.z);
      this.distWalked += dd;
      this.pos.x = nx;
      this.pos.z = nz;
      this.pos.y = hNew + 0.95;
    }
    this.world.colliders.resolve(this.pos, this.pos.y - 0.95, this.terrain);
    this.pos.y = this.terrain.heightAt(this.pos.x, this.pos.z) + 0.95;

    // orientação e animação
    if (this.walkMode && !sprint) {
      this.face.copy(this.ctx.camForward).setY(0).normalize();
    } else if (wants && !blocked) {
      this.face.lerp(dir, Math.min(1, 12 * dt));
      this.face.y = 0;
      this.face.normalize();
    } else if (blocked && wants) {
      this.face.lerp(dir, Math.min(1, 8 * dt)).normalize();
    }
    const spd = Math.hypot(this.vel.x, this.vel.z);
    this.speedNorm += (clamp(spd / 6, 0, 1.2) - this.speedNorm) * Math.min(1, dt * 10);
    this.walkPhase += spd * dt * 2.4;
    this.effort = sprint ? 0.75 : wants ? 0.25 : 0.04;
    this.resting = !sprint;

    // pulo
    if (inp.hit('Space') && this.surv.stamina > 6 && !this.inWater) {
      this.surv.useStamina(6);
      this.vel.y = 7.6;
      this.state = 'air';
      this.airTime = 0;
      this.fallStartY = this.pos.y;
      this.catchCd = 0.3;
      return;
    }
    // deslizar se o chão sob os pés ficar íngreme demais
    this.terrain.surface(this.pos.x, this.pos.z, this.surf);
    if (this.surf.slope > 2.0) {
      this.state = 'air';
      this.airTime = 0;
      this.fallStartY = this.pos.y;
      this.vel.set(0, 0, 0);
    }
  }

  // ---------------- ar ----------------
  private updateAir(dt: number) {
    const inp = this.input;
    this.airTime += dt;
    this.vel.y = Math.max(-55, this.vel.y - WORLD.gravity * dt);
    const ix = (inp.down('KeyD') ? 1 : 0) - (inp.down('KeyA') ? 1 : 0);
    const iy = (inp.down('KeyW') ? 1 : 0) - (inp.down('KeyS') ? 1 : 0);
    if (!this.ropeCaught && (ix || iy)) {
      const dir = this.t1.set(0, 0, 0).addScaledVector(this.ctx.camForward, iy).addScaledVector(this.ctx.camRight, ix).normalize();
      this.vel.x += dir.x * 5 * dt;
      this.vel.z += dir.z * 5 * dt;
    }
    this.vel.x += this.ctx.wind.x * 0.3 * dt;
    this.vel.z += this.ctx.wind.z * 0.3 * dt;
    this.pos.addScaledVector(this.vel, dt);
    if (this.vel.y > 0) this.fallStartY = Math.max(this.fallStartY, this.pos.y);
    this.effort = 0.15;
    this.resting = false;

    // corda
    if (this.anchors.length && this.ctx.rope) {
      const A = this.anchors[this.anchors.length - 1];
      const Lmax = this.ropeOut + 1.5;
      this.t1.copy(this.pos).sub(A);
      const dist = this.t1.length();
      if (dist > Lmax) {
        this.t1.divideScalar(dist);
        this.pos.copy(A).addScaledVector(this.t1, Lmax);
        const vr = this.vel.dot(this.t1);
        if (vr > 0) {
          this.vel.addScaledVector(this.t1, -vr);
          if (!this.ropeCaught && vr > 6) {
            this.emit('ropeCatch', { speed: vr });
            if (vr > 24) {
              this.surv.damage((vr - 24) * 2);
              if (this.surv.health <= 0) return this.kill('shock');
            }
          }
          this.ropeCaught = true;
        }
        this.vel.multiplyScalar(1 - 0.6 * dt);
      }
      if (this.ropeCaught) {
        this.prompt = 'Na corda — W sobe, S desce, Q/E agarra a parede';
        if (inp.down('KeyW') && this.surv.stamina > 1) {
          this.ropeOut = Math.max(1.5, this.ropeOut - 1.8 * dt);
          this.surv.stamina = Math.max(0, this.surv.stamina - 4 * dt);
        } else if (inp.down('KeyS')) {
          this.ropeOut = Math.min(45, this.ropeOut + 1.8 * dt);
        }
      }
    }

    // colisão com o terreno
    const h = this.terrain.heightAt(this.pos.x, this.pos.z);
    const gx = this.terrain.gx,
      gz = this.terrain.gz;
    const l = Math.sqrt(gx * gx + 1 + gz * gz);
    const nx = -gx / l,
      ny = 1 / l,
      nz = -gz / l;
    const dn = (this.pos.y - h) * ny;
    const c = 0.5 + 0.45 * ny;
    let nearWall = dn < 1.25;
    if (dn < c) {
      const pen = c - dn;
      this.pos.x += nx * pen;
      this.pos.y += ny * pen;
      this.pos.z += nz * pen;
      const vn = this.vel.x * nx + this.vel.y * ny + this.vel.z * nz;
      if (vn < 0) {
        this.vel.x -= nx * vn;
        this.vel.y -= ny * vn;
        this.vel.z -= nz * vn;
        const slope = Math.hypot(gx, gz);
        this.impact(-vn);
        if (this.state !== 'air') return;
        if (slope <= WORLD.walkSlope * 0.95 && this.state === 'air') {
          this.landed();
          return;
        }
        this.vel.x *= 1 - 0.8 * dt;
        this.vel.z *= 1 - 0.8 * dt;
        this.vel.y *= 1 - 0.3 * dt;
      }
    }
    this.world.colliders.resolve(this.pos, this.pos.y - 0.95, this.terrain);
    if (this.pos.y < -3) {
      this.surv.damage(100);
      return this.kill('water');
    }

    // agarrar em pleno ar
    const lk = inp.down('KeyQ') || inp.buttons[0];
    const rk = inp.down('KeyE') || inp.buttons[2];
    if ((lk || rk) && nearWall && this.catchCd <= 0 && this.surv.stamina > 2) this.tryCatch(lk, rk);
    else if (nearWall && !this.ropeCaught && this.airTime > 0.2) this.prompt = 'Segure Q / E para agarrar a parede';
    nearWall = false;
  }

  private tryCatch(lk: boolean, rk: boolean) {
    this.projectToSurface(this.pos, 0.46, this.t2);
    const saved = this.pos.clone();
    this.pos.copy(this.t2);
    this.updateFrame();
    const speed = this.vel.length();
    const stam = this.surv.stamina / 100;
    const strength = 0.4 + 0.6 * Math.sqrt(stam);
    let any = false;
    for (let i = 0; i < 2; i++) {
      if (!(i === 0 ? lk : rk)) continue;
      const h = this.hands[i];
      if (h.cd > 0) continue;
      this.shoulder(i, this.t1).addScaledVector(this.u, 0.35);
      const b = this.bestHold(this.t1);
      const capacity = Math.max(0.05, b.q * strength);
      const load = speed * 0.085;
      h.cd = 0.3;
      if (b.q < 0.15 || load > capacity * 1.6) {
        this.emit('msg', { text: 'A mão não segurou!', kind: 'warn' });
        this.emit('slip', { hand: i, reason: 'catch' });
        continue;
      }
      h.pos.copy(b.p);
      h.quality = b.q;
      h.mat = b.mat;
      h.gripped = true;
      h.reaching = false;
      h.held = true;
      h.slip = clamp(load / capacity - 0.4, 0, 0.9);
      h.crumble = 0;
      any = true;
    }
    if (any) {
      this.state = 'climb';
      this.surv.useStamina(8);
      const fell = this.fallStartY - this.pos.y;
      this.vel.set(0, 0, 0);
      this.ropeCaught = false;
      this.balV = (Math.random() - 0.5) * 1.2;
      this.emit('catch', { speed, fell });
    } else {
      this.pos.copy(saved);
      this.catchCd = 0.2;
    }
  }

  private impact(speed: number) {
    if (speed > 13) {
      const dmg = (speed - 13) * 3.4;
      this.surv.damage(dmg);
      this.emit('thud', { speed, dmg });
      if (this.surv.health <= 0 || speed > 46) {
        this.kill('fall');
      }
    }
  }

  private landed() {
    const fell = this.fallStartY - this.pos.y;
    this.emit('landed', { fell });
    this.state = 'ground';
    this.vel.set(0, 0, 0);
    this.ropeCaught = false;
    this.pos.y = this.terrain.heightAt(this.pos.x, this.pos.z) + 0.95;
  }

  // ---------------- escalada ----------------
  private updateClimb(dt: number) {
    const inp = this.input;
    this.updateFrame();
    const ix = (inp.down('KeyD') ? 1 : 0) - (inp.down('KeyA') ? 1 : 0);
    const iy = (inp.down('KeyW') ? 1 : 0) - (inp.down('KeyS') ? 1 : 0);
    const keys = [inp.down('KeyQ') || inp.buttons[0], inp.down('KeyE') || inp.buttons[2]];
    this.braced = inp.down('ShiftLeft') || inp.down('ShiftRight');
    const mat = this.surf.mat;
    const slopeF = smoothstep(1.0, 3.0, this.surf.slope);
    let reaching = 0;

    // soltar tudo / saltar
    if (inp.down('KeyZ') || inp.down('ControlLeft')) {
      this.letGo(1);
      return;
    }
    if (inp.hit('Space') && this.surv.stamina >= 12) {
      this.surv.useStamina(14);
      const u = this.u.clone(),
        n = this.n.clone();
      this.state = 'air';
      this.vel.copy(u).multiplyScalar(6.8).addScaledVector(n, 1.6);
      for (const h of this.hands) h.gripped = h.reaching = false;
      this.airTime = 0;
      this.fallStartY = this.pos.y;
      this.catchCd = 0.32;
      this.emit('dyno');
      return;
    }

    // controle independente das mãos
    for (let i = 0; i < 2; i++) {
      const h = this.hands[i];
      const other = this.hands[1 - i];
      const held = !!keys[i];
      const rising = held && !h.held;
      const falling = !held && h.held;
      if (rising) {
        if (h.gripped) {
          if (other.gripped) {
            h.gripped = false;
            h.reaching = true;
            h.slip = 0;
            h.crumble = 0;
            h.pos.copy(h.pos);
          }
        } else if (!h.reaching) h.reaching = true;
      }
      if (falling && h.reaching) {
        // soltou a tecla: tenta agarrar
        h.reaching = false;
        if (h.candQ >= 0.15) {
          h.gripped = true;
          h.pos.copy(h.cand);
          h.quality = h.candQ;
          h.mat = h.candMat;
          h.slip = 0;
          h.crumble = 0;
          this.emit('grab', { hand: i, q: h.candQ, p: h.pos });
          const sl = this.terrain.slopeAt(h.pos.x, h.pos.z);
          if (sl < this.walkLimit * 0.92) {
            h.held = held;
            this.mantle(h.pos);
            return;
          }
        } else if (this.failMsgCd <= 0) {
          this.emit('msg', { text: 'Sem apoio ali — mire em outro ponto.', kind: 'warn' });
          this.failMsgCd = 1.5;
        }
      }
      h.held = held;
      if (h.reaching && held) {
        reaching++;
        this.shoulder(i, this.t1);
        const aim = this.t2.set(0, 0, 0).addScaledVector(this.r, ix).addScaledVector(this.u, iy);
        if (aim.lengthSq() < 0.01) aim.copy(this.u).multiplyScalar(0.8);
        else aim.clampLength(0, 1);
        this.t1.addScaledVector(aim, 0.84);
        const b = this.bestHold(this.t1, ix, iy || (ix ? 0 : 1));
        h.cand.copy(b.p);
        h.candQ = b.q;
        h.candMat = b.mat;
        h.pos.lerp(h.cand, 1 - Math.exp(-16 * dt));
        h.fatigue = Math.max(0, h.fatigue - 0.01 * dt);
      }
      if (!h.gripped && !h.reaching) {
        // mão livre pendurada
        this.shoulder(i, this.t1).addScaledVector(this.u, -0.65).addScaledVector(this.n, 0.12);
        h.pos.lerp(this.t1, 1 - Math.exp(-8 * dt));
        h.fatigue = Math.max(0, h.fatigue - 0.04 * dt);
      }
    }

    const nG = this.gripped;
    if (nG === 0) {
      this.letGo(1);
      return;
    }

    // posição do corpo pendurado nas mãos
    this.t1.set(0, 0, 0);
    for (const h of this.hands) if (h.gripped) this.t1.add(h.pos);
    this.t1.multiplyScalar(1 / nG);
    const lateral = this.balance * (nG === 1 ? 0.5 : 0.12);
    this.t1.addScaledVector(this.u, nG === 2 ? -0.8 : -0.86).addScaledVector(this.r, lateral);
    this.projectToSurface(this.t1, 0.46, this.t2);
    this.pos.lerp(this.t2, 1 - Math.exp(-7 * dt));
    this.projectToSurface(this.pos, 0.46, this.pos);

    // equilíbrio
    const stamF = this.surv.stamina / 100;
    const windR = this.ctx.wind.dot(this.r);
    const noise = Math.sin(this.noiseT * 1.7) * Math.sin(this.noiseT * 0.71 + 1.3) + 0.6 * Math.sin(this.noiseT * 3.1);
    const dist = (0.18 + (1 - stamF) * 0.35 + (nG === 1 ? 0.55 : 0)) * noise + windR * 0.012;
    this.balV += dist * dt * 4;
    if (nG === 1) this.balV += this.balance * 1.1 * dt;
    else this.balV -= this.balance * 7 * dt;
    if (reaching === 0 && !this.braced) this.balV += ix * 3.2 * dt;
    if (this.braced) this.balV *= 1 - Math.min(1, 4 * dt);
    this.balV *= 1 - Math.min(1, 2.2 * dt);
    this.balance = clamp(this.balance + this.balV * dt, -1.4, 1.4);

    // cargas e aderência
    let loadFactor = 0.25 + 0.75 * slopeF;
    if (this.braced) loadFactor *= 0.72;
    if (this.ctx.crampons && (mat === 'ice' || mat === 'snow')) loadFactor *= 0.8;
    loadFactor *= 1 + this.ctx.windSpeed / 38;
    const swing = smoothstep(0.55, 1.2, Math.abs(this.balance)) * 0.9;
    const strength = 0.4 + 0.6 * Math.sqrt(stamF);
    for (let i = 0; i < 2; i++) {
      const h = this.hands[i];
      if (!h.gripped) continue;
      const load = (loadFactor / nG) * (1 + swing);
      const capacity = Math.max(0.03, h.quality * strength * (1 - h.fatigue * 0.55) * (this.surv.exhausted ? 0.45 : 1));
      const ratio = load / capacity;
      if (ratio > 0.8) h.slip += (ratio - 0.8) * 1.6 * dt;
      else h.slip = Math.max(0, h.slip - 0.35 * dt);
      h.fatigue = clamp(h.fatigue + load * 0.015 * dt, 0, 1);
      if (h.mat === 'scree' || h.quality < 0.28) h.crumble += dt;
      if (h.slip >= 1) {
        this.releaseHand(i, 'slip');
        if (this.state !== 'climb') return;
      } else if (h.crumble > 1.4 + h.quality * 3) {
        this.releaseHand(i, 'crumble');
        if (this.state !== 'climb') return;
      }
    }
    if (this.balance > 1.3 || this.balance < -1.3) {
      if (this.gripped === 1) {
        const gi = this.hands[0].gripped ? 0 : 1;
        this.releaseHand(gi, 'slip');
        if (this.state !== 'climb') return;
      }
    }

    // custo de stamina
    let drain = nG === 2 ? 1.0 : 3.2;
    drain *= 0.7 + 0.5 * slopeF;
    if (reaching > 0) drain += 1.6 * reaching;
    if (this.braced) drain += 1.8;
    const still = reaching === 0 && nG === 2 && !this.braced && this.surf.slope < 1.7;
    if (still) {
      drain = 0;
      this.surv.stamina = Math.min(this.surv.staminaMax, this.surv.stamina + 3.5 * this.surv.o2 * dt);
    }
    this.surv.stamina = Math.max(0, this.surv.stamina - drain * dt * (1 / this.surv.o2));
    this.effort = 0.6 + 0.3 * (reaching > 0 ? 1 : 0);
    this.resting = false;

    // chegou a um trecho suave? levanta
    if (this.surf.slope < this.walkLimit * 0.88 && nG >= 1) {
      this.standUp();
      return;
    }

    // dicas
    if (reaching > 0) {
      const h = this.hands[this.hands[0].reaching ? 0 : 1];
      this.prompt = h.candQ >= 0.15 ? `Solte para agarrar — aderência ${Math.round(Math.min(1, h.candQ) * 100)}%` : 'Sem apoio nesse ponto';
    } else if (nG === 2) this.prompt = 'Segure Q / E, mire com WASD e solte para agarrar';
    else this.prompt = 'Mão livre! Segure a outra tecla (Q/E) para alcançar um novo apoio';
  }

  /** Efeito físico de ser atingido por uma pedra. */
  rockHit(dir: THREE.Vector3) {
    if (this.state === 'climb') {
      for (const h of this.hands) if (h.gripped) h.slip = Math.min(0.95, h.slip + 0.55);
      this.balV += (Math.random() - 0.5) * 3;
    } else if (this.state === 'ground') {
      this.vel.x += dir.x * 0.3;
      this.vel.z += dir.z * 0.3;
    } else {
      this.vel.addScaledVector(dir, 0.25);
    }
  }

  /** Posição de câmera: yaw ideal para olhar para a parede. */
  wallYaw() {
    return Math.atan2(-this.f.x, -this.f.z);
  }

  /** Preenche pontos de apoio visíveis ao redor do jogador (modo escalada). */
  hints(pos: Float32Array, col: Float32Array): number {
    let k = 0;
    this.updateFrame();
    for (let iu = -2; iu <= 5; iu++) {
      for (let ir = -4; ir <= 4; ir++) {
        this.tq.copy(this.pos).addScaledVector(this.u, iu * 0.3 + 0.2).addScaledVector(this.r, ir * 0.3);
        this.projectToSurface(this.tq, 0.07, this.tq);
        const g = this.gripAt(this.tq.x, this.tq.z);
        if (g.q < 0.3) {
          pos[k * 3] = pos[k * 3 + 1] = pos[k * 3 + 2] = -99999;
        } else {
          pos[k * 3] = this.tq.x;
          pos[k * 3 + 1] = this.tq.y;
          pos[k * 3 + 2] = this.tq.z;
          if (g.q >= 0.85) {
            col[k * 3] = 0.4;
            col[k * 3 + 1] = 1;
            col[k * 3 + 2] = 0.5;
          } else if (g.q >= 0.55) {
            col[k * 3] = 1;
            col[k * 3 + 1] = 0.85;
            col[k * 3 + 2] = 0.3;
          } else {
            col[k * 3] = 1;
            col[k * 3 + 1] = 0.35;
            col[k * 3 + 2] = 0.3;
          }
        }
        k++;
      }
    }
    return k;
  }
}
