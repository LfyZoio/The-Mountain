import * as THREE from 'three';
import { MountainDef, EQUIPMENT, EquipId, ACHIEVEMENTS } from './config';
import { Terrain, MAT_NAMES } from './terrain';
import { planLayout, Layout } from './layout';
import { World, SkyDome, Clouds } from './world';
import { Weather, SnowParticles, WEATHER_NAMES } from './weather';
import { Survival } from './survival';
import { Player } from './player';
import { CharacterAvatar } from '../character/avatar';
import { loadProtagonist } from '../character/loader';
import { CameraRig } from './cameraRig';
import { Input } from './input';
import { GameAudio } from './audio';
import { FX, Rockfall } from './fx';
import { Profile } from './progression';
import { clamp, lerp, smoothstep } from './noise';

export interface HudHand {
  st: 'grip' | 'reach' | 'free';
  q: number;
  slip: number;
  fat: number;
}

export interface HudState {
  alt: number;
  altMax: number;
  summitM: number;
  progress: number;
  stamina: number;
  staminaMax: number;
  health: number;
  energy: number;
  temp: number;
  ambient: number;
  oxygen: number;
  oxygenOn: boolean;
  lampOn: boolean;
  exhausted: boolean;
  hands: [HudHand, HudHand];
  balance: number;
  mode: string;
  roped: boolean;
  ropeOut: number;
  anchors: number;
  pitons: number;
  chalk: number;
  chalkT: number;
  food: number;
  tea: number;
  windKmh: number;
  windDir: number;
  weather: string;
  precip: number;
  biome: string;
  heading: number;
  summitBearing: number;
  summitDist: number;
  campBearing: number | null;
  campDist: number;
  campName: string;
  time: number;
  prompt: string;
  cold: number;
  hurt: number;
  camps: { p: number; active: boolean }[];
  checkpoint: number;
  intro: number;
  inCave: boolean;
  hints: boolean;
  vista: boolean;
  muted: boolean;
  matName: string;
  level: number;
  xpFrac: number;
  unlocked: Record<string, boolean>;
  dead: boolean;
  speed: number;
}

export interface Toast {
  text: string;
  kind: 'info' | 'warn' | 'good' | 'ach';
  icon?: string;
}

export interface VictoryInfo {
  time: number;
  best: number;
  record: boolean;
  xp: number;
  achievements: string[];
  mountain: string;
  pitons: number;
  falls: number;
  climbed: number;
}

export interface GameEvents {
  onHud: (h: HudState) => void;
  onToast: (t: Toast) => void;
  onVictory: (v: VictoryInfo) => void;
  onDeath: (on: boolean, reason?: string) => void;
  onLoading: (pct: number, label: string) => void;
  onPause: () => void;
  onReady: () => void;
}

type RunState = 'loading' | 'ready' | 'running' | 'paused' | 'victory';

const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => r()));
const DEG = 180 / Math.PI;
const norm360 = (d: number) => ((d % 360) + 360) % 360;

export class Game {
  runState: RunState = 'loading';
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.2, 9000);
  terrain: Terrain;
  layout!: Layout;
  world!: World;
  weather = new Weather();
  surv = new Survival();
  input!: Input;
  audio = new GameAudio();
  player!: Player;
  avatar: CharacterAvatar | null = null;
  camRig!: CameraRig;
  fx = new FX();
  rockfall = new Rockfall();
  snow = new SnowParticles();
  sky = new SkyDome();
  clouds!: Clouds;

  private hemi = new THREE.HemisphereLight(0xbcd4ff, 0x5a5448, 1);
  private sun = new THREE.DirectionalLight(0xfff0d8, 3.2);
  private pointLights: THREE.PointLight[] = [];
  private sunDir = new THREE.Vector3(0.45, 0.55, 0.35).normalize();
  private ropeMesh!: THREE.InstancedMesh;
  private pitonMeshes: THREE.Mesh[] = [];
  private reticles: THREE.Mesh[] = [];
  private hintPoints!: THREE.Points;
  private hintPos = new Float32Array(72 * 3);
  private hintCol = new Float32Array(72 * 3);
  private hintTimer = 0;
  private raf = 0;
  private lastT = 0;
  private time = 0;
  private runTime = 0;
  private hudTimer = 0;
  private saveTimer = 0;
  private windVec = new THREE.Vector3();
  private windSpeed = 0;
  private caveT = 0;
  private inCave = false;
  private activeCamps: boolean[] = [];
  private checkpoint = 0;
  private deadTimer = 0;
  private wasLocked = false;
  private hintsOn = true;
  private maxY = 0;
  private maxAltDisplayed = 0;
  private runPitons = 0;
  private runFalls = 0;
  private runClimbed = 0;
  private runCamps = 0;
  private newAch: string[] = [];
  private sessionXp = 0;
  private hypo = false;
  private ambient = 10;
  private nearFire = false;
  private tmpV = new THREE.Vector3();
  private lightTimer = 0;
  private eatCd = 0;
  private resizeHandler = () => this.resize();
  private disposed = false;
  private container: HTMLElement;
  private firstClimbTip = true;

  constructor(
    container: HTMLElement,
    public def: MountainDef,
    public profile: Profile,
    private ev: GameEvents,
  ) {
    this.container = container;
    this.terrain = new Terrain(def);
  }

  private async frame() {
    await nextFrame();
    if (this.disposed) throw new Error('disposed');
  }

  // ---------------- carregamento ----------------
  async init() {
    const def = this.def;
    this.ev.onLoading(0.02, 'Preparando renderizador…');
    await this.frame();
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.resize();
    window.addEventListener('resize', this.resizeHandler);
    this.input = new Input(this.renderer.domElement);

    this.ev.onLoading(0.08, 'Esculpindo a montanha…');
    await this.frame();
    this.layout = planLayout(this.terrain);
    this.ev.onLoading(0.25, 'Gerando relevo e cavernas…');
    await this.frame();
    this.terrain.buildGrid();
    this.ev.onLoading(0.5, 'Pintando rochas, gelo e neve…');
    await this.frame();
    const mesh = this.terrain.buildMesh();
    this.scene.add(mesh);
    this.ev.onLoading(0.7, 'Plantando florestas e montando acampamentos…');
    await this.frame();
    this.world = new World(this.terrain, this.layout);
    this.scene.add(this.world.group);

    this.scene.add(this.sky.mesh);
    this.clouds = new Clouds(def, def.seed);
    this.scene.add(this.clouds.group);
    this.scene.add(this.snow.points);
    this.scene.add(this.fx.points);
    this.scene.add(this.rockfall.group);
    this.scene.fog = new THREE.FogExp2(0xaecbe8, 0.001);

    // luzes
    this.scene.add(this.hemi);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -70;
    sc.right = 70;
    sc.top = 70;
    sc.bottom = -70;
    sc.near = 1;
    sc.far = 900;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.5;
    this.scene.add(this.sun, this.sun.target);
    for (let i = 0; i < 3; i++) {
      const l = new THREE.PointLight(0xffffff, 0, 30, 2);
      this.pointLights.push(l);
      this.scene.add(l);
    }

    // personagem
    this.ev.onLoading(0.85, 'Carregando protagonista (rig + animações)…');
    await this.frame();
    const model = await loadProtagonist();
    if (this.disposed) throw new Error('disposed');
    this.avatar = new CharacterAvatar(model);
    model.object.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) o.castShadow = true;
    });
    this.scene.add(model.object);

    // corda, pitons, retículos, dicas
    const rg = new THREE.CylinderGeometry(0.03, 0.03, 1, 5);
    this.ropeMesh = new THREE.InstancedMesh(rg, new THREE.MeshStandardMaterial({ color: 0xffc94d, roughness: 0.8 }), 48);
    this.ropeMesh.frustumCulled = false;
    this.ropeMesh.count = 0;
    this.scene.add(this.ropeMesh);
    for (let i = 0; i < 14; i++) {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.3, 6).rotateX(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xbfc7cf, metalness: 0.8, roughness: 0.3 }));
      m.visible = false;
      this.pitonMeshes.push(m);
      this.scene.add(m);
    }
    for (let i = 0; i < 2; i++) {
      const m = new THREE.Mesh(
        new THREE.RingGeometry(0.1, 0.15, 20),
        new THREE.MeshBasicMaterial({ color: 0x66ff88, transparent: true, opacity: 0.95, side: THREE.DoubleSide, depthTest: false }),
      );
      m.renderOrder = 20;
      m.visible = false;
      this.reticles.push(m);
      this.scene.add(m);
    }
    const hg = new THREE.BufferGeometry();
    hg.setAttribute('position', new THREE.BufferAttribute(this.hintPos, 3));
    hg.setAttribute('color', new THREE.BufferAttribute(this.hintCol, 3));
    this.hintPoints = new THREE.Points(hg, new THREE.PointsMaterial({ size: 0.1, vertexColors: true, transparent: true, opacity: 0.85, depthWrite: false }));
    this.hintPoints.frustumCulled = false;
    this.hintPoints.visible = false;
    this.scene.add(this.hintPoints);

    // sistemas de jogo
    this.camRig = new CameraRig(this.camera, this.terrain);
    this.player = new Player(this.terrain, this.world, this.surv, this.input, (t, d) => this.onPlayerEvent(t, d));
    const base = this.layout.camps[0];
    this.player.spawn(base.pos);
    const toC = new THREE.Vector3(-base.pos.x, 0, -base.pos.z).normalize();
    this.player.face.copy(toC);
    this.camRig.yaw = Math.atan2(-toC.x, -toC.z);
    this.activeCamps = this.layout.camps.map((_, i) => i === 0);
    this.world.setCampActive(0, true);
    this.maxY = this.player.pos.y;
    this.camera.position.set(base.pos.x + 50, base.pos.y + 30, base.pos.z + 50);
    this.ev.onLoading(0.95, 'Ajustando iluminação…');
    await this.frame();
    this.applyEnvironment(0.016, true);
    this.renderer.compile(this.scene, this.camera);
    this.ev.onLoading(1, 'Pronto');
    this.runState = 'ready';
    (window as any).__game = this;
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.tick);
    this.ev.onReady();
  }

  /** Chamado por um clique do jogador (necessário para áudio e pointer lock). */
  begin() {
    if (this.runState !== 'ready') return;
    this.audio.start();
    this.audio.setMuted(this.audio.muted);
    this.input.lock();
    this.camRig.startIntro(this.layout.summit);
    this.runState = 'running';
    this.toast(`Bem-vindo ao ${this.def.name}`, 'info', '🏔️');
    this.lastT = performance.now();
  }

  pause() {
    if (this.runState !== 'running') return;
    this.runState = 'paused';
    this.input.unlock();
    this.profile.save();
  }

  resume() {
    if (this.runState !== 'paused') return;
    this.runState = 'running';
    this.input.lock();
    this.lastT = performance.now();
  }

  skipIntro() {
    this.camRig.introT = 1;
  }

  get introActive() {
    return this.camRig && this.camRig.introT < 1;
  }

  private resize() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  // ---------------- laço principal ----------------
  private tick = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.tick);
    const now = performance.now();
    const dt = Math.min((now - this.lastT) / 1000, 0.05);
    this.lastT = now;

    if (this.runState === 'running') {
      // detecta perda do pointer lock = pausa
      if (this.wasLocked && !this.input.locked) {
        this.wasLocked = false;
        this.pause();
        this.ev.onPause();
      } else {
        this.wasLocked = this.input.locked;
        this.step(dt);
      }
    } else if (this.runState === 'ready') {
      this.idleCamera(dt);
    }
    this.renderer.render(this.scene, this.camera);
  };

  private idleCamera(dt: number) {
    // câmera panorâmica na tela de início
    this.time += dt;
    const c = this.layout.camps[0].pos;
    const a = this.time * 0.08;
    this.camera.position.set(c.x + Math.cos(a) * 60, c.y + 25, c.z + Math.sin(a) * 60);
    this.camera.lookAt(0, this.def.peak * 0.5, 0);
    this.applyEnvironment(dt, false);
    this.world.update(dt);
    this.sky.mesh.position.copy(this.camera.position);
  }

  private altM(y: number) {
    const sy = this.layout.summit.y;
    return this.def.baseM + clamp(y / sy, 0, 1.05) * (this.def.summitM - this.def.baseM);
  }

  private step(dt: number) {
    const inp = this.input;
    this.time += dt;
    const p = this.player;
    const introduction = this.camRig.introT < 1;

    if (introduction) {
      if (inp.hit('Space') || inp.hit('Enter') || inp.hit('Escape')) this.skipIntro();
    } else {
      this.runTime += dt;
      this.profile.data.stats.time += dt;
      this.saveTimer += dt;
      if (this.saveTimer > 20) {
        this.saveTimer = 0;
        this.profile.save();
      }
    }

    // direção da câmera → jogador
    this.camRig.forward(p.ctx.camForward);
    this.camRig.right(p.ctx.camRight);

    // ambiente em torno do jogador
    const a01 = clamp(p.pos.y / this.layout.summit.y, 0, 1.1);
    this.weather.update(dt, a01, this.def.severity);
    const cave = this.world.caveAt(p.pos);
    this.inCave = !!cave;
    this.caveT = lerp(this.caveT, this.inCave ? 1 : 0, 1 - Math.exp(-dt * 3));
    if (cave && !this.profile.has('cave') && !introduction) {
      this.profile.data.stats.caves++;
      this.ach('cave');
    }
    let ws = this.weather.wind(this.time, p.pos.y, this.terrain.windExposure(p.pos.x, p.pos.z, p.pos.y), this.def.severity, this.def.peak, this.windVec);
    if (this.inCave) {
      this.windVec.multiplyScalar(0.05);
      ws *= 0.05;
    }
    this.windSpeed = ws;
    p.ctx.wind.copy(this.windVec);
    p.ctx.windSpeed = ws;
    p.ctx.wet = this.weather.wet * (this.inCave ? 0.2 : 1);
    p.ctx.axe = this.has('axe');
    p.ctx.crampons = this.has('crampons');
    p.ctx.rope = this.has('rope');
    p.inCave = this.inCave;

    // temperatura ambiente
    let amb = 18 - 36 * a01 - (this.def.severity - 0.65) * 6 * a01;
    amb += this.weather.tempOff * (0.6 + 0.4 * a01);
    amb -= ws * 0.28;
    if (this.inCave) amb = Math.max(amb * 0.25, 2);
    this.ambient = amb;
    const insulation = 0.25 + (this.has('jacket') ? 0.42 : 0) + (this.inCave ? 0.05 : 0);

    // fogueiras
    this.nearFire = false;
    for (const c of this.layout.camps) {
      if (Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z) < 7 && Math.abs(p.pos.y - c.pos.y) < 5) this.nearFire = true;
    }

    if (!introduction) {
      this.handleEquipment(dt);
      p.update(dt);
      const inWater = p.inWater && p.state === 'ground';
      this.surv.update(dt, {
        effort: p.effort,
        resting: p.resting,
        ambient: inWater ? 4 : amb,
        insulation: inWater ? 0 : insulation,
        altFrac: a01,
        nearFire: this.nearFire,
        inCave: this.inCave,
        wet: p.ctx.wet,
      });
      if (inWater) this.surv.temp -= 0.15 * dt;
      this.checkSurvivalDeath();
      this.trackProgress(dt);
      this.checkCamps();
      this.checkSummit();
      this.updateRockfall(dt);
    }

    // morte / respawn
    if (p.state === 'dead') {
      this.deadTimer -= dt;
      if (this.deadTimer <= 0) this.respawn();
    }

    this.fx.update(dt);
    this.world.update(dt);
    this.applyEnvironment(dt, false);
    this.updateVisuals(dt);

    // câmera
    const lookX = inp.mouseDX + ((inp.down('ArrowRight') ? 1 : 0) - (inp.down('ArrowLeft') ? 1 : 0)) * 650 * dt;
    const lookY = inp.mouseDY + ((inp.down('ArrowDown') ? 1 : 0) - (inp.down('ArrowUp') ? 1 : 0)) * 450 * dt;
    this.camRig.update(dt, this.time, p.pos, {
      climbing: p.state === 'climb',
      wallYaw: p.wallYaw(),
      look: { dx: lookX, dy: lookY },
      sprint: p.sprinting,
      wind: ws,
      falling: p.state === 'air' && p.vel.y < -12,
    });

    // HUD
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.1;
      this.ev.onHud(this.buildHud());
    }
    inp.endFrame();
  }

  // ---------------- equipamentos ----------------
  private has(id: EquipId) {
    return this.profile.equipUnlocked(id);
  }

  private handleEquipment(dt: number) {
    const inp = this.input;
    const s = this.surv;
    this.eatCd = Math.max(0, this.eatCd - dt);
    if (inp.hit('KeyR')) {
      if (!this.has('rope')) this.toast('Corda ainda bloqueada.', 'warn');
      else this.player.placePiton();
    }
    if (inp.hit('KeyC') && this.has('chalk')) {
      if (s.items.chalk > 0 && s.chalkTimer < 25) {
        s.items.chalk--;
        s.chalkTimer = 90;
        this.fx.burst(this.player.pos, 0xffffff, 18, 2.5, 0.8);
        this.toast('Magnésio aplicado — aderência melhorada por 90 s', 'good', '🤍');
      } else if (s.items.chalk <= 0) this.toast('Sem magnésio.', 'warn');
    }
    if (inp.hit('KeyF') && this.has('food') && this.eatCd <= 0) {
      if (s.items.food > 0) {
        s.items.food--;
        s.energy = Math.min(100, s.energy + 38);
        s.stamina = Math.min(s.staminaMax, s.stamina + 20);
        this.eatCd = 2.5;
        this.toast('Ração consumida: +energia', 'good', '🍫');
        this.avatar?.trigger('eat');
      } else this.toast('Sem rações.', 'warn');
    }
    if (inp.hit('KeyT') && this.has('tea') && this.eatCd <= 0) {
      if (s.items.tea > 0) {
        s.items.tea--;
        s.heatPending += 1.4;
        this.eatCd = 2.5;
        this.toast('Chá quente: o corpo aquece', 'good', '🍵');
        this.avatar?.trigger('eat');
      } else this.toast('Sem chá térmico.', 'warn');
    }
    if (inp.hit('KeyL') && this.has('lamp')) s.lampOn = !s.lampOn;
    if (inp.hit('KeyO') && this.has('oxygen')) {
      if (s.oxygen > 0) s.oxygenOn = !s.oxygenOn;
      else this.toast('Cilindro vazio.', 'warn');
    }
    if (inp.hit('KeyG')) {
      this.hintsOn = !this.hintsOn;
      this.toast(this.hintsOn ? 'Indicadores de apoio: ligados' : 'Indicadores de apoio: desligados', 'info');
    }
    if (inp.hit('KeyV')) this.camRig.vista = !this.camRig.vista;
    if (inp.hit('KeyM')) {
      this.audio.setMuted(!this.audio.muted);
    }
  }

  // ---------------- eventos do jogador ----------------
  private onPlayerEvent(type: string, d?: any) {
    const st = this.profile.data.stats;
    switch (type) {
      case 'climbStart':
        this.ach('first_climb');
        if (this.firstClimbTip) {
          this.firstClimbTip = false;
          this.toast('Escalada: segure Q (mão esq.) ou E (mão dir.), mire com WASD e solte para agarrar.', 'info', '🧗');
        }
        break;
      case 'grab':
        this.avatar?.trigger('grab', { hand: d.hand, mat: this.player.hands[d.hand].mat, axe: this.has('axe') });
        this.audio.grab();
        this.fx.burst(d.p, d.q > 0.7 ? 0xffffff : 0xaa9988, 6, 1.5, 0.6);
        break;
      case 'slip':
        this.avatar?.trigger('slip');
        this.audio.slip();
        this.camRig.addShake(0.35);
        this.toast(d.reason === 'crumble' ? 'O apoio se esfarelou!' : d.reason === 'catch' ? 'A mão não segurou!' : `Mão ${d.hand === 0 ? 'esquerda' : 'direita'} escorregou!`, 'warn', '✋');
        break;
      case 'thud':
        this.audio.thud(d.speed);
        this.camRig.addShake(Math.min(1, d.speed / 30));
        this.fx.burst(this.player.pos, 0xcccccc, 20, 5, 0.8);
        this.toast(`Impacto! −${Math.round(d.dmg)} de saúde`, 'warn', '💥');
        break;
      case 'landed': {
        this.avatar?.trigger('landed', d);
        if (d.fell > 8) {
          st.falls++;
          this.runFalls++;
          st.maxFall = Math.max(st.maxFall, d.fell);
        }
        if (d.fell > 25 && this.surv.health > 0) this.ach('big_fall');
        break;
      }
      case 'catch':
        if (d.fell > 25) this.ach('big_fall');
        break;
      case 'ropeCatch':
        st.ropeSaves++;
        this.audio.thud(d.speed * 0.6);
        this.camRig.addShake(0.6);
        this.toast('A corda segurou a queda!', 'good', '🛟');
        this.ach('rope_save');
        break;
      case 'piton':
        this.avatar?.trigger('piton');
        st.pitons++;
        this.runPitons++;
        this.audio.piton();
        this.fx.burst(d.p, 0xdddddd, 8, 2, 0.5);
        this.toast(`Piton fixado (${this.surv.items.pitons} restantes)`, 'good', '📌');
        this.ach('first_piton');
        break;
      case 'mantle':
        this.avatar?.trigger('mantle');
        this.audio.grab();
        break;
      case 'dyno':
        this.avatar?.trigger('dyno');
        this.camRig.addShake(0.15);
        break;
      case 'msg':
        this.toast(d.text, d.kind || 'info');
        break;
      case 'death':
        st.deaths++;
        this.deadTimer = 3.4;
        this.camRig.addShake(1);
        this.profile.save();
        this.ev.onDeath(true, d.reason);
        break;
    }
  }

  private checkSurvivalDeath() {
    const p = this.player;
    if (p.state === 'dead') return;
    if (this.surv.health <= 0) p.kill(this.surv.temp < 33.5 ? 'cold' : 'health');
    else if (this.surv.temp < 29.8) p.kill('cold');
  }

  private respawn() {
    const c = this.layout.camps[this.checkpoint];
    this.player.spawn(c.pos);
    this.player.face.set(-c.pos.x, 0, -c.pos.z).normalize();
    this.surv.respawn();
    this.avatar?.trigger('respawn');
    this.rockfall.reset();
    this.hypo = false;
    this.ev.onDeath(false);
    this.toast(`Retomando em: ${c.name}`, 'info', '⛺');
  }

  private updateRockfall(dt: number) {
    const p = this.player;
    const a01 = p.pos.y / this.layout.summit.y;
    const enabled = a01 > 0.16 && !this.inCave && p.state !== 'dead';
    this.rockfall.update(
      dt,
      p.pos,
      this.terrain,
      enabled,
      this.def.severity * (0.8 + this.weather.precip * 0.4),
      () => {
        this.toast('Pedras rolando de cima! Fique atento.', 'warn', '🪨');
        this.audio.rumble();
      },
      (speed, dir) => {
        const dmg = 8 + speed * 0.9;
        this.surv.damage(dmg);
        p.rockHit(dir);
        this.camRig.addShake(0.8);
        this.audio.thud(speed);
        this.toast(`Atingido por uma pedra! −${Math.round(dmg)}`, 'warn', '🪨');
        if (this.surv.health <= 0) p.kill('rock');
      },
      (pt, speed) => {
        this.fx.burst(pt, 0x8a8178, 6, speed * 0.3, 0.6);
        if (pt.distanceTo(p.pos) < 40) this.audio.thud(speed * 0.4);
      },
    );
  }

  // ---------------- progressão ----------------
  private giveXp(n: number) {
    if (n <= 0) return;
    this.sessionXp += n;
    const ups = this.profile.addXp(n);
    for (const lvl of ups) {
      this.toast(`Nível ${lvl} alcançado!`, 'ach', '⭐');
      this.audio.chime();
      for (const e of EQUIPMENT) if (e.level === lvl) this.toast(`Equipamento desbloqueado: ${e.name}`, 'ach', e.icon);
      if (lvl >= 5) this.ach('veteran');
    }
  }

  private ach(id: string) {
    const xp = this.profile.unlockAch(id);
    if (xp > 0) {
      const a = ACHIEVEMENTS.find((x) => x.id === id)!;
      this.newAch.push(id);
      this.toast(`Conquista: ${a.name} (+${a.xp} XP)`, 'ach', a.icon);
      this.audio.chime();
      this.giveXp(xp);
      this.profile.save();
    }
  }

  private trackProgress(dt: number) {
    const p = this.player;
    const st = this.profile.data.stats;
    const dy = p.pos.y - this.maxY;
    const scale = (this.def.summitM - this.def.baseM) / this.layout.summit.y;
    // ganho de altitude real (somente subida em solo/parede)
    if (p.state === 'climb' || p.state === 'ground') {
      const climbed = Math.max(0, p.climbSpeedY * dt) * scale;
      if (climbed < 30) {
        st.totalClimb += climbed;
        this.runClimbed += climbed;
      }
      if (p.state === 'climb') {
        st.climbSeconds += dt;
        if ((p.hands[0].gripped && p.hands[0].mat === 'ice') || (p.hands[1].gripped && p.hands[1].mat === 'ice')) st.iceClimb += climbed;
      }
    }
    st.distance += 0;
    if (dy > 0 && (p.state === 'climb' || p.state === 'ground')) {
      this.maxY = p.pos.y;
      this.giveXp(dy * scale * 0.12);
    }
    const alt = this.altM(p.pos.y);
    if (alt > this.maxAltDisplayed) this.maxAltDisplayed = alt;
    st.maxAlt = Math.max(st.maxAlt, alt);

    // conquistas contínuas
    if (Math.hypot(p.pos.x - this.layout.camps[0].pos.x, p.pos.z - this.layout.camps[0].pos.z) > 30) this.ach('first_steps');
    if (p.pos.y / this.layout.summit.y > 0.6) this.ach('above_clouds');
    if (st.iceClimb >= 30) this.ach('ice_master');
    if (st.totalClimb >= 5000) this.ach('marathon');
    if (this.weather.kind === 'blizzard' && this.weather.precip > 0.7 && this.altM(p.pos.y) > 1500 && !this.inCave) this.ach('blizzard');
    if (this.surv.temp < 34.5) this.hypo = true;
    else if (this.hypo && this.surv.temp > 36) {
      this.hypo = false;
      this.ach('cold_survivor');
    }
    if (this.profile.level >= 5) this.ach('veteran');
    st.distance = st.distance + 0;
    st.distance += p.distWalked;
    p.distWalked = 0;
  }

  private checkCamps() {
    const p = this.player;
    for (const c of this.layout.camps) {
      const d = Math.hypot(p.pos.x - c.pos.x, p.pos.z - c.pos.z);
      if (d < 5 && Math.abs(p.pos.y - c.pos.y) < 3.5 && p.state !== 'dead') {
        if (!this.activeCamps[c.index]) {
          this.activeCamps[c.index] = true;
          this.world.setCampActive(c.index, true);
          this.profile.data.stats.camps++;
          this.runCamps++;
          this.surv.restock();
          this.surv.health = Math.min(100, this.surv.health + 30);
          this.giveXp(40);
          this.audio.chime();
          this.toast(`Acampamento ativado: ${c.name} — suprimentos reabastecidos`, 'good', '⛺');
          if (this.runCamps >= 3) this.ach('camp3');
          this.profile.save();
        }
        if (this.checkpoint !== c.index) {
          this.checkpoint = c.index;
          this.toast('Checkpoint salvo', 'info', '🚩');
        }
      }
    }
  }

  private checkSummit() {
    const p = this.player;
    const s = this.layout.summit;
    if (this.runState !== 'running') return;
    if (Math.hypot(p.pos.x - s.x, p.pos.z - s.z) < 5 && p.pos.y - 0.95 > s.y - 2 && p.state === 'ground') this.victory();
  }

  private victory() {
    this.runState = 'victory';
    this.input.unlock();
    const prof = this.profile.data;
    const prev = prof.conquered[this.def.id];
    const time = this.runTime;
    const record = !prev || time < prev.best;
    prof.conquered[this.def.id] = { best: prev ? Math.min(prev.best, time) : time, count: (prev?.count || 0) + 1, last: Date.now() };
    prof.stats.summits++;
    this.newAch = [];
    this.ach('summit');
    if (this.runPitons === 0) this.ach('free_solo');
    if (time < this.def.parTime) this.ach('speed');
    if (['aurora', 'gelado', 'titan'].every((id) => !!prof.conquered[id])) this.ach('three_peaks');
    const bonus = 300 + this.def.difficulty * 120;
    this.giveXp(bonus);
    this.profile.save();
    this.audio.chime();
    this.ev.onVictory({
      time,
      best: prof.conquered[this.def.id].best,
      record,
      xp: this.sessionXp,
      achievements: this.newAch.slice(),
      mountain: this.def.name,
      pitons: this.runPitons,
      falls: this.runFalls,
      climbed: Math.round(this.runClimbed),
    });
  }

  keepExploring() {
    if (this.runState !== 'victory') return;
    this.runState = 'running';
    this.input.lock();
    this.lastT = performance.now();
  }

  // ---------------- ambiente e visuais ----------------
  private applyEnvironment(dt: number, instant: boolean) {
    const w = this.weather;
    if (instant) {
      /* valores iniciais já coerentes */
    }
    const caveT = this.caveT;
    const fogColor = this.tmpV.set(w.horizon.r, w.horizon.g, w.horizon.b);
    const fog = this.scene.fog as THREE.FogExp2;
    fog.color.setRGB(lerp(fogColor.x, 0.02, caveT), lerp(fogColor.y, 0.025, caveT), lerp(fogColor.z, 0.03, caveT));
    fog.density = w.fog * (1 + 0.6 * smoothstep(0.4, 1, this.player ? this.player.pos.y / this.layout.summit.y : 0)) + caveT * 0.012;
    const u = this.sky.mat.uniforms;
    u.uTop.value.copy(w.top);
    u.uHorizon.value.copy(w.horizon);
    u.uSunDir.value.copy(this.sunDir);
    u.uGlow.value = w.light;
    this.hemi.intensity = (0.55 + 0.9 * w.light) * (1 - 0.9 * caveT);
    this.hemi.color.copy(w.top).lerp(new THREE.Color(1, 1, 1), 0.45);
    this.sun.intensity = 3.6 * w.light * (1 - 0.8 * caveT);
    this.sun.color.setRGB(1, 0.94 - 0.05 * (1 - w.light), 0.84 + 0.1 * (1 - w.light));
    const tint = this.tmpV.set(1, 1, 1);
    this.clouds.update(dt, this.windVec, w.cloud, new THREE.Color(tint.x * (0.7 + 0.3 * w.light), tint.y * (0.72 + 0.28 * w.light), tint.z * (0.78 + 0.22 * w.light)), this.terrain.half);
    this.renderer.toneMappingExposure = 1.0 + 0.25 * caveT;
  }

  private updateVisuals(dt: number) {
    const p = this.player;
    const cam = this.camera;
    // sol e sombras seguem o jogador
    this.sun.position.copy(p.pos).addScaledVector(this.sunDir, 300);
    this.sun.target.position.copy(p.pos);
    this.sky.mesh.position.copy(cam.position);

    // neve
    const a01 = clamp(p.pos.y / this.layout.summit.y, 0, 1);
    const intensity = this.weather.precip * (0.45 + 0.55 * a01) * (1 - this.caveT);
    const pixel = this.renderer.domElement.height / (2 * Math.tan((cam.fov * Math.PI) / 360));
    this.snow.update(this.time, cam.position, this.windVec, intensity, 2.2 + 2.5 * this.weather.precip, pixel);
    this.audio.setWind(this.windSpeed, this.inCave ? 0.25 : 1);

    // personagem
    if (this.avatar) {
      const lookDir = new THREE.Vector3();
      cam.getWorldDirection(lookDir);
      this.avatar.update({
        dt,
        state: p.state,
        pos: p.pos,
        vel: p.vel,
        face: p.face,
        R: p.r,
        U: p.u,
        F: p.f,
        hands: [p.hands[0], p.hands[1]],
        gripped: p.gripped,
        slope: p.surf.slope,
        surfMat: p.surf.mat,
        wind: this.windVec,
        windSpeed: this.windSpeed,
        temp: this.surv.temp,
        stamina: this.surv.stamina,
        exhausted: this.surv.exhausted,
        nearFire: this.nearFire,
        crouch: p.crouching && p.state === 'ground',
        moveInput: p.moving,
        ropeCaught: p.ropeCaught,
        anchor: p.anchors.length ? p.anchors[p.anchors.length - 1] : null,
        lookDir,
        ground: (x, z) => this.terrain.heightAt(x, z),
        project: (q, off, out) => p.projectToSurface(q, off, out),
        axe: this.has('axe'),
        crampons: this.has('crampons'),
        lamp: this.surv.lampOn,
      });
    }

    // luzes pontuais mais próximas
    this.lightTimer -= dt;
    if (this.lightTimer <= 0) {
      this.lightTimer = 0.3;
      const srcs = this.world.lightSources
        .map((s) => ({ s, d: s.pos.distanceTo(p.pos) }))
        .filter((x) => x.d < x.s.dist * 2.5)
        .sort((a, b) => a.d - b.d)
        .slice(0, 3);
      this.pointLights.forEach((l, i) => {
        const e = srcs[i];
        if (e) {
          l.position.copy(e.s.pos);
          l.color.set(e.s.color);
          l.distance = e.s.dist;
          (l as any)._base = e.s.intensity;
        } else (l as any)._base = 0;
      });
    }
    for (const l of this.pointLights) {
      const b = (l as any)._base || 0;
      l.intensity = b * (0.88 + 0.12 * Math.sin(this.time * 14 + l.position.x)) ;
    }

    // corda
    this.updateRope();
    for (let i = 0; i < this.pitonMeshes.length; i++) {
      const m = this.pitonMeshes[i];
      const a = p.anchors[i];
      if (a) {
        m.visible = true;
        m.position.copy(a);
      } else m.visible = false;
    }

    // retículos das mãos e dicas
    for (let i = 0; i < 2; i++) {
      const h = p.hands[i];
      const r = this.reticles[i];
      if (p.state === 'climb' && h.reaching && h.held) {
        r.visible = true;
        r.position.copy(h.cand).addScaledVector(p.n, 0.05);
        r.lookAt(this.tmpV.copy(r.position).add(p.n));
        const q = h.candQ;
        (r.material as THREE.MeshBasicMaterial).color.setRGB(q >= 0.85 ? 0.4 : 1, q >= 0.55 ? 1 : 0.3, q >= 0.85 ? 0.5 : q >= 0.55 ? 0.3 : 0.3);
        if (q < 0.15) (r.material as THREE.MeshBasicMaterial).color.setRGB(0.6, 0.6, 0.6);
        r.scale.setScalar(1 + Math.sin(this.time * 10) * 0.12);
      } else r.visible = false;
    }
    this.hintTimer -= dt;
    const showHints = this.hintsOn && p.state === 'climb';
    this.hintPoints.visible = showHints;
    if (showHints && this.hintTimer <= 0) {
      this.hintTimer = 0.12;
      p.hints(this.hintPos, this.hintCol);
      (this.hintPoints.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      (this.hintPoints.geometry.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    }
  }

  private updateRope() {
    const p = this.player;
    const pts: THREE.Vector3[] = [];
    if (p.anchors.length) {
      for (const a of p.anchors) pts.push(a);
      const A = p.anchors[p.anchors.length - 1];
      const P = this.tmpV.copy(p.pos);
      P.y += 0.1;
      const len = A.distanceTo(P);
      const slack = Math.max(0, p.ropeOut + 1.5 - len);
      const sag = Math.min(slack * 0.35, 6);
      for (let i = 1; i <= 16; i++) {
        const t = i / 16;
        const q = new THREE.Vector3().lerpVectors(A, P, t);
        q.y -= sag * 4 * t * (1 - t);
        pts.push(q);
      }
    }
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    const d = new THREE.Vector3();
    const mid = new THREE.Vector3();
    let n = 0;
    for (let i = 0; i < pts.length - 1 && n < 48; i++) {
      d.copy(pts[i + 1]).sub(pts[i]);
      const l = d.length();
      if (l < 0.001) continue;
      d.divideScalar(l);
      q.setFromUnitVectors(up, d);
      mid.copy(pts[i]).addScaledVector(d, l / 2);
      m.compose(mid, q, new THREE.Vector3(1, l, 1));
      this.ropeMesh.setMatrixAt(n++, m);
    }
    this.ropeMesh.count = n;
    this.ropeMesh.instanceMatrix.needsUpdate = true;
  }

  // ---------------- HUD ----------------
  private buildHud(): HudState {
    const p = this.player;
    const s = this.surv;
    const sm = this.layout.summit;
    const handInfo = (i: number): HudHand => {
      const h = p.hands[i];
      return {
        st: h.gripped ? 'grip' : h.reaching ? 'reach' : 'free',
        q: h.gripped ? h.quality : h.reaching ? h.candQ : 0,
        slip: h.slip,
        fat: h.fatigue,
      };
    };
    const heading = norm360(-this.camRig.yaw * DEG);
    const bearing = (x: number, z: number) => norm360(Math.atan2(x - p.pos.x, -(z - p.pos.z)) * DEG);
    let nextCamp = null as null | (typeof this.layout.camps)[number];
    for (const c of this.layout.camps) {
      if (!this.activeCamps[c.index]) {
        nextCamp = c;
        break;
      }
    }
    const wDeg = norm360(Math.atan2(this.windVec.x, -this.windVec.z) * DEG);
    const unlocked: Record<string, boolean> = {};
    for (const e of EQUIPMENT) unlocked[e.id] = this.profile.equipUnlocked(e.id);
    const lv = this.profile.levelInfo();
    return {
      alt: this.altM(p.pos.y),
      altMax: this.maxAltDisplayed,
      summitM: this.def.summitM,
      progress: clamp(p.pos.y / sm.y, 0, 1),
      stamina: s.stamina,
      staminaMax: s.staminaMax,
      health: s.health,
      energy: s.energy,
      temp: s.temp,
      ambient: this.ambient,
      oxygen: s.oxygen,
      oxygenOn: s.oxygenOn,
      lampOn: s.lampOn,
      exhausted: s.exhausted,
      hands: [handInfo(0), handInfo(1)],
      balance: p.state === 'climb' ? p.balance : 0,
      mode: p.state,
      roped: p.anchors.length > 0,
      ropeOut: p.ropeOut,
      anchors: p.anchors.length,
      pitons: s.items.pitons,
      chalk: s.items.chalk,
      chalkT: s.chalkTimer,
      food: s.items.food,
      tea: s.items.tea,
      windKmh: this.windSpeed * 3.6,
      windDir: wDeg,
      weather: WEATHER_NAMES[this.weather.kind],
      precip: this.weather.precip,
      biome: this.terrain.biome(p.pos.y, this.inCave),
      heading,
      summitBearing: bearing(sm.x, sm.z),
      summitDist: Math.hypot(sm.x - p.pos.x, sm.z - p.pos.z, (sm.y - p.pos.y) * 0.5),
      campBearing: nextCamp ? bearing(nextCamp.pos.x, nextCamp.pos.z) : null,
      campDist: nextCamp ? Math.hypot(nextCamp.pos.x - p.pos.x, nextCamp.pos.z - p.pos.z) : 0,
      campName: nextCamp ? nextCamp.name : '',
      time: this.runTime,
      prompt: p.state === 'dead' ? '' : p.prompt,
      cold: clamp((36.2 - s.temp) / 3.5, 0, 1),
      hurt: s.hurtFlash,
      camps: this.layout.camps.map((c) => ({ p: clamp(c.pos.y / sm.y, 0, 1), active: !!this.activeCamps[c.index] })),
      checkpoint: this.checkpoint,
      intro: this.camRig.introT,
      inCave: this.inCave,
      hints: this.hintsOn,
      vista: this.camRig.vista,
      muted: this.audio.muted,
      matName: MAT_NAMES[p.surf.mat],
      level: lv.level,
      xpFrac: lv.frac,
      unlocked,
      dead: p.state === 'dead',
      speed: p.speedMs,
    };
  }

  toast(text: string, kind: Toast['kind'] = 'info', icon?: string) {
    this.ev.onToast({ text, kind, icon });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resizeHandler);
    try {
      this.profile.save();
    } catch {
      /* ignore */
    }
    this.input?.dispose();
    this.avatar?.dispose();
    try {
      void this.audio.ctx?.close();
    } catch {
      /* ignore */
    }
    this.world?.dispose();
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
    if (this.renderer) {
      this.renderer.dispose();
      this.renderer.domElement.remove();
    }
  }
}
