# 🏔️ MOUNTAIN — Beyond the Summit

> Um jogo independente de alpinismo e sobrevivência em 3D, jogável direto no navegador.

Escale montanhas gigantescas geradas proceduralmente, administre stamina, frio, energia e oxigênio, e enfrente nevascas, pedras rolando e paredões de gelo até alcançar o cume. Cada apoio conta: suas mãos são controladas de forma independente e podem escorregar a qualquer momento.

---

## 📖 Sobre o jogo

**MOUNTAIN — Beyond the Summit** é um simulador de escalada em terceira pessoa com foco em física de aderência, gestão de recursos e sensação de escala. O objetivo é simples de explicar e difícil de cumprir: **chegar ao topo**.

### Montanhas

| Montanha | Altitude | Dificuldade | Descrição |
|---|---|---|---|
| **Monte Aurora** | 3.800 m | ▲▲ | Florestas, paredões de granito e pico gelado. Ideal para aprender. |
| **Pico Gelado** | 5.100 m | ▲▲▲▲ | Muralhas de gelo, ventos cortantes e cavernas de cristal. |
| **Titã Negro** | 6.900 m | ▲▲▲▲▲ | Rocha negra, ar rarefeito e nevascas sem fim. |

Cada montanha é desbloqueada ao conquistar a anterior.

### Biomas
🌲 Floresta · 🪨 Penhascos rochosos · 🧊 Montanha congelada · 🕳️ Cavernas · 🌨️ Zona do pico com ventos extremos

---

## 🎮 Mecânicas principais

### Escalada
- **Controle independente dos braços:** segure `Q` (mão esquerda) ou `E` (mão direita), mire com `WASD` e solte para agarrar.
- **Física de aderência:** cada apoio tem qualidade própria, que depende do material (rocha, gelo, neve, pedra solta), da umidade, do frio, do magnésio e da fadiga das mãos.
- **Equilíbrio:** pendurado por uma mão só, o corpo balança; use `A`/`D` para compensar e `Shift` para firmar os pés.
- **Perda de aderência:** as mãos escorregam aos poucos, e apoios ruins se esfarelam.
- **Salto dinâmico (dyno)** com `Espaço` e agarrar no meio da queda.
- **Corda e pitons:** fixe pitons com `R`. A corda só segura a queda até o comprimento já percorrido acima do último piton.
- **Indicadores de apoio:** pontos verdes, amarelos e vermelhos mostram a qualidade de cada ponto.

### Sobrevivência
- 🌡️ Temperatura corporal (hipotermia)
- 💪 Stamina e resistência física
- 🍫 Energia (fome)
- 🫁 Oxigênio em grandes altitudes
- 🌦️ Clima dinâmico: céu limpo, neblina, neve e nevasca
- 💨 Vento variável conforme altitude e exposição
- 🪨 Quedas de pedras nos penhascos

### Progressão
- ⛺ 7 acampamentos por montanha (checkpoints, reabastecimento e fogueira)
- ⭐ Sistema de níveis e XP
- 🏆 17 conquistas
- 🎒 9 equipamentos desbloqueáveis: corda, magnésio, ração, chá, lanterna, piolet, jaqueta térmica, crampons e oxigênio
- ⏱️ Recordes de tempo e registro de montanhas conquistadas
- 📊 Estatísticas detalhadas de escalada

O progresso fica salvo automaticamente no navegador (`localStorage`).

---

## 🧍 Personagem e animações

O protagonista tem um **rig humanoide completo** (73 ossos, incluindo dedos) e uma biblioteca de **46 animações**:

- **Movimento:** idle, andar (frente/trás/lados), correr, sprint, iniciar/parar, giro de 180°
- **Ações:** pular, cair, aterrissar, agachar, olhar ao redor, checar equipamento, ajustar a mochila, recuperar o fôlego
- **Escalada:** alcançar apoios, trocar os pés, pendurar, puxar o corpo, transpor bordas (mantle), transpor obstáculos, escorregar e recuperar, piolet, escalada com corda
- **Sobrevivência:** andar na neve, contra o vento e no gelo, reação ao frio, descansar, usar equipamento

Recursos técnicos: blend tree de locomoção com sincronização de fase (sem pés deslizando), IK de mãos e pés, olhar procedural, mola na mochila e suporte a root motion.

### Usando seu próprio modelo 3D
No menu principal, abra **🧍 Personagem: rig & animações** e importe um arquivo `.glb`, `.gltf`, `.fbx` ou `.obj`:
- **Malha sem rig:** o auto-rig ajusta o esqueleto e calcula os pesos de skin.
- **Rig humanoide existente (Mixamo / Unreal / Blender):** as animações são retargetizadas para o esqueleto original.

Clique em **Usar no jogo** ou coloque o arquivo em `public/models/protagonist.glb`. O laboratório também exporta o personagem com todas as animações em **GLB**, um manifesto JSON e uma folha de contato.

---

## ⌨️ Controles

| Tecla | Ação |
|---|---|
| `W A S D` | Andar / mirar o alcance na parede |
| `Mouse` / setas | Câmera |
| `Shift` | Correr · na parede: firmar os pés |
| `Espaço` | Pular · na parede: salto dinâmico |
| `Q` / `E` (ou botões do mouse) | Mão esquerda / direita |
| `Z` | Soltar-se · na borda: descer pela parede |
| `X` | Agachar |
| `B` | Modo cauteloso (caminhar com strafe) |
| `R` | Fixar piton e amarrar a corda |
| `C` | Magnésio |
| `F` | Comer ração |
| `T` | Beber chá quente |
| `L` | Lanterna |
| `O` | Oxigênio |
| `V` | Modo vista (panorama da montanha) |
| `G` | Mostrar/ocultar indicadores de apoio |
| `H` | Ajuda |
| `P` / `Esc` | Pausar |
| `M` | Silenciar |

---

## 🛠️ Stack utilizada

| Tecnologia | Uso |
|---|---|
| **[React 19](https://react.dev/)** | Interface: menus, HUD e laboratório do personagem |
| **[TypeScript](https://www.typescriptlang.org/)** | Tipagem de todo o código |
| **[Three.js](https://threejs.org/)** | Renderização 3D, iluminação, sombras, skinning e animação |
| **[Vite](https://vitejs.dev/)** | Build e servidor de desenvolvimento |
| **[Tailwind CSS 4](https://tailwindcss.com/)** | Estilização da interface |
| **vite-plugin-singlefile** | Gera o jogo inteiro em um único `index.html` |
| **Web Audio API** | Vento e efeitos sonoros gerados por código |
| **Pointer Lock API** | Controle de câmera com o mouse |
| **IndexedDB / localStorage** | Modelo do personagem e progresso do jogador |

Tudo é **procedural**: terreno, texturas, vegetação, céu, nuvens, sons e animações são gerados por código. O jogo não depende de assets externos.

---

## 📥 Como baixar e rodar

### Pré-requisitos
- [Node.js](https://nodejs.org/) **18 ou superior**
- npm (já vem com o Node)
- Navegador moderno com WebGL 2 (Chrome, Edge, Firefox ou Safari recentes)

### Passo a passo

```bash
# 1. Clone o repositório
git clone https://github.com/SEU-USUARIO/mountain-beyond-the-summit.git

# 2. Entre na pasta
cd mountain-beyond-the-summit

# 3. Instale as dependências
npm install

# 4. Rode em modo de desenvolvimento
npm run dev
```

Abra o endereço exibido no terminal (geralmente `http://localhost:5173`).

### Gerar a versão final

```bash
npm run build     # gera dist/index.html
npm run preview   # serve a versão compilada localmente
```

O build produz **um único arquivo `dist/index.html`** com todo o jogo embutido, pronto para hospedar em GitHub Pages, Netlify, Vercel ou qualquer servidor estático.

> 💡 Para carregar um modelo de `public/models/protagonist.glb`, sirva o jogo por HTTP (`npm run dev` ou `npm run preview`). Abrir o arquivo direto pelo explorador (`file://`) bloqueia esse carregamento; a importação pelo laboratório funciona normalmente.

---

## 📁 Estrutura do projeto

```
src/
├── App.tsx                 # Telas e fluxo do jogo
├── game/                   # Sistemas de gameplay
│   ├── Game.ts             # Orquestrador (loop, render, eventos)
│   ├── terrain.ts          # Geração da montanha e materiais
│   ├── layout.ts           # Acampamentos, cavernas e cume
│   ├── world.ts            # Céu, nuvens, árvores, rochas, cavernas
│   ├── player.ts           # Movimento, escalada, aderência, corda
│   ├── survival.ts         # Temperatura, stamina, energia, oxigênio
│   ├── weather.ts          # Clima, vento e partículas de neve
│   ├── cameraRig.ts        # Câmera cinematográfica em 3ª pessoa
│   ├── progression.ts      # XP, níveis, conquistas e estatísticas
│   ├── fx.ts               # Partículas e queda de pedras
│   ├── audio.ts            # Áudio procedural
│   ├── input.ts            # Teclado e mouse
│   └── config.ts           # Montanhas, equipamentos e conquistas
├── character/              # Personagem
│   ├── skeleton.ts         # Esqueleto humanoide
│   ├── clips.ts            # Biblioteca de animações
│   ├── animator.ts         # Máquina de estados, blend tree, IK
│   ├── avatar.ts           # Liga o gameplay às animações
│   ├── ik.ts               # IK de dois ossos
│   ├── loader.ts           # Importação, auto-rig e retarget
│   ├── skinning.ts         # Cálculo de pesos de skin
│   ├── exporter.ts         # Exportação GLB e manifesto
│   ├── standIn.ts          # Modelo provisório
│   └── LabScene.ts         # Cena do laboratório
└── ui/                     # Interface React
    ├── HUD.tsx
    ├── Menus.tsx
    └── CharacterLab.tsx
```

A arquitetura é modular: cada sistema é independente e pode ser expandido sem afetar os demais.

---

## 🗺️ Roadmap

- [ ] Mais montanhas e biomas (vulcão, deserto de altitude)
- [ ] Ciclo dia/noite
- [ ] Avalanches
- [ ] Suporte a gamepad
- [ ] Modo cooperativo (cordada em dupla)
- [ ] Trilha sonora dinâmica
- [ ] Ranking online de tempos

---

## 🤝 Contribuindo

1. Faça um fork do projeto
2. Crie uma branch: `git checkout -b minha-feature`
3. Commit: `git commit -m "Adiciona minha feature"`
4. Push: `git push origin minha-feature`
5. Abra um Pull Request

---

## 📄 Licença

Distribuído sob a licença **MIT**. Veja o arquivo `LICENSE` para mais detalhes.

---

<p align="center"><b>MOUNTAIN — Beyond the Summit</b><br/>O topo é só o começo.</p>
